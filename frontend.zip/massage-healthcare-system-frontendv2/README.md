# Massage Booking System

A modern web application for booking massage services, built with modern technologies.

## Features

- Online massage service booking
- Real-time availability checking
- User authentication and profiles
- Service catalog with detailed descriptions
- Booking management for both clients and administrators
- Responsive design for all devices

## Tech Stack

### Frontend
- React + TypeScript
- Vite for build tooling
- Tailwind CSS for styling
- Redux Toolkit for state management

### Backend
- NestJS (Node.js framework)
- PostgreSQL with TypeORM for database ORM
- JWT for authentication
- Socket.IO for real-time features

## Getting Started

### Prerequisites

- Node.js (v18 or higher)
- npm or yarn
- PostgreSQL

### Installation

1. Clone the repository:
```bash
git clone [repository-url]
cd massage-booking
```

2. Install dependencies:
```bash
# Install frontend dependencies
cd frontend
npm install

# Install backend dependencies
cd ../backend
npm install
```

3. Set up environment variables:
Create `.env` files in both frontend and backend directories following the `.env.example` templates.

4. Start the development servers:

```bash
# Start backend server
cd backend
npm run start:dev

# Start frontend development server
cd frontend
npm run dev
```

The application will be available at `http://localhost:5173`

## Project Structure

```
massage-booking/
├── frontend/           # React frontend application
│   ├── src/
│   ├── public/
│   └── ...
├── backend/           # NestJS backend application
│   ├── src/
│   ├── config/
│   └── ...
└── README.md
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contact

Your Name - [your-email@example.com]
Project Link: [https://github.com/yourusername/massage-booking]

## Acknowledgments

- List any resources, libraries, or tools that you used or were inspired by
- Credit any collaborators or contributors 