import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles: string[];
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, allowedRoles }) => {
  const location = useLocation();
  const user = JSON.parse(localStorage.getItem('user') || 'null');
  const userRole = user?.role || 'guest';

  // Nếu chưa đăng nhập và không phải ở trang chủ, chuyển về trang đăng nhập
  if (!user && location.pathname !== '/') {
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }

  // Nếu là admin đã đăng nhập và đang cố truy cập trang chủ, chuyển về trang admin
  if (user?.role === 'admin' && location.pathname === '/') {
    return <Navigate to="/admin" replace />;
  }

  // Nếu là employee đã đăng nhập và đang cố truy cập trang chủ, chuyển về trang employee
  if (user?.role === 'employee' && location.pathname === '/') {
    return <Navigate to="/employee" replace />;
  }

  // Nếu đã đăng nhập nhưng không có quyền truy cập
  if (user && !allowedRoles.includes(userRole)) {
    // Nếu là admin, chuyển về trang admin
    if (userRole === 'admin') {
      return <Navigate to="/admin" replace />;
    }
    // Nếu là employee, chuyển về trang employee
    if (userRole === 'employee') {
      return <Navigate to="/employee" replace />;
    }
    // Nếu là customer, chuyển về trang chủ
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute; 