export interface AppointmentHistory {
  date: string;
  service: string;
  status: string;
}

export interface AppointmentData {
  id: number;
  date: string;
  time: string;
  service: string;
  duration: number;
  therapist: string;
  status: 'upcoming' | 'past' | 'cancelled';

  // Admin fields (optional)
  adminId?: string;
  customerId?: string;
  customerName?: string;
  customerAvatar?: string;
  customerType?: string;
  customerPhone?: string;
  customerEmail?: string;
  customerUsageCount?: number;
  serviceId?: string;
  servicePrice?: number;
  additionalServiceName?: string;
  additionalServicePrice?: number;
  notes?: string;
  staffId?: string;
  staffName?: string;
  staffAvatar?: string;
  staffRole?: string;
  staffExperience?: number;
  staffSpecialty?: string;
  totalPrice?: number;
  history?: AppointmentHistory[];
  adminStatus?: 'confirmed' | 'pending' | 'cancelled';

  // Thêm trường này để hỗ trợ lịch hẹn gói dịch vụ
  therapists?: { name: string; experience?: string }[];
}

export const appointmentsData: AppointmentData[] = [
  {
    id: 1,
    date: '15 Tháng 6, 2025',
    time: '14:00',
    service: 'Massage Thụy Điển',
    duration: 60,
    therapist: 'Emma Wilson',
    status: 'upcoming',
    adminId: '1',
    customerId: '101',
    customerName: 'Nguyễn Thị Anh',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg',
    customerType: 'Khách hàng VIP',
    customerPhone: '0912 345 678',
    customerEmail: 'nguyenanh@email.com',
    customerUsageCount: 12,
    serviceId: '1',
    servicePrice: 850000,
    additionalServiceName: 'Tinh dầu đặc biệt',
    additionalServicePrice: 150000,
    notes: 'Khách hàng yêu cầu massage nhẹ nhàng, tập trung vào vùng vai gáy. Có tiền sử đau lưng mãn tính.',
    staffId: '1',
    staffName: 'Lê Thị Mai',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-5.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 5,
    staffSpecialty: 'Massage Thụy Điển, Thái',
    totalPrice: 1000000,
    history: [
      { date: '20/04/2025', service: 'Massage chân', status: 'Hoàn thành' },
      { date: '15/04/2025', service: 'Massage thư giãn', status: 'Hoàn thành' },
    ],
    adminStatus: 'confirmed',
  },
  {
    id: 2,
    date: '22 Tháng 6, 2025',
    time: '15:30',
    service: 'Massage Cơ Sâu',
    duration: 90,
    therapist: 'Michael Chen',
    status: 'upcoming',
    adminId: '2',
    customerId: '102',
    customerName: 'Trần Văn Bình',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    customerType: 'Khách hàng tiềm năng',
    customerPhone: '0987 654 321',
    customerEmail: 'binhtran@email.com',
    customerUsageCount: 3,
    serviceId: '2',
    servicePrice: 600000,
    additionalServiceName: 'Không',
    additionalServicePrice: 0,
    notes: 'Khách hàng muốn tập trung vào vùng cổ và vai.',
    staffId: '2',
    staffName: 'Phạm Thị Hoa',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-6.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 3,
    staffSpecialty: 'Massage cổ, vai, gáy',
    totalPrice: 600000,
    history: [
      { date: '10/04/2025', service: 'Massage lưng', status: 'Hoàn thành' },
    ],
    adminStatus: 'pending',
  },
  {
    id: 3,
    date: '10 Tháng 3, 2025',
    time: '10:00',
    service: 'Massage Đá Nóng',
    duration: 75,
    therapist: 'Sarah Johnson',
    status: 'past',
    adminId: '3',
    customerId: '103',
    customerName: 'Lê Thị Cúc',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-5.jpg',
    customerType: 'Khách hàng thường',
    customerPhone: '0965 432 198',
    customerEmail: 'cuc.lt@email.com',
    customerUsageCount: 5,
    serviceId: '3',
    servicePrice: 700000,
    additionalServiceName: 'Đá nóng Himalaya',
    additionalServicePrice: 100000,
    notes: 'Khách hàng thích massage đá nóng, yêu cầu nhiệt độ vừa phải.',
    staffId: '3',
    staffName: 'Nguyễn Văn Toàn',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-8.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 4,
    staffSpecialty: 'Massage Đá Nóng',
    totalPrice: 800000,
    history: [
      { date: '01/03/2025', service: 'Massage Thái', status: 'Hoàn thành' },
    ],
    adminStatus: 'confirmed',
  },
  {
    id: 4,
    date: '5 Tháng 3, 2025',
    time: '16:00',
    service: 'Massage Chân',
    duration: 45,
    therapist: 'David Lee',
    status: 'cancelled',
    adminId: '4',
    customerId: '104',
    customerName: 'Phạm Minh Quân',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-3.jpg',
    customerType: 'Khách hàng VIP',
    customerPhone: '0911 223 344',
    customerEmail: 'quan.pm@email.com',
    customerUsageCount: 8,
    serviceId: '4',
    servicePrice: 400000,
    additionalServiceName: 'Ngâm thảo dược',
    additionalServicePrice: 50000,
    notes: 'Khách hàng bị đau chân, yêu cầu massage nhẹ.',
    staffId: '4',
    staffName: 'Đỗ Minh Quân',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-7.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 2,
    staffSpecialty: 'Massage chân',
    totalPrice: 450000,
    history: [
      { date: '20/02/2025', service: 'Massage body', status: 'Hoàn thành' },
    ],
    adminStatus: 'cancelled',
  },
  {
    id: 5,
    date: '10 Tháng 7, 2025',
    time: '11:00',
    service: 'Massage Aroma',
    duration: 60,
    therapist: 'Nguyễn Thị Hoa',
    status: 'upcoming',
    adminId: '5',
    customerId: '105',
    customerName: 'Đỗ Thị Hạnh',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-4.jpg',
    customerType: 'Khách hàng tiềm năng',
    customerPhone: '0933 445 566',
    customerEmail: 'hanh.dt@email.com',
    customerUsageCount: 2,
    serviceId: '5',
    servicePrice: 650000,
    additionalServiceName: 'Tinh dầu Aroma',
    additionalServicePrice: 80000,
    notes: 'Khách hàng thích mùi tinh dầu nhẹ.',
    staffId: '5',
    staffName: 'Vũ Thị Mai',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-7.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 3,
    staffSpecialty: 'Massage Aroma',
    totalPrice: 730000,
    history: [
      { date: '01/07/2025', service: 'Chăm sóc da mặt', status: 'Hoàn thành' },
    ],
    adminStatus: 'confirmed',
  },
  {
    id: 6,
    date: '12 Tháng 7, 2025',
    time: '13:30',
    service: 'Massage Thái',
    duration: 90,
    therapist: 'Trần Văn B',
    status: 'upcoming',
    adminId: '6',
    customerId: '106',
    customerName: 'Ngô Văn Lực',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-6.jpg',
    customerType: 'Khách hàng thường',
    customerPhone: '0977 889 900',
    customerEmail: 'luc.nv@email.com',
    customerUsageCount: 1,
    serviceId: '6',
    servicePrice: 750000,
    additionalServiceName: 'Không',
    additionalServicePrice: 0,
    notes: 'Khách hàng muốn massage mạnh.',
    staffId: '6',
    staffName: 'Trịnh Quốc Hùng',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-8.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 2,
    staffSpecialty: 'Massage Thái',
    totalPrice: 750000,
    history: [
      { date: '10/07/2025', service: 'Massage body', status: 'Hoàn thành' },
    ],
    adminStatus: 'confirmed',
  },
  {
    id: 7,
    date: '15 Tháng 7, 2025',
    time: '09:00',
    service: 'Massage Đầu',
    duration: 30,
    therapist: 'Lê Thị C',
    status: 'upcoming',
    adminId: '7',
    customerId: '107',
    customerName: 'Lý Thị Hồng',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-9.jpg',
    customerType: 'Khách hàng thường',
    customerPhone: '0933 666 999',
    customerEmail: 'hong.lt@email.com',
    customerUsageCount: 4,
    serviceId: '7',
    servicePrice: 300000,
    additionalServiceName: 'Không',
    additionalServicePrice: 0,
    notes: 'Khách hàng muốn massage đầu nhẹ nhàng.',
    staffId: '7',
    staffName: 'Đỗ Minh Quân',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-7.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 1,
    staffSpecialty: 'Massage đầu',
    totalPrice: 300000,
    history: [
      { date: '01/07/2025', service: 'Massage chân', status: 'Hoàn thành' },
    ],
    adminStatus: 'confirmed',
  },
  {
    id: 8,
    date: '18 Tháng 7, 2025',
    time: '17:00',
    service: 'Massage Body Toàn Thân',
    duration: 60,
    therapist: 'Phạm Văn D',
    status: 'upcoming',
    adminId: '8',
    customerId: '108',
    customerName: 'Trịnh Quốc Toàn',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-8.jpg',
    customerType: 'Khách hàng tiềm năng',
    customerPhone: '0909 888 777',
    customerEmail: 'toan.tq@email.com',
    customerUsageCount: 2,
    serviceId: '8',
    servicePrice: 900000,
    additionalServiceName: 'Không',
    additionalServicePrice: 0,
    notes: 'Khách hàng muốn massage toàn thân.',
    staffId: '8',
    staffName: 'Nguyễn Văn Toàn',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-8.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 3,
    staffSpecialty: 'Massage body',
    totalPrice: 900000,
    history: [
      { date: '10/07/2025', service: 'Massage Thái', status: 'Hoàn thành' },
    ],
    adminStatus: 'confirmed',
  },
  {
    id: 9,
    date: '1 Tháng 2, 2025',
    time: '08:00',
    service: 'Massage Thụy Điển',
    duration: 60,
    therapist: 'Emma Wilson',
    status: 'past',
    adminId: '9',
    customerId: '109',
    customerName: 'Nguyễn Văn An',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-10.jpg',
    customerType: 'Khách hàng thường',
    customerPhone: '0912 111 222',
    customerEmail: 'an.nv@email.com',
    customerUsageCount: 6,
    serviceId: '9',
    servicePrice: 850000,
    additionalServiceName: 'Không',
    additionalServicePrice: 0,
    notes: 'Khách hàng thích massage Thụy Điển.',
    staffId: '9',
    staffName: 'Lê Thị Mai',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-5.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 2,
    staffSpecialty: 'Massage Thụy Điển',
    totalPrice: 850000,
    history: [
      { date: '20/01/2025', service: 'Massage body', status: 'Hoàn thành' },
    ],
    adminStatus: 'confirmed',
  },
  {
    id: 10,
    date: '15 Tháng 1, 2025',
    time: '15:00',
    service: 'Massage Cơ Sâu',
    duration: 90,
    therapist: 'Michael Chen',
    status: 'past',
    adminId: '10',
    customerId: '110',
    customerName: 'Phạm Thị Hồng',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-11.jpg',
    customerType: 'Khách hàng tiềm năng',
    customerPhone: '0988 777 666',
    customerEmail: 'hong.pt@email.com',
    customerUsageCount: 2,
    serviceId: '10',
    servicePrice: 600000,
    additionalServiceName: 'Không',
    additionalServicePrice: 0,
    notes: 'Khách hàng muốn massage cơ sâu.',
    staffId: '10',
    staffName: 'Phạm Thị Hoa',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-6.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 2,
    staffSpecialty: 'Massage cơ sâu',
    totalPrice: 600000,
    history: [
      { date: '10/01/2025', service: 'Massage vai gáy', status: 'Hoàn thành' },
    ],
    adminStatus: 'confirmed',
  },
  {
    id: 11,
    date: '20 Tháng 2, 2025',
    time: '10:30',
    service: 'Massage Đá Nóng',
    duration: 75,
    therapist: 'Sarah Johnson',
    status: 'past',
    adminId: '11',
    customerId: '111',
    customerName: 'Trần Thị Lan',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-12.jpg',
    customerType: 'Khách hàng thường',
    customerPhone: '0912 333 444',
    customerEmail: 'lan.tt@email.com',
    customerUsageCount: 3,
    serviceId: '11',
    servicePrice: 700000,
    additionalServiceName: 'Đá nóng Himalaya',
    additionalServicePrice: 100000,
    notes: 'Khách hàng thích massage đá nóng.',
    staffId: '11',
    staffName: 'Nguyễn Văn Toàn',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-8.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 2,
    staffSpecialty: 'Massage Đá Nóng',
    totalPrice: 800000,
    history: [
      { date: '15/02/2025', service: 'Massage body', status: 'Hoàn thành' },
    ],
    adminStatus: 'confirmed',
  },
  {
    id: 12,
    date: '5 Tháng 4, 2025',
    time: '16:00',
    service: 'Massage Chân',
    duration: 45,
    therapist: 'David Lee',
    status: 'cancelled',
    adminId: '12',
    customerId: '112',
    customerName: 'Nguyễn Thị Mai',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-13.jpg',
    customerType: 'Khách hàng VIP',
    customerPhone: '0912 555 666',
    customerEmail: 'mai.nt@email.com',
    customerUsageCount: 7,
    serviceId: '12',
    servicePrice: 400000,
    additionalServiceName: 'Ngâm thảo dược',
    additionalServicePrice: 50000,
    notes: 'Khách hàng bị đau chân.',
    staffId: '12',
    staffName: 'Đỗ Minh Quân',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-7.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 2,
    staffSpecialty: 'Massage chân',
    totalPrice: 450000,
    history: [
      { date: '01/04/2025', service: 'Massage body', status: 'Hoàn thành' },
    ],
    adminStatus: 'cancelled',
  },
  {
    id: 13,
    date: '8 Tháng 5, 2025',
    time: '18:00',
    service: 'Massage Aroma',
    duration: 60,
    therapist: 'Nguyễn Thị Hoa',
    status: 'cancelled',
    adminId: '13',
    customerId: '113',
    customerName: 'Vũ Thị Mai',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-7.jpg',
    customerType: 'Khách hàng VIP',
    customerPhone: '0911 555 777',
    customerEmail: 'mai.vt@email.com',
    customerUsageCount: 10,
    serviceId: '13',
    servicePrice: 650000,
    additionalServiceName: 'Tinh dầu Aroma',
    additionalServicePrice: 80000,
    notes: 'Khách hàng thích mùi tinh dầu.',
    staffId: '13',
    staffName: 'Nguyễn Văn Toàn',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-8.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 3,
    staffSpecialty: 'Massage Aroma',
    totalPrice: 730000,
    history: [
      { date: '01/05/2025', service: 'Chăm sóc da mặt', status: 'Hoàn thành' },
    ],
    adminStatus: 'cancelled',
  },
  {
    id: 14,
    date: '12 Tháng 5, 2025',
    time: '14:00',
    service: 'Massage Thái',
    duration: 90,
    therapist: 'Trần Văn B',
    status: 'cancelled',
    adminId: '14',
    customerId: '114',
    customerName: 'Trịnh Quốc Toàn',
    customerAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-8.jpg',
    customerType: 'Khách hàng tiềm năng',
    customerPhone: '0909 888 777',
    customerEmail: 'toan.tq@email.com',
    customerUsageCount: 2,
    serviceId: '14',
    servicePrice: 750000,
    additionalServiceName: 'Không',
    additionalServicePrice: 0,
    notes: 'Khách hàng muốn massage Thái.',
    staffId: '14',
    staffName: 'Nguyễn Văn Toàn',
    staffAvatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-8.jpg',
    staffRole: 'Chuyên viên massage',
    staffExperience: 2,
    staffSpecialty: 'Massage Thái',
    totalPrice: 750000,
    history: [
      { date: '10/05/2025', service: 'Massage body', status: 'Hoàn thành' },
    ],
    adminStatus: 'cancelled',
  },
];

// Hàm chuyển đổi định dạng ngày từ "DD Tháng MM, YYYY" sang Date object
export function parseVietnameseDate(dateStr: string): Date {
  const parts = dateStr.match(/(\d{1,2}) Tháng (\d{1,2}), (\d{4})/);
  if (!parts) return new Date(NaN);
  const day = parseInt(parts[1], 10);
  const month = parseInt(parts[2], 10) - 1;
  const year = parseInt(parts[3], 10);
  return new Date(year, month, day);
}

// Hàm kiểm tra status của appointment dựa trên ngày hiện tại
export function getAppointmentStatus(appointment: AppointmentData): 'upcoming' | 'past' | 'cancelled' {
  let appointmentDateTime: Date;
  // Nếu là dạng yyyy-mm-dd thì parse trực tiếp
  if (/^\d{4}-\d{2}-\d{2}$/.test(appointment.date)) {
    appointmentDateTime = new Date(appointment.date + 'T' + (appointment.time || '00:00'));
  } else {
    appointmentDateTime = parseVietnameseDate(appointment.date);
    const [hour, minute] = appointment.time.split(':').map(Number);
    appointmentDateTime.setHours(hour);
    appointmentDateTime.setMinutes(minute);
  }
  const now = new Date();
  if (appointment.status === 'cancelled') {
    return 'cancelled';
  }
  if (appointmentDateTime < now) {
    return 'past';
  }
  return 'upcoming';
}

// Hàm lấy danh sách appointment theo trạng thái
export function getAppointmentsByStatus(status: 'upcoming' | 'past' | 'cancelled'): AppointmentData[] {
  return appointmentsData.filter(a => getAppointmentStatus(a) === status);
}

// Hàm lấy appointment theo id
export function getAppointmentById(id: number): AppointmentData | undefined {
  // First check the static appointments
  const staticAppointment = appointmentsData.find(a => a.id === id);
  if (staticAppointment) {
    return staticAppointment;
  }

  // If not found in static data, check userAppointments in localStorage
  const userAppointments = JSON.parse(localStorage.getItem('userAppointments') || '[]');
  const userAppointment = userAppointments.find((a: AppointmentData) => a.id === id);
  
  if (userAppointment) {
    return {
      ...userAppointment,
      status: getAppointmentStatus(userAppointment)
    };
  }

  return undefined;
}
