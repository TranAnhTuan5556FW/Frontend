export interface Invoice {
  date: string;
  service: string;
  amount: number;
  status: 'paid' | 'pending';
  paymentMethod: '' | 'Tiền mặt' | 'Chuyển khoản' | 'Ví điện tử';
}

export const invoiceData: Invoice[] = [
  {
    date: '2025-05-15',
    service: 'Massage Thụy Điển',
    amount: 85000,
    status: 'pending',
    paymentMethod: '',
  },
  {
    date: '2025-05-10',
    service: 'Massage mô sâu',
    amount: 95000,
    status: 'paid',
    paymentMethod: 'Ví điện tử',
  },
  {
    date: '2025-05-05',
    service: 'Liệu pháp hương thơm',
    amount: 75000,
    status: 'paid',
    paymentMethod: 'Tiền mặt',
  },
  // 6 invoice mới
  {
    date: '2025-04-28',
    service: 'Massage đá nóng',
    amount: 105000,
    status: 'paid',
    paymentMethod: 'Chuyển khoản',
  },
  {
    date: '2025-04-20',
    service: 'Chăm sóc da mặt',
    amount: 65000,
    status: 'pending',
    paymentMethod: '',
  },
  {
    date: '2025-04-15',
    service: 'Massage Thái',
    amount: 120000,
    status: 'paid',
    paymentMethod: 'Chuyển khoản',
  },
  {
    date: '2025-04-10',
    service: 'Massage chân',
    amount: 55000,
    status: 'pending',
    paymentMethod: '',
  },
  {
    date: '2025-04-05',
    service: 'Liệu pháp đá muối',
    amount: 115000,
    status: 'paid',
    paymentMethod: 'Ví điện tử',
  },
  {
    date: '2025-03-30',
    service: 'Massage thư giãn',
    amount: 80000,
    status: 'paid',
    paymentMethod: 'Tiền mặt',
  },
  // Thêm các hóa đơn khác nếu cần
];
