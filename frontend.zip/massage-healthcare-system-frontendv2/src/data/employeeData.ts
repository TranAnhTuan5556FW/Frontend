export interface Employee {
  id: number;
  name: string;
  avatar: string;
  position: string;
  status: string;
  phone: string;
  email: string;
  address: string;
  skills: string[];
  birthDate: string;
  experience: number;
  stats: {
    hours: string;
    customers: number;
    rating: string;
  };
  schedule: {
    day: string;
    shift: string;
    time: string;
  }[];
}

export const employeeData: Employee[] = [
  {
    id: 1,
    name: 'Nguyễn Thị Mai',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg',
    position: 'Massage Therapist',
    status: 'Đang làm việc',
    phone: '0987654321',
    email: 'mai.nguyen@example.com',
    address: '123 Đường ABC, Quận 1, TP.HCM',
    skills: ['Swedish', 'Thai', 'Sports', 'Head & Shoulder'],
    birthDate: '15/08/1990',
    experience: 5,
    stats: {
      hours: '176h',
      customers: 127,
      rating: '4.8/5'
    },
    schedule: [
      { day: 'T2', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T3', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T4', shift: 'Nghỉ', time: '' },
      { day: 'T5', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T6', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T7', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'CN', shift: 'Nghỉ', time: '' }
    ]
  },
  {
    id: 2,
    name: 'Trần Văn Hùng',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    position: 'Quản lý',
    status: 'Đang làm việc',
    phone: '0912345678',
    email: 'hung.tran@example.com',
    address: '456 Đường DEF, Quận 3, TP.HCM',
    skills: ['Quản lý', 'Đào tạo'],
    birthDate: '22/05/1988',
    experience: 7,
    stats: {
      hours: '180h',
      customers: 98,
      rating: '4.7/5'
    },
    schedule: [
      { day: 'T2', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T3', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T4', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T5', shift: 'Nghỉ', time: '' },
      { day: 'T6', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T7', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'CN', shift: 'Nghỉ', time: '' }
    ]
  },
  {
    id: 3,
    name: 'Phạm Thị Hoa',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-6.jpg',
    position: 'Lễ tân',
    status: 'Nghỉ phép',
    phone: '0977123456',
    email: 'hoa.pham@example.com',
    address: '789 Đường XYZ, Quận 5, TP.HCM',
    skills: ['CSKH', 'Đặt lịch'],
    birthDate: '10/12/1995',
    experience: 3,
    stats: {
      hours: '120h',
      customers: 80,
      rating: '4.6/5'
    },
    schedule: [
      { day: 'T2', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T3', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T4', shift: 'Nghỉ', time: '' },
      { day: 'T5', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T6', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T7', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'CN', shift: 'Nghỉ', time: '' }
    ]
  },
  {
    id: 4,
    name: 'Lê Văn Bình',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-3.jpg',
    position: 'Massage Therapist',
    status: 'Đang làm việc',
    phone: '0911223344',
    email: 'binh.le@example.com',
    address: '12 Trần Hưng Đạo, Quận 1, TP.HCM',
    skills: ['Deep Tissue', 'Hot Stone', 'Spine Therapy', 'Oriental Therapy'],
    birthDate: '02/07/1985',
    experience: 8,
    stats: {
      hours: '150h',
      customers: 110,
      rating: '4.7/5'
    },
    schedule: [
      { day: 'T2', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T3', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T4', shift: 'Nghỉ', time: '' },
      { day: 'T5', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T6', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T7', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'CN', shift: 'Nghỉ', time: '' }
    ]
  },
  {
    id: 5,
    name: 'Phạm Thị Hằng',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-4.jpg',
    position: 'Lễ tân',
    status: 'Đang làm việc',
    phone: '0933445566',
    email: 'hang.pham@example.com',
    address: '34 Lý Thường Kiệt, Quận 10, TP.HCM',
    skills: ['CSKH', 'Đặt lịch'],
    birthDate: '30/09/1992',
    experience: 2,
    stats: {
      hours: '100h',
      customers: 70,
      rating: '4.5/5'
    },
    schedule: [
      { day: 'T2', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T3', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T4', shift: 'Nghỉ', time: '' },
      { day: 'T5', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T6', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T7', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'CN', shift: 'Nghỉ', time: '' }
    ]
  },
  {
    id: 6,
    name: 'Nguyễn Văn Toàn',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-5.jpg',
    position: 'Quản lý',
    status: 'Nghỉ phép',
    phone: '0909888777',
    email: 'toan.nguyen@example.com',
    address: '90 Hoàng Văn Thụ, Quận Phú Nhuận, TP.HCM',
    skills: ['Swedish', 'Aromatherapy', 'Lymphatic', 'Prenatal'],
    birthDate: '18/06/1993',
    experience: 4,
    stats: {
      hours: '140h',
      customers: 85,
      rating: '4.6/5'
    },
    schedule: [
      { day: 'T2', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T3', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T4', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T5', shift: 'Nghỉ', time: '' },
      { day: 'T6', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T7', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'CN', shift: 'Nghỉ', time: '' }
    ]
  },
  {
    id: 7,
    name: 'Đỗ Minh Quân',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-7.jpg',
    position: 'Massage Therapist',
    status: 'Đang làm việc',
    phone: '0911555777',
    email: 'quan.do@example.com',
    address: '78 Phan Đăng Lưu, Quận Bình Thạnh, TP.HCM',
    skills: ['Swedish', 'Aromatherapy', 'Reflexology', 'Facial'],
    birthDate: '25/03/1987',
    experience: 6,
    stats: {
      hours: '160h',
      customers: 120,
      rating: '4.8/5'
    },
    schedule: [
      { day: 'T2', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T3', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T4', shift: 'Nghỉ', time: '' },
      { day: 'T5', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T6', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T7', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'CN', shift: 'Nghỉ', time: '' }
    ]
  },
  {
    id: 8,
    name: 'Trịnh Quốc Hùng',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-8.jpg',
    position: 'Massage Therapist',
    status: 'Đang làm việc',
    phone: '0933666999',
    email: 'hung.trinh@example.com',
    address: '101 Nguyễn Đình Chiểu, Quận 3, TP.HCM',
    skills: ['Hot Stone', 'Deep Tissue', 'Reflexology', 'Facial'],
    birthDate: '05/01/1990',
    experience: 3,
    stats: {
      hours: '130h',
      customers: 95,
      rating: '4.7/5'
    },
    schedule: [
      { day: 'T2', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T3', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T4', shift: 'Nghỉ', time: '' },
      { day: 'T5', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T6', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T7', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'CN', shift: 'Nghỉ', time: '' }
    ]
  },
  {
    id: 9,
    name: 'Lý Thị Hồng',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-9.jpg',
    position: 'Lễ tân',
    status: 'Nghỉ phép',
    phone: '0965432198',
    email: 'hong.ly@example.com',
    address: '789 Nguyễn Thị Thập, Quận 7, TP.HCM',
    skills: ['CSKH', 'Đặt lịch'],
    birthDate: '10/12/1995',
    experience: 1,
    stats: {
      hours: '90h',
      customers: 60,
      rating: '4.4/5'
    },
    schedule: [
      { day: 'T2', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T3', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T4', shift: 'Nghỉ', time: '' },
      { day: 'T5', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'T6', shift: 'Ca chiều', time: '14:00-22:00' },
      { day: 'T7', shift: 'Ca sáng', time: '8:00-14:00' },
      { day: 'CN', shift: 'Nghỉ', time: '' }
    ]
  }
];
