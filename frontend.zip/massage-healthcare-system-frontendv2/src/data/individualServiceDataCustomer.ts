export interface Service {
  id: number;
  name: string;
  prices: {
    [key: string]: number;
  };
  duration: string;
  description: string;
  rating: number;
  reviews: number;
  image: string;
  tag?: 'popular' | 'special';
  category: 'relaxation' | 'therapeutic' | 'specialty' | 'beauty';
  benefits: string[];
  therapists: {
    id: number;
    name: string;
    experience: string;
    image: string;
  }[];
  room: 'VIP' | 'Trị liệu' | 'Spa';
  staff: number;
  status: 'active' | 'inactive';
  requiredSkills: string[];
  statistics: {
    orders: number;
    positiveRate: string;
    frequentCustomers: number;
    avgRating: string;
  };
}

export const services: Service[] = [
  {
    id: 1,
    name: 'Massage Thụy Điển',
    prices: {
      '60': 850000,
      '90': 1200000,
      '120': 1500000
    },
    duration: '60 phút',
    description: 'Trải nghiệm sự thư giãn tuyệt đối với massage Thụy Điển đặc trưng của chúng tôi. Kỹ thuật cổ điển này sử dụng các động tác vuốt ve nhẹ nhàng để thúc đẩy thư giãn, giảm căng cơ và cải thiện tuần hoàn.',
    rating: 4.9,
    reviews: 128,
    image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/701deccdf7-3aefa1001a97b85ccb8e.png',
    tag: 'popular',
    category: 'relaxation',
    benefits: [
      'Giảm căng thẳng và lo âu',
      'Cải thiện tuần hoàn máu',
      'Giảm đau cơ',
      'Cải thiện giấc ngủ'
    ],
    therapists: [
      {
        id: 1,
        name: 'Emma White',
        experience: '5 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg'
      },
      {
        id: 2,
        name: 'John Smith',
        experience: '8 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg'
      }
    ],
    room: 'VIP',
    staff: 1,
    status: 'active',
    requiredSkills: ['Swedish'],
    statistics: {
      orders: 128,
      positiveRate: '98%',
      frequentCustomers: 30,
      avgRating: '4.9/5'
    }
  },
  {
    id: 2,
    name: 'Massage Mô Sâu',
    prices: {
      '60': 950000,
      '90': 1400000,
      '120': 1800000
    },
    duration: '90 phút',
    description: 'Áp lực tập trung để giải phóng căng cơ mãn tính và xử lý các vùng có vấn đề cụ thể. Phù hợp cho người thường xuyên tập thể thao hoặc làm việc văn phòng.',
    rating: 4.8,
    reviews: 96,
    image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/3524fe54de-f92fb73294fbcb96024b.png',
    category: 'therapeutic',
    benefits: [
      'Giảm đau cơ mãn tính',
      'Cải thiện tầm vận động',
      'Phục hồi chấn thương',
      'Tăng cường lưu thông máu'
    ],
    therapists: [
      {
        id: 3,
        name: 'David Chen',
        experience: '10 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-3.jpg'
      },
      {
        id: 4,
        name: 'Sarah Johnson',
        experience: '7 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-4.jpg'
      }
    ],
    room: 'Trị liệu',
    staff: 1,
    status: 'active',
    requiredSkills: ['Deep Tissue'],
    statistics: {
      orders: 96,
      positiveRate: '95%',
      frequentCustomers: 25,
      avgRating: '4.8/5'
    }
  },
  {
    id: 3,
    name: 'Massage Đá Nóng',
    prices: {
      '60': 1100000,
      '90': 1600000,
      '120': 2000000
    },
    duration: '90 phút',
    description: 'Kết hợp đá nóng với các động tác massage để thư giãn cơ sâu và chữa lành. Nhiệt từ đá giúp thư giãn cơ và cải thiện tuần hoàn máu.',
    rating: 4.9,
    reviews: 84,
    image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/01558a44ac-5e36b4be9cd5de7d625b.png',
    tag: 'special',
    category: 'specialty',
    benefits: [
      'Thư giãn cơ sâu',
      'Giảm đau nhức',
      'Cải thiện giấc ngủ',
      'Detox cơ thể'
    ],
    therapists: [
      {
        id: 5,
        name: 'Maria Garcia',
        experience: '6 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-5.jpg'
      },
      {
        id: 6,
        name: 'Michael Lee',
        experience: '9 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-6.jpg'
      }
    ],
    room: 'VIP',
    staff: 1,
    status: 'active',
    requiredSkills: ['Hot Stone'],
    statistics: {
      orders: 84,
      positiveRate: '97%',
      frequentCustomers: 20,
      avgRating: '4.9/5'
    }
  },
  {
    id: 4,
    name: 'Massage Thể Thao',
    prices: {
      '60': 950000,
      '90': 1400000,
      '120': 1800000
    },
    duration: '60 phút',
    description: 'Massage chuyên biệt cho vận động viên và người hoạt động thể chất. Hỗ trợ phục hồi và nâng cao hiệu suất.',
    rating: 4.7,
    reviews: 62,
    image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/9f788d1b4f-8f85bc7641e04e2236a8.png',
    category: 'therapeutic',
    benefits: [
      'Tăng cường phục hồi cơ bắp',
      'Cải thiện hiệu suất thể thao',
      'Phòng ngừa chấn thương',
      'Giảm đau nhức sau tập luyện'
    ],
    therapists: [
      {
        id: 7,
        name: 'Alex Thompson',
        experience: '8 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-7.jpg'
      },
      {
        id: 8,
        name: 'Jessica Lee',
        experience: '6 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-8.jpg'
      }
    ],
    room: 'Trị liệu',
    staff: 1,
    status: 'active',
    requiredSkills: ['Sports'],
    statistics: {
      orders: 62,
      positiveRate: '94%',
      frequentCustomers: 15,
      avgRating: '4.7/5'
    }
  },
  {
    id: 5,
    name: 'Massage Tiền Sản',
    prices: {
      '60': 1100000,
      '90': 1500000,
      '120': 1900000
    },
    duration: '75 phút',
    description: 'Massage được thiết kế đặc biệt cho các bà mẹ đang mang thai. Chăm sóc an toàn và nhẹ nhàng.',
    rating: 4.9,
    reviews: 45,
    image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/fc3e2372a3-84e11ee7bd2032d66007.png',
    category: 'specialty',
    benefits: [
      'Giảm đau lưng và mỏi chân',
      'Cải thiện giấc ngủ',
      'Giảm căng thẳng',
      'An toàn cho mẹ và bé'
    ],
    therapists: [
      {
        id: 9,
        name: 'Lisa Chen',
        experience: '10 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-9.jpg'
      },
      {
        id: 10,
        name: 'Emily Wang',
        experience: '7 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-10.jpg'
      }
    ],
    room: 'VIP',
    staff: 1,
    status: 'active',
    requiredSkills: ['Prenatal'],
    statistics: {
      orders: 45,
      positiveRate: '98%',
      frequentCustomers: 10,
      avgRating: '4.9/5'
    }
  },
  {
    id: 6,
    name: 'Massage Tinh Dầu',
    prices: {
      '60': 1150000,
      '90': 1650000,
      '120': 2100000
    },
    duration: '75 phút',
    description: 'Massage kết hợp tinh dầu thiên nhiên để thư giãn tối đa và mang lại lợi ích trị liệu.',
    rating: 4.8,
    reviews: 73,
    image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/882c98a6c2-f066644050174a360b51.png',
    category: 'relaxation',
    benefits: [
      'Thư giãn sâu với tinh dầu',
      'Detox và làm đẹp da',
      'Cải thiện tâm trạng',
      'Giảm căng thẳng'
    ],
    therapists: [
      {
        id: 11,
        name: 'Sophie Kim',
        experience: '9 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-11.jpg'
      },
      {
        id: 12,
        name: 'Anna Park',
        experience: '5 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-12.jpg'
      }
    ],
    room: 'VIP',
    staff: 1,
    status: 'active',
    requiredSkills: ['Aromatherapy'],
    statistics: {
      orders: 73,
      positiveRate: '96%',
      frequentCustomers: 18,
      avgRating: '4.8/5'
    }
  },
  {
    id: 7,
    name: 'Massage Chân Đông Y',
    prices: {
      '30': 450000,
      '45': 650000,
      '60': 850000
    },
    duration: '45 phút',
    description: 'Kết hợp kỹ thuật bấm huyệt và massage chân truyền thống, giúp cải thiện tuần hoàn và giảm mệt mỏi cho đôi chân của bạn.',
    rating: 4.8,
    reviews: 92,
    image: 'https://hoamoctamanspa.vn/wp-content/uploads/2023/04/dia-chi-massage-chan-dong-y-3.jpg',
    category: 'therapeutic',
    benefits: [
      'Kích thích các huyệt đạo',
      'Giảm mệt mỏi chân',
      'Cải thiện giấc ngủ',
      'Tăng cường tuần hoàn máu'
    ],
    therapists: [
      {
        id: 13,
        name: 'Lucy Zhang',
        experience: '12 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-13.jpg'
      },
      {
        id: 14,
        name: 'Tom Wang',
        experience: '8 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-14.jpg'
      }
    ],
    room: 'Trị liệu',
    staff: 1,
    status: 'active',
    requiredSkills: ['Reflexology'],
    statistics: {
      orders: 92,
      positiveRate: '95%',
      frequentCustomers: 22,
      avgRating: '4.8/5'
    }
  },
  {
    id: 8,
    name: 'Massage Đầu & Vai Gáy',
    prices: {
      '30': 500000,
      '45': 700000,
      '60': 900000
    },
    duration: '45 phút',
    description: 'Tập trung vào vùng đầu, cổ và vai gáy - nơi thường xuyên tích tụ căng thẳng nhất, đặc biệt phù hợp cho dân văn phòng.',
    rating: 4.9,
    reviews: 108,
    image: 'https://daythammy.com/wp-content/uploads/2024/09/co-vai-gay20.png',
    tag: 'popular',
    category: 'relaxation',
    benefits: [
      'Giảm đau đầu',
      'Thư giãn cổ vai gáy',
      'Giảm căng thẳng',
      'Cải thiện tập trung'
    ],
    therapists: [
      {
        id: 15,
        name: 'Helen Tran',
        experience: '6 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-15.jpg'
      },
      {
        id: 16,
        name: 'Kevin Nguyen',
        experience: '9 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-16.jpg'
      }
    ],
    room: 'VIP',
    staff: 1,
    status: 'active',
    requiredSkills: ['Head & Shoulder'],
    statistics: {
      orders: 108,
      positiveRate: '98%',
      frequentCustomers: 25,
      avgRating: '4.9/5'
    }
  },
  {
    id: 9,
    name: 'Massage Trị Liệu Cột Sống',
    prices: {
      '60': 1200000,
      '90': 1700000,
      '120': 2200000
    },
    duration: '90 phút',
    description: 'Chương trình massage chuyên sâu tập trung vào cột sống, giúp giảm đau lưng mãn tính và cải thiện tư thế.',
    rating: 4.9,
    reviews: 76,
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrK23X0q6CQW8UnXJir9YEQc57yYnMbrEeRA&s',
    tag: 'special',
    category: 'therapeutic',
    benefits: [
      'Giảm đau cột sống',
      'Cải thiện tư thế',
      'Tăng linh hoạt',
      'Phục hồi chức năng'
    ],
    therapists: [
      {
        id: 17,
        name: 'Dr. James Wilson',
        experience: '15 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-17.jpg'
      },
      {
        id: 18,
        name: 'Mary Anderson',
        experience: '11 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-18.jpg'
      }
    ],
    room: 'Trị liệu',
    staff: 1,
    status: 'active',
    requiredSkills: ['Spine Therapy'],
    statistics: {
      orders: 76,
      positiveRate: '97%',
      frequentCustomers: 18,
      avgRating: '4.9/5'
    }
  },
  {
    id: 10,
    name: 'Massage Trẻ Hóa Da Mặt',
    prices: {
      '45': 850000,
      '60': 1100000,
      '90': 1600000
    },
    duration: '60 phút',
    description: 'Kết hợp các kỹ thuật massage mặt với tinh chất dưỡng da cao cấp, giúp làn da trẻ hóa và rạng rỡ tự nhiên.',
    rating: 4.8,
    reviews: 64,
    image: 'https://drbelter.com.vn/wp-content/uploads/2019/04/cach-massage-dau-tri-mat-ngu-ft800-2.jpg',
    category: 'beauty',
    benefits: [
      'Làm mờ nếp nhăn',
      'Tăng độ đàn hồi',
      'Cải thiện làn da',
      'Giảm quầng thâm mắt'
    ],
    therapists: [
      {
        id: 19,
        name: 'Linda Kim',
        experience: '7 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-19.jpg'
      },
      {
        id: 20,
        name: 'Susan Park',
        experience: '9 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-20.jpg'
      }
    ],
    room: 'Spa',
    staff: 1,
    status: 'active',
    requiredSkills: ['Facial'],
    statistics: {
      orders: 64,
      positiveRate: '95%',
      frequentCustomers: 15,
      avgRating: '4.8/5'
    }
  },
  {
    id: 11,
    name: 'Massage Thải Độc Lymph',
    prices: {
      '60': 1300000,
      '90': 1800000,
      '120': 2300000
    },
    duration: '90 phút',
    description: 'Kỹ thuật massage nhẹ nhàng giúp kích thích hệ bạch huyết, tăng cường khả năng đào thải độc tố và cải thiện hệ miễn dịch.',
    rating: 4.7,
    reviews: 58,
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT--hwNbAUjWr53pjJHaBQM84xwIrb80wBTcw&s',
    category: 'specialty',
    benefits: [
      'Tăng cường miễn dịch',
      'Giảm phù nề',
      'Detox cơ thể',
      'Cải thiện tuần hoàn'
    ],
    therapists: [
      {
        id: 21,
        name: 'Rachel Green',
        experience: '10 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-21.jpg'
      },
      {
        id: 22,
        name: 'Patricia Lee',
        experience: '8 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-22.jpg'
      }
    ],
    room: 'VIP',
    staff: 1,
    status: 'active',
    requiredSkills: ['Lymphatic'],
    statistics: {
      orders: 58,
      positiveRate: '94%',
      frequentCustomers: 12,
      avgRating: '4.7/5'
    }
  },
  {
    id: 12,
    name: 'Massage Trị Liệu Đông Y',
    prices: {
      '60': 1100000,
      '90': 1600000,
      '120': 2000000
    },
    duration: '90 phút',
    description: 'Kết hợp các phương pháp trị liệu cổ truyền như bấm huyệt, giác hơi và massage với tinh dầu thảo dược.',
    rating: 4.8,
    reviews: 82,
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRudWf-JM_e7EPd48WT6QNEewQ3GdE18FUqoQ&s',
    category: 'therapeutic',
    benefits: [
      'Cân bằng khí huyết',
      'Giảm đau nhức',
      'Tăng cường sức khỏe',
      'Cải thiện giấc ngủ'
    ],
    therapists: [
      {
        id: 23,
        name: 'Master Wong',
        experience: '20 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-23.jpg'
      },
      {
        id: 24,
        name: 'Dr. Liu Chen',
        experience: '15 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-24.jpg'
      }
    ],
    room: 'Trị liệu',
    staff: 1,
    status: 'active',
    requiredSkills: ['Oriental Therapy'],
    statistics: {
      orders: 82,
      positiveRate: '96%',
      frequentCustomers: 20,
      avgRating: '4.8/5'
    }
  }
];
