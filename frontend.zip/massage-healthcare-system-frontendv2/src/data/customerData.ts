// Sample customer data
export interface MembershipInfo {
  tier: string;
  points: number;
  discount: string;
  expiryDate: string;
}

export interface HealthNote {
  note: string;
  type: 'warning' | 'info';
  updatedAt: string;
}

export interface ServiceHistory {
  id: string;
  serviceName: string;
  date: string;
  duration: string;
  price: string;
  staff: string;
  icon: string;
}

export interface Appointment {
  id: string;
  serviceName: string;
  date: string;
  time: string;
  duration: string;
}

export interface Customer {
  id: string;
  name: string;
  avatar: string;
  phone: string;
  email: string;
  group: string;
  membershipTier: string;
  frequency: string;
  spending: string;
  birthDate: string;
  gender: string;
  address: string;
  joinDate: string;
  membershipInfo: MembershipInfo;
  healthNotes: HealthNote[];
  serviceHistory: ServiceHistory[];
  upcomingAppointments: Appointment[];
}

export const customers: Customer[] = [
  {
    id: '1',
    name: 'Nguyễn Thị Anh',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg',
    phone: '0912345678',
    email: 'anh.nt@email.com',
    group: 'VIP',
    membershipTier: 'VIP Gold',
    frequency: '2-3 lần/tuần',
    spending: '5,000,000đ',
    birthDate: '15/08/1990',
    gender: 'Nữ',
    address: '123 Nguyễn Văn Linh, Q.7, TP.HCM',
    joinDate: '01/01/2025',
    membershipInfo: {
      tier: 'VIP Gold',
      points: 2450,
      discount: '15%',
      expiryDate: '31/12/2025',
    },
    healthNotes: [
      {
        note: 'Dị ứng với tinh dầu hoa nhài',
        type: 'warning',
        updatedAt: '10/04/2025',
      },
      {
        note: 'Cần massage nhẹ vùng vai gáy',
        type: 'info',
        updatedAt: '05/04/2025',
      },
    ],
    serviceHistory: [
      {
        id: 'SH1',
        serviceName: 'Massage Thư giãn toàn thân',
        date: '20/04/2025',
        duration: '90 phút',
        price: '850,000đ',
        staff: 'Lan Anh',
        icon: 'faHands',
      },
      {
        id: 'SH2',
        serviceName: 'Chăm sóc da mặt',
        date: '15/04/2025',
        duration: '60 phút',
        price: '650,000đ',
        staff: 'Thanh Thảo',
        icon: 'faSpa',
      },
    ],
    upcomingAppointments: [
      {
        id: 'AP1',
        serviceName: 'Massage Thư giãn',
        date: '25/04/2025',
        time: '15:00',
        duration: '90 phút',
      },
    ],
  },
  {
    id: '2',
    name: 'Trần Văn Bình',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    phone: '0987654321',
    email: 'binh.tv@email.com',
    group: 'Tiềm năng',
    membershipTier: 'Silver',
    frequency: '1 lần/tuần',
    spending: '2,000,000đ',
    birthDate: '22/05/1988',
    gender: 'Nam',
    address: '456 Lê Văn Lương, Q.7, TP.HCM',
    joinDate: '15/02/2025',
    membershipInfo: {
      tier: 'Silver',
      points: 1200,
      discount: '10%',
      expiryDate: '15/02/2026',
    },
    healthNotes: [],
    serviceHistory: [],
    upcomingAppointments: [],
  },
  {
    id: '3',
    name: 'Lê Thị Cúc',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-5.jpg',
    phone: '0965432198',
    email: 'cuc.lt@email.com',
    group: 'Thường',
    membershipTier: 'Basic',
    frequency: '2-3 lần/tháng',
    spending: '1,500,000đ',
    birthDate: '10/12/1995',
    gender: 'Nữ',
    address: '789 Nguyễn Thị Thập, Q.7, TP.HCM',
    joinDate: '01/03/2025',
    membershipInfo: {
      tier: 'Basic',
      points: 500,
      discount: '5%',
      expiryDate: '01/03/2026',
    },
    healthNotes: [],
    serviceHistory: [],
    upcomingAppointments: [],
  },
  {
    id: '4',
    name: 'Phạm Minh Quân',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-3.jpg',
    phone: '0911223344',
    email: 'quan.pm@email.com',
    group: 'VIP',
    membershipTier: 'VIP Gold',
    frequency: '1 lần/tuần',
    spending: '4,200,000đ',
    birthDate: '02/07/1985',
    gender: 'Nam',
    address: '12 Trần Hưng Đạo, Q.1, TP.HCM',
    joinDate: '10/01/2025',
    membershipInfo: {
      tier: 'VIP Gold',
      points: 2000,
      discount: '15%',
      expiryDate: '10/01/2026',
    },
    healthNotes: [
      {
        note: 'Tiền sử đau lưng',
        type: 'info',
        updatedAt: '12/03/2025',
      },
    ],
    serviceHistory: [
      {
        id: 'SH3',
        serviceName: 'Massage Thái',
        date: '18/04/2025',
        duration: '60 phút',
        price: '700,000đ',
        staff: 'Hồng Nhung',
        icon: 'faSpa',
      },
    ],
    upcomingAppointments: [],
  },
  {
    id: '5',
    name: 'Đỗ Thị Hạnh',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-4.jpg',
    phone: '0933445566',
    email: 'hanh.dt@email.com',
    group: 'Tiềm năng',
    membershipTier: 'Silver',
    frequency: '1 lần/tháng',
    spending: '900,000đ',
    birthDate: '30/09/1992',
    gender: 'Nữ',
    address: '34 Lý Thường Kiệt, Q.10, TP.HCM',
    joinDate: '20/03/2025',
    membershipInfo: {
      tier: 'Silver',
      points: 800,
      discount: '10%',
      expiryDate: '20/03/2026',
    },
    healthNotes: [],
    serviceHistory: [
      {
        id: 'SH4',
        serviceName: 'Chăm sóc da mặt',
        date: '05/04/2025',
        duration: '60 phút',
        price: '650,000đ',
        staff: 'Thanh Thảo',
        icon: 'faSpa',
      },
    ],
    upcomingAppointments: [
      {
        id: 'AP2',
        serviceName: 'Massage Thư giãn',
        date: '28/04/2025',
        time: '10:00',
        duration: '90 phút',
      },
    ],
  },
  {
    id: '6',
    name: 'Ngô Văn Lực',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-6.jpg',
    phone: '0977889900',
    email: 'luc.nv@email.com',
    group: 'Thường',
    membershipTier: 'Basic',
    frequency: '1 lần/2 tháng',
    spending: '600,000đ',
    birthDate: '12/11/1980',
    gender: 'Nam',
    address: '56 Nguyễn Tri Phương, Q.5, TP.HCM',
    joinDate: '05/04/2025',
    membershipInfo: {
      tier: 'Basic',
      points: 300,
      discount: '5%',
      expiryDate: '05/04/2026',
    },
    healthNotes: [],
    serviceHistory: [],
    upcomingAppointments: [],
  },
  {
    id: '7',
    name: 'Vũ Thị Mai',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-7.jpg',
    phone: '0911555777',
    email: 'mai.vt@email.com',
    group: 'VIP',
    membershipTier: 'VIP Gold',
    frequency: '3 lần/tháng',
    spending: '6,500,000đ',
    birthDate: '25/03/1987',
    gender: 'Nữ',
    address: '78 Phan Đăng Lưu, Q.Bình Thạnh, TP.HCM',
    joinDate: '15/02/2025',
    membershipInfo: {
      tier: 'VIP Gold',
      points: 3000,
      discount: '15%',
      expiryDate: '15/02/2026',
    },
    healthNotes: [
      {
        note: 'Huyết áp thấp',
        type: 'warning',
        updatedAt: '20/03/2025',
      },
    ],
    serviceHistory: [
      {
        id: 'SH5',
        serviceName: 'Massage đá nóng',
        date: '10/04/2025',
        duration: '90 phút',
        price: '950,000đ',
        staff: 'Minh Tâm',
        icon: 'faHands',
      },
    ],
    upcomingAppointments: [],
  },
  {
    id: '8',
    name: 'Trịnh Quốc Toàn',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-8.jpg',
    phone: '0909888777',
    email: 'toan.tq@email.com',
    group: 'Tiềm năng',
    membershipTier: 'Silver',
    frequency: '2 lần/tháng',
    spending: '1,800,000đ',
    birthDate: '18/06/1993',
    gender: 'Nam',
    address: '90 Hoàng Văn Thụ, Q.Phú Nhuận, TP.HCM',
    joinDate: '22/03/2025',
    membershipInfo: {
      tier: 'Silver',
      points: 950,
      discount: '10%',
      expiryDate: '22/03/2026',
    },
    healthNotes: [],
    serviceHistory: [
      {
        id: 'SH6',
        serviceName: 'Massage Thụy Điển',
        date: '15/04/2025',
        duration: '60 phút',
        price: '750,000đ',
        staff: 'Bích Hạnh',
        icon: 'faSpa',
      },
    ],
    upcomingAppointments: [],
  },
  {
    id: '9',
    name: 'Lý Thị Hồng',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-9.jpg',
    phone: '0933666999',
    email: 'hong.lt@email.com',
    group: 'Thường',
    membershipTier: 'Basic',
    frequency: '1 lần/tháng',
    spending: '800,000đ',
    birthDate: '05/01/1990',
    gender: 'Nữ',
    address: '101 Nguyễn Đình Chiểu, Q.3, TP.HCM',
    joinDate: '01/04/2025',
    membershipInfo: {
      tier: 'Basic',
      points: 400,
      discount: '5%',
      expiryDate: '01/04/2026',
    },
    healthNotes: [],
    serviceHistory: [],
    upcomingAppointments: [],
  },
];

// Membership tiers configuration
export const membershipTiers = {
  'VIP Gold': {
    color: 'from-purple-600 to-blue-600',
    icon: 'faCrown',
    benefits: ['Giảm giá 15%', 'Ưu tiên đặt lịch', 'Tích điểm x2'],
  },
  'Silver': {
    color: 'from-gray-500 to-gray-400',
    icon: 'faStar',
    benefits: ['Giảm giá 10%', 'Tích điểm x1.5'],
  },
  'Basic': {
    color: 'from-blue-400 to-blue-300',
    icon: 'faUser',
    benefits: ['Giảm giá 5%', 'Tích điểm x1'],
  },
};

// Customer group configuration
export const customerGroups = {
  'VIP': {
    badgeColor: 'bg-purple-100 text-purple-700',
  },
  'Tiềm năng': {
    badgeColor: 'bg-blue-100 text-blue-700',
  },
  'Thường': {
    badgeColor: 'bg-gray-100 text-gray-700',
  },
};
