export interface Service {
  id?: number;
  name: string;
  duration: string;
}

export interface Therapist {
  id?: number;
  name: string;
  image: string;
  experience?: string;
}

export interface Package {
  id: number;
  name: string;
  services: Service[];
  prices?: {
    [key: string]: number;
  };
  duration: string;
  description: string;
  rating?: number;
  reviews?: number;
  image: string;
  tag?: string | null;
  category?: string;
  benefits: string[];
  therapists: Therapist[];
  currentPrice?: string | null;
  originalPrice?: string | null;
  soldCount?: number;
  growth?: string | null;
  status?: string;
}

export const allPackages: Package[] = [
  {
    id: 1,
    name: 'Gói Thư Giãn Tuyệt Đối',
    services: [
      { id: 1, name: 'Massage Thụy Điển', duration: '60 phút' },
      { id: 6, name: 'Massage Tinh Dầu', duration: '75 phút' }
    ],
    prices: {
      '135': 1800000
    },
    duration: '135 phút',
    description: 'Kết hợp massage Thụy Điển nhẹ nhàng với massage tinh dầu thiên nhiên, mang đến trạng thái thư giãn sâu và cải thiện tâm trạng. Phù hợp cho những ai cần giải tỏa căng thẳng và tái tạo năng lượng.',
    rating: 4.9,
    reviews: 56,
    image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/701deccdf7-3aefa1001a97b85ccb8e.png',
    tag: 'popular',
    category: 'relaxation',
    benefits: [
      'Thư giãn sâu và giảm căng thẳng',
      'Cải thiện tuần hoàn máu',
      'Làm đẹp da với tinh dầu',
      'Tăng cường giấc ngủ'
    ],
    therapists: [
      {
        id: 1,
        name: 'Emma White',
        experience: '5 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg'
      },
      {
        id: 11,
        name: 'Sophie Kim',
        experience: '9 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-11.jpg'
      }
    ],
    currentPrice: '1,200,000đ',
    originalPrice: '1,500,000đ',
    soldCount: 48,
    growth: '+12%',
    status: 'Đang bán'
  },
  {
    id: 2,
    name: 'Gói Trị Liệu Toàn Diện',
    services: [
      { id: 2, name: 'Massage Mô Sâu', duration: '90 phút' },
      { id: 9, name: 'Massage Trị Liệu Cột Sống', duration: '90 phút' }
    ],
    prices: {
      '180': 2500000
    },
    duration: '180 phút',
    description: 'Gói trị liệu chuyên sâu tập trung vào giảm đau cơ mãn tính và cải thiện tư thế cột sống. Phù hợp cho những người làm việc văn phòng hoặc có vấn đề về lưng và cơ.',
    rating: 4.8,
    reviews: 42,
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrK23X0q6CQW8UnXJir9YEQc57yYnMbrEeRA&s',
    tag: null,
    category: 'therapeutic',
    benefits: [
      'Giảm đau cơ và cột sống',
      'Cải thiện tư thế và tầm vận động',
      'Phục hồi chấn thương',
      'Tăng cường lưu thông máu'
    ],
    therapists: [
      {
        id: 3,
        name: 'David Chen',
        experience: '10 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-3.jpg'
      },
      {
        id: 17,
        name: 'Dr. James Wilson',
        experience: '15 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-17.jpg'
      }
    ],
    currentPrice: '1,800,000đ',
    originalPrice: '2,200,000đ',
    soldCount: 32,
    growth: '+8%',
    status: 'Đang bán'
  },
  {
    id: 3,
    name: 'Gói Làm Đẹp và Thư Giãn',
    services: [
      { id: 10, name: 'Massage Trẻ Hóa Da Mặt', duration: '60 phút' },
      { id: 6, name: 'Massage Tinh Dầu', duration: '75 phút' }
    ],
    prices: {
      '135': 1900000
    },
    duration: '135 phút',
    description: 'Kết hợp massage trẻ hóa da mặt với massage tinh dầu để mang lại làn da rạng rỡ và trạng thái thư giãn tuyệt đối. Lý tưởng cho những ai muốn làm đẹp và thư giãn cùng lúc.',
    rating: 4.8,
    reviews: 38,
    image: 'https://drbelter.com.vn/wp-content/uploads/2019/04/cach-massage-dau-tri-mat-ngu-ft800-2.jpg',
    tag: null,
    category: 'beauty',
    benefits: [
      'Làm mờ nếp nhăn và cải thiện làn da',
      'Thư giãn sâu với tinh dầu',
      'Tăng độ đàn hồi da',
      'Giảm căng thẳng'
    ],
    therapists: [
      {
        id: 19,
        name: 'Linda Kim',
        experience: '7 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-19.jpg'
      },
      {
        id: 11,
        name: 'Sophie Kim',
        experience: '9 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-11.jpg'
      }
    ],
    currentPrice: null,
    originalPrice: null,
    soldCount: 0,
    growth: null,
    status: 'Chưa bán'
  },
  {
    id: 4,
    name: 'Gói Chăm Sóc Đặc Biệt',
    services: [
      { id: 3, name: 'Massage Đá Nóng', duration: '90 phút' },
      { id: 11, name: 'Massage Thải Độc Lymph', duration: '90 phút' }
    ],
    prices: {
      '180': 3000000
    },
    duration: '180 phút',
    description: 'Trải nghiệm sự kết hợp độc đáo giữa massage đá nóng và massage thải độc lymph, giúp thư giãn cơ sâu, đào thải độc tố, và tăng cường hệ miễn dịch.',
    rating: 4.9,
    reviews: 29,
    image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/01558a44ac-5e36b4be9cd5de7d625b.png',
    tag: 'special',
    category: 'specialty',
    benefits: [
      'Thư giãn cơ sâu và giảm đau nhức',
      'Tăng cường miễn dịch',
      'Detox cơ thể',
      'Cải thiện tuần hoàn'
    ],
    therapists: [
      {
        id: 5,
        name: 'Maria Garcia',
        experience: '6 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-5.jpg'
      },
      {
        id: 21,
        name: 'Rachel Green',
        experience: '10 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-21.jpg'
      }
    ],
    currentPrice: null,
    originalPrice: null,
    soldCount: 0,
    growth: null,
    status: 'Chưa bán'
  },
  {
    id: 5,
    name: 'Gói Phục Hồi Năng Lượng',
    services: [
      { id: 7, name: 'Massage Chân Đông Y', duration: '45 phút' },
      { id: 8, name: 'Massage Đầu & Vai Gáy', duration: '45 phút' }
    ],
    prices: {
      '90': 1200000
    },
    duration: '90 phút',
    description: 'Tập trung vào việc phục hồi năng lượng với massage chân Đông Y và massage đầu vai gáy, giúp giảm mệt mỏi và cải thiện tập trung. Phù hợp cho dân văn phòng hoặc người thường xuyên di chuyển.',
    rating: 4.8,
    reviews: 67,
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQG3ocMYlCWnb-VsE271u3dD9PrUpSahKREawJyXDMgQBr8Ng96HQ71K2Llpsd9Vem8EoA&usqp=CAU',
    tag: 'popular',
    category: 'relaxation',
    benefits: [
      'Giảm mệt mỏi chân và vai gáy',
      'Cải thiện tập trung',
      'Kích thích tuần hoàn máu',
      'Giảm căng thẳng'
    ],
    therapists: [
      {
        id: 13,
        name: 'Lucy Zhang',
        experience: '12 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-13.jpg'
      },
      {
        id: 15,
        name: 'Helen Tran',
        experience: '6 năm kinh nghiệm',
        image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-15.jpg'
      }
    ],
    currentPrice: null,
    originalPrice: null,
    soldCount: 0,
    growth: null,
    status: 'Chưa bán'
  }
];

export default allPackages;
