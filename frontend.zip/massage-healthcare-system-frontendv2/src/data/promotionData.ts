export interface PromotionCustomer {
  name: string;
  phone: string;
  avatar: string;
}

export interface PromotionUsageHistory {
  customer: PromotionCustomer;
  service: string;
  date: string;
  time: string;
  orderValue: string;
  discount: string;
  payment: string;
}

export interface PromotionStats {
  usage: number;
  revenue: string;
}

export interface Promotion {
  id: number;
  name: string;
  code: string;
  type: string;
  value: string;
  usageLimit: number;
  used: number;
  status: string;
  statusColor: string;
  startDate: string;
  endDate: string;
  description: string;
  conditions: string[];
  usageHistory: PromotionUsageHistory[];
  stats: PromotionStats;
}

export const promotions: Promotion[] = [
  {
    id: 1,
    name: 'Giảm 50% Massage Body',
    code: 'BODY50',
    type: 'Mã giảm giá',
    value: '50%',
    usageLimit: 200,
    used: 145,
    status: 'Đang chạy',
    statusColor: 'bg-green-100 text-green-700',
    startDate: '01/05/2025',
    endDate: '15/05/2025',
    description: 'Giảm 50% cho dịch vụ massage body. Áp dụng cho khách hàng mới và cũ. Không áp dụng đồng thời với các khuyến mãi khác.',
    conditions: [
      'Áp dụng cho tất cả khách hàng',
      'Mỗi khách hàng chỉ được sử dụng 1 lần',
      'Không áp dụng vào ngày lễ, Tết',
      'Không hoàn tiền nếu không sử dụng hết giá trị'
    ],
    usageHistory: [
      {
        customer: {
          name: 'Nguyễn Thị An',
          phone: '0912345678',
          avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg'
        },
        service: 'Massage Body 90 phút',
        date: '10/05/2025',
        time: '15:30',
        orderValue: '600,000đ',
        discount: '-300,000đ',
        payment: '300,000đ'
      },
      {
        customer: {
          name: 'Trần Văn Bình',
          phone: '0987654321',
          avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg'
        },
        service: 'Massage Body 60 phút',
        date: '09/05/2025',
        time: '10:00',
        orderValue: '400,000đ',
        discount: '-200,000đ',
        payment: '200,000đ'
      }
    ],
    stats: {
      usage: 145,
      revenue: '45,000,000đ'
    }
  },
  {
    id: 2,
    name: 'Voucher 500K',
    code: 'VOUCHER500K',
    type: 'Voucher',
    value: '500,000đ',
    usageLimit: 100,
    used: 89,
    status: 'Đang chạy',
    statusColor: 'bg-green-100 text-green-700',
    startDate: '15/05/2025',
    endDate: '30/05/2025',
    description: 'Voucher giảm trực tiếp 500,000đ cho hóa đơn bất kỳ.',
    conditions: [
      'Áp dụng cho hóa đơn từ 1 triệu đồng',
      'Không áp dụng đồng thời với mã giảm giá khác',
      'Mỗi khách hàng chỉ sử dụng 1 lần'
    ],
    usageHistory: [],
    stats: {
      usage: 89,
      revenue: '44,500,000đ'
    }
  },
  {
    id: 3,
    name: 'Thẻ quà tặng 1 triệu',
    code: 'GIFT1M',
    type: 'Thẻ quà tặng',
    value: '1,000,000đ',
    usageLimit: 50,
    used: 50,
    status: 'Đã kết thúc',
    statusColor: 'bg-red-100 text-red-700',
    startDate: '01/04/2025',
    endDate: '01/05/2025',
    description: 'Tặng thẻ quà tặng trị giá 1 triệu đồng cho khách hàng thân thiết.',
    conditions: [
      'Chỉ áp dụng cho khách hàng VIP',
      'Không quy đổi thành tiền mặt',
      'Không áp dụng đồng thời với các ưu đãi khác'
    ],
    usageHistory: [],
    stats: {
      usage: 50,
      revenue: '50,000,000đ'
    }
  },
  {
    id: 4,
    name: 'Combo Spa Đặc Biệt',
    code: 'COMBO2025',
    type: 'Combo dịch vụ',
    value: '30%',
    usageLimit: 80,
    used: 40,
    status: 'Đang chạy',
    statusColor: 'bg-green-100 text-green-700',
    startDate: '10/05/2025',
    endDate: '31/05/2025',
    description: 'Giảm 30% cho combo 3 dịch vụ bất kỳ trong tháng 5/2025.',
    conditions: [
      'Áp dụng cho combo 3 dịch vụ',
      'Không áp dụng đồng thời với các chương trình khác',
      'Mỗi khách hàng chỉ sử dụng 1 lần'
    ],
    usageHistory: [
      {
        customer: {
          name: 'Lê Thị Hoa',
          phone: '0901234567',
          avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-3.jpg'
        },
        service: 'Combo Massage + Xông hơi + Chăm sóc da',
        date: '12/05/2025',
        time: '14:00',
        orderValue: '1,200,000đ',
        discount: '-360,000đ',
        payment: '840,000đ'
      }
    ],
    stats: {
      usage: 40,
      revenue: '33,600,000đ'
    }
  },
  {
    id: 5,
    name: 'Tặng 1 suất chăm sóc da',
    code: 'FREESKIN',
    type: 'Tặng kèm',
    value: 'Miễn phí 1 lần',
    usageLimit: 120,
    used: 75,
    status: 'Đang chạy',
    statusColor: 'bg-green-100 text-green-700',
    startDate: '05/05/2025',
    endDate: '20/05/2025',
    description: 'Tặng miễn phí 1 lần chăm sóc da mặt cho khách hàng đặt lịch trong thời gian khuyến mãi.',
    conditions: [
      'Áp dụng cho khách hàng đặt lịch trước',
      'Không áp dụng cho khách hàng đã từng sử dụng dịch vụ chăm sóc da',
      'Không quy đổi thành tiền mặt'
    ],
    usageHistory: [
      {
        customer: {
          name: 'Phạm Văn Cường',
          phone: '0978123456',
          avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-4.jpg'
        },
        service: 'Chăm sóc da mặt',
        date: '07/05/2025',
        time: '09:30',
        orderValue: '0đ',
        discount: '0đ',
        payment: '0đ'
      }
    ],
    stats: {
      usage: 75,
      revenue: '0đ'
    }
  },
  {
    id: 6,
    name: 'Ưu đãi thành viên vàng',
    code: 'GOLDMEMBER',
    type: 'Ưu đãi thành viên',
    value: '20%',
    usageLimit: 60,
    used: 55,
    status: 'Đang chạy',
    statusColor: 'bg-green-100 text-green-700',
    startDate: '01/05/2025',
    endDate: '31/05/2025',
    description: 'Giảm 20% cho tất cả dịch vụ dành cho thành viên vàng.',
    conditions: [
      'Chỉ áp dụng cho khách hàng thành viên vàng',
      'Không áp dụng đồng thời với các ưu đãi khác',
      'Không áp dụng cho dịch vụ combo'
    ],
    usageHistory: [],
    stats: {
      usage: 55,
      revenue: '22,000,000đ'
    }
  }
];
