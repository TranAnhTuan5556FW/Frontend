// Dữ liệu mẫu các cấp độ thành viên
export interface MembershipCriteria {
  spending: string;
  frequency: string;
}

export interface Membership {
  id: number;
  name: string;
  type: 'Premium' | 'Advanced' | 'Basic';
  icon: string;
  iconColor: string;
  criteria: MembershipCriteria;
  benefits: string[];
  memberCount: number;
  status: 'active' | 'inactive';
}

const membershipsData: Membership[] = [
  {
    id: 1,
    name: 'Hạng Vàng',
    type: 'Premium',
    icon: 'fa-crown',
    iconColor: 'text-yellow-500',
    criteria: {
      spending: 'Chi tiêu > 50tr/năm',
      frequency: 'Tần suất > 4 lần/tháng'
    },
    benefits: [
      'Giảm giá 20%',
      '1 dịch vụ miễn phí/tháng',
      'Tích điểm x3'
    ],
    memberCount: 156,
    status: 'active'
  },
  {
    id: 2,
    name: 'Hạng Bạc',
    type: 'Advanced',
    icon: 'fa-medal',
    iconColor: 'text-gray-400',
    criteria: {
      spending: 'Chi tiêu > 30tr/năm',
      frequency: 'Tần suất > 2 lần/tháng'
    },
    benefits: [
      'Giảm giá 15%',
      'Tích điểm x2'
    ],
    memberCount: 283,
    status: 'inactive'
  },
  {
    id: 3,
    name: 'Hạng Đồng',
    type: 'Basic',
    icon: 'fa-award',
    iconColor: 'text-amber-700',
    criteria: {
      spending: 'Chi tiêu > 10tr/năm',
      frequency: 'Tần suất > 1 lần/tháng'
    },
    benefits: [
      'Giảm giá 10%',
      'Tích điểm x1'
    ],
    memberCount: 542,
    status: 'active'
  }
];

export default membershipsData;
