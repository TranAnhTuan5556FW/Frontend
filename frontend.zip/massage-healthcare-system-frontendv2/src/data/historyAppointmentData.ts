const mockBookings = [
  {
    id: 1,
    date: "1 Tháng 3, 2025",
    time: "14:00",
    service: "Massage Thụy Điển",
    duration: "60 phút",
    therapist: "Emma Wilson",
    amount: 80,
    status: "completed",
  },
  {
    id: 2,
    date: "15 Tháng 2, 2025",
    time: "15:30",
    service: "Massage Cơ Sâu",
    duration: "90 phút",
    therapist: "Michael Chen",
    amount: 120,
    status: "cancelled",
  },
  {
    id: 3,
    date: "1 Tháng 2, 2025",
    time: "13:00",
    service: "Massage Đá Nóng",
    duration: "75 phút",
    therapist: "Sarah Lee",
    amount: 100,
    status: "rescheduled",
  },
];

export default mockBookings;
