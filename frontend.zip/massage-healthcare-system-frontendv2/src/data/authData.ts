export interface User {
  id: number;
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  role: 'admin' | 'employee' | 'customer';
  dateOfBirth: string;
  gender: 'male' | 'female';
  phoneNumber: string;
  avatar: string;
  createdAt: string;
  lastLogin: string;
  specialization?: string;
  membershipLevel?: 'gold' | 'silver' | 'bronze';
}

export interface Permissions {
  [key: string]: boolean;
}

export interface RolePermissions {
  admin: Permissions;
  employee: Permissions;
  customer: Permissions;
}

export interface AuthResult {
  success: boolean;
  user?: Omit<User, 'password'>;
  permissions?: Permissions;
  message?: string;
}

export interface PasswordValidationResult {
  isValid: boolean;
  message: string;
}

export const users: User[] = [
  {
    id: 1,
    email: "admin@spa.com",
    password: "Admin@123",
    firstName: "Admin",
    lastName: "User",
    role: "admin",
    dateOfBirth: "1990-01-01",
    gender: "male",
    phoneNumber: "0987654321",
    avatar: "https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg",
    createdAt: "2024-01-01",
    lastLogin: "2024-03-20"
  },
  {
    id: 2,
    email: "employee1@spa.com",
    password: "Employee@123",
    firstName: "John",
    lastName: "Smith",
    role: "employee",
    dateOfBirth: "1992-05-15",
    gender: "male",
    phoneNumber: "0987654322",
    avatar: "https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg",
    specialization: "Swedish Massage",
    createdAt: "2024-01-15",
    lastLogin: "2024-03-19"
  },
  {
    id: 3,
    email: "employee2@spa.com",
    password: "Employee@123",
    firstName: "Emma",
    lastName: "Wilson",
    role: "employee",
    dateOfBirth: "1995-08-20",
    gender: "female",
    phoneNumber: "0987654323",
    avatar: "https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-3.jpg",
    specialization: "Deep Tissue Massage",
    createdAt: "2024-01-20",
    lastLogin: "2024-03-20"
  },
  {
    id: 4,
    email: "customer1@example.com",
    password: "Customer@123",
    firstName: "Sarah",
    lastName: "Johnson",
    role: "customer",
    dateOfBirth: "1988-12-10",
    gender: "female",
    phoneNumber: "0987654324",
    avatar: "https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-4.jpg",
    membershipLevel: "gold",
    createdAt: "2024-02-01",
    lastLogin: "2024-03-18"
  },
  {
    id: 5,
    email: "customer2@example.com",
    password: "Customer@123",
    firstName: "Michael",
    lastName: "Brown",
    role: "customer",
    dateOfBirth: "1985-03-25",
    gender: "male",
    phoneNumber: "0987654325",
    avatar: "https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-5.jpg",
    membershipLevel: "silver",
    createdAt: "2024-02-15",
    lastLogin: "2024-03-19"
  }
];

export const rolePermissions: RolePermissions = {
  admin: {
    dashboard: true,
    manageEmployees: true,
    manageCustomers: true,
    manageServices: true,
    manageAppointments: true,
    viewReports: true,
    manageSettings: true,
    accessFinance: true
  },
  employee: {
    dashboard: true,
    viewProfile: true,
    viewSchedule: true,
    manageOwnAppointments: true,
    viewCustomerDetails: true,
    addServiceNotes: true
  },
  customer: {
    viewProfile: true,
    bookAppointments: true,
    viewAppointments: true,
    cancelAppointments: true,
    viewServices: true,
    leaveReviews: true
  }
};

export function validatePassword(password: string): PasswordValidationResult {
  const minLength = 8;
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumbers = /\d/.test(password);
  const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

  const isValid = password.length >= minLength &&
    hasUpperCase &&
    hasLowerCase &&
    hasNumbers &&
    hasSpecialChar;

  if (!isValid) {
    return {
      isValid: false,
      message: "Mật khẩu phải có ít nhất 8 ký tự, bao gồm chữ hoa, chữ thường, số và ký tự đặc biệt"
    };
  }

  return {
    isValid: true,
    message: "Mật khẩu hợp lệ"
  };
}

export function authenticateUser(email: string, password: string): AuthResult {
  const user = users.find(u => u.email === email && u.password === password);
  if (user) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { password, ...userWithoutPassword } = user;
    return {
      success: true,
      user: userWithoutPassword,
      permissions: rolePermissions[user.role],
      message: "Đăng nhập thành công"
    };
  }
  return {
    success: false,
    message: "Email hoặc mật khẩu không chính xác"
  };
}

export function hasPermission(userRole: string, permission: string): boolean {
  return rolePermissions[userRole as keyof RolePermissions]?.[permission] || false;
}

export function getRoleNameVi(role: string): string {
  const roleNames: { [key: string]: string } = {
    admin: "Quản trị viên",
    employee: "Nhân viên",
    customer: "Khách hàng"
  };
  return roleNames[role] || role;
}
