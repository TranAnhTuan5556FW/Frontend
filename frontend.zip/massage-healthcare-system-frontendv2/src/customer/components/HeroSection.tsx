import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const HeroSection: React.FC = () => {
  return (
    <section id="hero" className="pt-24 h-[650px] relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center h-full">
          <motion.div 
            className="z-10"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.h2 
              className="text-5xl font-bold text-gray-800 mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Trải Nghiệm Massage <br />
              <span className="text-[#008080]">Thư Giãn Tuyệt Vời</span>
            </motion.h2>
            
            <motion.p 
              className="text-xl text-gray-600 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              Khám phá các dịch vụ massage chuyên nghiệp của chúng tôi, được thiết kế để mang lại sự thư giãn và phục hồi cho cơ thể và tâm trí của bạn.
            </motion.p>

            <motion.div
              className="flex flex-col sm:flex-row gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
            >
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-[#008080] text-white rounded-lg hover:bg-[#006666] text-lg"
              >
                Đặt Lịch Ngay
              </motion.button>
              <Link to="/services">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-transparent border-2 border-[#008080] text-[#008080] rounded-lg hover:bg-[#008080] hover:text-white text-lg"
                >
                  Xem Dịch Vụ
                </motion.button>
              </Link>
            </motion.div>
          </motion.div>

          <motion.div 
            className="relative"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="relative">
              <motion.img
                src="https://storage.googleapis.com/uxpilot-auth.appspot.com/fccbeceb8e-2a7bdbda0583c5609a84.png"
                alt="Massage thư giãn"
                className="rounded-2xl shadow-2xl w-full h-auto transform hover:scale-105 transition duration-500"
                whileHover={{ scale: 1.02 }}
              />
              <motion.div 
                className="absolute -bottom-6 -right-6 bg-white p-4 rounded-xl shadow-lg"
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.8, duration: 0.5 }}
              >
                <div className="text-[#008080] font-bold text-lg">⭐ 4.9/5</div>
                <div className="text-gray-600 text-sm">Đánh giá từ khách hàng</div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
      <div className="absolute top-0 right-0 w-full h-full bg-[#e6e6fa]/10 -z-10" />
    </section>
  );
};

export default HeroSection; 