import React from 'react';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  totalItems: number;
  itemsPerPage: number;
  onPageChange: (pageNumber: number) => void;
  containerRef?: string;
  itemName?: string;
}

export const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  totalPages,
  totalItems,
  itemsPerPage,
  onPageChange,
  containerRef,
  itemName = 'dịch vụ'
}) => {
  const indexOfFirstItem = (currentPage - 1) * itemsPerPage;
  const indexOfLastItem = Math.min(indexOfFirstItem + itemsPerPage, totalItems);

  const handlePageChange = (pageNum: number) => {
    onPageChange(pageNum);
    if (containerRef) {
      document.getElementById(containerRef)?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {totalPages > 1 && (
        <div className="flex justify-center items-center gap-4 mt-12">
          <button
            className="px-4 py-2 border rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:hover:bg-white"
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
          >
            <i className="fas fa-chevron-left mr-2"></i>
            Trang trước
          </button>
          <div className="flex items-center gap-2">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
              <button
                key={pageNum}
                onClick={() => handlePageChange(pageNum)}
                className={`w-10 h-10 rounded-lg ${
                  pageNum === currentPage
                    ? 'bg-[#008080] text-white'
                    : 'border hover:border-[#008080] hover:text-[#008080]'
                }`}
              >
                {pageNum}
              </button>
            ))}
          </div>
          <button
            className="px-4 py-2 border rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:hover:bg-white"
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
          >
            Trang sau
            <i className="fas fa-chevron-right ml-2"></i>
          </button>
        </div>
      )}

      {/* Results Summary */}
      <div className="text-center text-gray-600 mt-6">
        Hiển thị {indexOfFirstItem + 1}-{indexOfLastItem} trong tổng số {totalItems} {itemName}
      </div>
    </>
  );
};
