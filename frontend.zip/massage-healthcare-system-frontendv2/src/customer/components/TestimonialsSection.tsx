import React from "react";
import { motion } from "framer-motion";

const TestimonialsSection: React.FC = () => (
  <section id="testimonials" className="py-20">
    <div className="container mx-auto px-6">
      <h3 className="text-4xl font-bold text-center mb-16 text-gray-800">Khách hàng nói gì về chúng tôi</h3>
      <div className="grid md:grid-cols-3 gap-8">
        <motion.div
          id="testimonial-1"
          className="bg-white p-8 rounded-xl shadow-lg"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center mb-6">
            <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg" alt="Khách hàng" className="w-16 h-16 rounded-full mr-4" />
            <div>
              <h4 className="font-bold">Sarah Johnson</h4>
              <p className="text-gray-500">Khách hàng thường xuyên</p>
            </div>
          </div>
          <p className="text-gray-600">"Trải nghiệm massage tuyệt vời nhất tôi từng có. Nhân viên chuyên nghiệp, không gian cực kỳ yên tĩnh."</p>
        </motion.div>

        <motion.div
          id="testimonial-2"
          className="bg-white p-8 rounded-xl shadow-lg"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center mb-6">
            <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg" alt="Khách hàng" className="w-16 h-16 rounded-full mr-4" />
            <div>
              <h4 className="font-bold">Michael Chen</h4>
              <p className="text-gray-500">Người yêu thể thao</p>
            </div>
          </div>
          <p className="text-gray-600">"Massage chuyên sâu ở đây giúp tôi cải thiện hiệu suất thể thao và phục hồi nhanh hơn."</p>
        </motion.div>

        <motion.div
          id="testimonial-3"
          className="bg-white p-8 rounded-xl shadow-lg"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center mb-6">
            <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-6.jpg" alt="Khách hàng" className="w-16 h-16 rounded-full mr-4" />
            <div>
              <h4 className="font-bold">Emma Davis</h4>
              <p className="text-gray-500">Khách lần đầu</p>
            </div>
          </div>
          <p className="text-gray-600">"Đặt lịch rất dễ dàng, massage đá nóng thật tuyệt vời. Tôi đã đặt lịch tiếp theo rồi!"</p>
        </motion.div>
      </div>
    </div>
  </section>
);

export default TestimonialsSection; 