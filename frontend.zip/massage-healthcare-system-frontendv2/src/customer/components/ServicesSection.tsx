import React from "react";
import { motion } from "framer-motion";
import '@fortawesome/fontawesome-free/css/all.min.css';

const ServicesSection: React.FC = () => {
  const serviceVariants = {
    hidden: { 
      opacity: 0,
      y: 50
    },
    visible: (index: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: index * 0.2,
        duration: 0.5
      }
    })
  };

  const services = [
    {
      id: 1,
      icon: <i className="fa-solid fa-spa text-[#008080]"></i>,
      title: "Massage Thụy Điển",
      description: "Liệu pháp massage thư giãn cổ điển, kết hợp các động tác vuốt nhẹ nhàng và xoa bóp có nhịp điệu. Phù hợp cho người mới trải nghiệm và giúp giảm căng thẳng hiệu quả.",
      price: "85.000đ",
      duration: "60 phút",
      benefits: ["Giảm căng thẳng", "Cải thiện tuần hoàn", "Thư giãn cơ bắp"]
    },
    {
      id: 2,
      icon: <i className="fa-solid fa-hands text-[#008080]"></i>,
      title: "Massage Chuyên Sâu",
      description: "Kỹ thuật massage tác động sâu vào các lớp cơ, giúp giải tỏa căng cơ và các điểm đau mãn tính. Phù hợp cho người thường xuyên vận động hoặc tập thể thao.",
      price: "95.000đ",
      duration: "60 phút",
      benefits: ["Giảm đau mãn tính", "Phục hồi chấn thương", "Tăng độ linh hoạt"]
    },
    {
      id: 3,
      icon: <i className="fa-solid fa-hot-tub-person text-[#008080]"></i>,
      title: "Massage Đá Nóng",
      description: "Liệu pháp độc đáo kết hợp giữa massage truyền thống và đá nóng, giúp thư giãn sâu và giải tỏa căng thẳng toàn diện. Mang lại trải nghiệm spa cao cấp.",
      price: "110.000đ",
      duration: "75 phút",
      benefits: ["Thư giãn sâu", "Detox cơ thể", "Cải thiện giấc ngủ"]
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Dịch Vụ Của Chúng Tôi
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Khám phá các dịch vụ massage đa dạng của chúng tôi, được thiết kế để mang lại trải nghiệm thư giãn tuyệt vời.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.id}
              custom={index}
              variants={serviceVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              whileHover={{ y: -10 }}
              className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow flex flex-col h-full"
            >
              <div className="text-4xl mb-4">{service.icon}</div>
              <div className="flex-1 flex flex-col">
                <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                <p className="text-gray-600 mb-4 flex-1">{service.description}</p>
                <div className="space-y-2 mb-4">
                  {service.benefits.map((benefit, idx) => (
                    <div key={idx} className="flex items-center text-gray-600">
                      <i className="fa-solid fa-check text-[#008080] mr-2 text-sm"></i>
                      <span className="text-sm">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="mt-2">
                <div className="flex items-center justify-between mb-4">
                  <p className="text-[#008080] font-bold text-xl">{service.price}</p>
                  <p className="text-gray-500 text-sm">
                    <i className="fa-regular fa-clock mr-1"></i>
                    {service.duration}
                  </p>
                </div>
                <button className="w-full py-3 bg-[#008080] text-white rounded-lg hover:bg-[#006666] transition-colors">
                  Đặt Lịch
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;