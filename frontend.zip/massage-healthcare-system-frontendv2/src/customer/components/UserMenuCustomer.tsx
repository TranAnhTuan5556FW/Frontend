import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { 
  FaUser, 
  FaCrown, 
  FaCalendarAlt, 
  FaHistory, 
  FaSignOutAlt, 
  FaFileInvoiceDollar 
} from "react-icons/fa";

const UserMenuCustomer: React.FC = () => {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const user = JSON.parse(localStorage.getItem("user") || "null");

  const handleLogout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("permissions");
    navigate("/");
  };

  if (!user) return null;

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 focus:outline-none"
      >
        <img
          src={user.avatar}
          alt={`${user.firstName} ${user.lastName}`}
          className="w-10 h-10 rounded-full object-cover"
        />
        <span className="text-gray-700">{user.firstName} {user.lastName}</span>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50">
          <div className="px-4 py-2 border-b border-gray-100">
            <p className="text-sm font-medium text-gray-700">{user.firstName} {user.lastName}</p>
            <p className="text-xs text-gray-500">{user.email}</p>
          </div>
          
          <Link
            to="/customer/profile"
            className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            onClick={() => setIsOpen(false)}
          >
            <FaUser className="mr-2" />
            Thông tin cá nhân
          </Link>

          <Link
            to="/customer/membership-rewards"
            className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            onClick={() => setIsOpen(false)}
          >
            <FaCrown className="mr-2 text-yellow-500" />
            Thẻ thành viên
          </Link>
          
          <Link
            to="/customer/appointments"
            className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            onClick={() => setIsOpen(false)}
          >
            <FaCalendarAlt className="mr-2" />
            Lịch hẹn của tôi
          </Link>
          
          <Link
            to="/customer/booking-history"
            className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            onClick={() => setIsOpen(false)}
          >
            <FaHistory className="mr-2" />
            Lịch sử đặt lịch
          </Link>
          
          <Link
            to="/customer/billing"
            className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            onClick={() => setIsOpen(false)}
          >
            <FaFileInvoiceDollar className="mr-2" />
            Thanh toán & Hóa đơn
          </Link>
          
          <button
            onClick={handleLogout}
            className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
          >
            <FaSignOutAlt className="mr-2" />
            Đăng xuất
          </button>
        </div>
      )}
    </div>
  );
};

export default UserMenuCustomer;
