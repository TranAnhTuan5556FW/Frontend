import React from "react";

const CTASection: React.FC = () => (
  <section id="cta" className="py-20 bg-[#008080]">
    <div className="container mx-auto px-6 text-center">
      <h3 className="text-4xl font-bold text-white mb-6">Sẵn sàng thư giãn?</h3>
      <p className="text-white/90 text-xl mb-8">Đặt lịch lần đầu và nhận ngay ưu đãi 15%!</p>
      <button className="px-8 py-4 bg-white text-[#008080] rounded-lg hover:bg-gray-100 text-lg font-bold">
        Đặt lịch ngay
      </button>
    </div>
  </section>
);

export default CTASection; 