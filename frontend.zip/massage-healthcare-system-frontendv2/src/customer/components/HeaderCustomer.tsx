import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import UserMenuCustomer from "./UserMenuCustomer";

const Header: React.FC = () => {
  const location = useLocation();
  const isAuthPage = location.pathname === '/auth';
  const user = JSON.parse(localStorage.getItem("user") || "null");
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleMenuClick = () => {
    setIsMenuOpen(false);
  };

  const handleLogoClick = () => {
    setIsMenuOpen(false);
    window.scrollTo(0, 0);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm shadow-md">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link 
            to="/" 
            onClick={handleLogoClick}
            className="text-2xl font-bold text-[#008080] hover:text-[#006666] transition-colors"
          >
            RelaxEase
          </Link>
          
          {!isAuthPage && (
            <>
              <nav className="hidden md:flex items-center space-x-8">
                <Link to="/" className="text-gray-600 hover:text-[#008080] transition-colors">
                  Trang Chủ
                </Link>
                <Link 
                  to="/services" 
                  className="text-gray-600 hover:text-[#008080] transition-colors"
                  onClick={handleLogoClick}
                >
                  Dịch vụ
                </Link>
                <Link 
                  to="/offer" 
                  className="text-gray-600 hover:text-[#008080] transition-colors"
                  onClick={handleLogoClick}
                >
                  Ưu đãi
                </Link>
                <Link 
                  to="/reviews" 
                  className="text-gray-600 hover:text-[#008080] transition-colors"
                  onClick={handleMenuClick}
                >
                  Đánh giá/Phản hồi
                </Link>
                <Link 
                  to="/about" 
                  className="text-gray-600 hover:text-[#008080] transition-colors"
                  onClick={handleMenuClick}
                >
                  Về Chúng Tôi
                </Link>
                <Link 
                  to="/contact" 
                  className="text-gray-600 hover:text-[#008080] transition-colors"
                  onClick={handleMenuClick}
                >
                  Liên Hệ
                </Link>
              </nav>

              <div className="flex items-center space-x-4">
                {user ? (
                  <UserMenuCustomer />
                ) : (
                  <>
                    <Link to="/auth" className="hidden md:block text-gray-600 hover:text-[#008080] transition-colors">
                      Đăng Nhập
                    </Link>
                    <Link to="/auth?mode=signup" className="hidden md:block bg-[#008080] text-white px-6 py-2 rounded-lg hover:bg-[#006666] transition-colors">
                      Đăng Ký
                    </Link>
                  </>
                )}

                <button
                  onClick={toggleMenu}
                  className="md:hidden text-gray-700 focus:outline-none"
                >
                  <i className={`fa-solid ${isMenuOpen ? 'fa-xmark' : 'fa-bars'} text-xl`}></i>
                </button>
              </div>
            </>
          )}
        </div>

        {!isAuthPage && isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4">
            <div className="flex flex-col space-y-4">
              <Link
                to="/"
                className="text-gray-700 hover:text-[#008080] transition duration-300"
                onClick={handleMenuClick}
              >
                Trang Chủ
              </Link>
              <Link
                to="/services"
                className="text-gray-700 hover:text-[#008080] transition duration-300"
                onClick={handleMenuClick}
              >
                Dịch vụ
              </Link>
              <Link
                to="/offer"
                className="text-gray-700 hover:text-[#008080] transition duration-300"
                onClick={handleMenuClick}
              >
                Ưu đãi
              </Link>
              <Link
                to="/reviews"
                className="text-gray-700 hover:text-[#008080] transition duration-300"
                onClick={handleMenuClick}
              >
                Đánh giá/Phản hồi
              </Link>
              <Link
                to="/about"
                className="text-gray-700 hover:text-[#008080] transition duration-300"
                onClick={handleMenuClick}
              >
                Về Chúng Tôi
              </Link>
              <Link
                to="/contact"
                className="text-gray-700 hover:text-[#008080] transition duration-300"
                onClick={handleMenuClick}
              >
                Liên Hệ
              </Link>
              {!user && (
                <>
                  <Link
                    to="/auth"
                    className="text-gray-700 hover:text-[#008080] transition duration-300"
                    onClick={handleMenuClick}
                  >
                    Đăng Nhập
                  </Link>
                  <Link
                    to="/auth?mode=signup"
                    className="text-gray-700 hover:text-[#008080] transition duration-300"
                    onClick={handleMenuClick}
                  >
                    Đăng Ký
                  </Link>
                </>
              )}
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header; 