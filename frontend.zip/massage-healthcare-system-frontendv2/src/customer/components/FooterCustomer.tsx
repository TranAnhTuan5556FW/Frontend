import React from "react";

const Footer: React.FC = () => (
  <footer id="footer" className="bg-gray-900 text-white py-12">
    <div className="container mx-auto px-6">
      <div className="grid md:grid-cols-4 gap-8">
        <div id="footer-about">
          <h4 className="text-xl font-bold mb-4">RelaxEase</h4>
          <p className="text-gray-400">Đối tác tin cậy của bạn trong lĩnh vực chăm sóc sức khỏe và thư giãn từ năm 2025.</p>
        </div>
        <div id="footer-contact">
          <h4 className="text-xl font-bold mb-4">Liên hệ</h4>
          <p className="text-gray-400">123 Đường Thư Giãn</p>
          <p className="text-gray-400">Thành phố Wellness, WC 12345</p>
          <p className="text-gray-400">Điện thoại: (555) 123-4567</p>
        </div>
        <div id="footer-hours">
          <h4 className="text-xl font-bold mb-4">Giờ làm việc</h4>
          <p className="text-gray-400">Thứ 2 - Thứ 6: 9h - 20h</p>
          <p className="text-gray-400">Thứ 7: 10h - 18h</p>
          <p className="text-gray-400">Chủ nhật: 10h - 16h</p>
        </div>
        <div id="footer-social">
          <h4 className="text-xl font-bold mb-4">Kết nối với chúng tôi</h4>
          <div className="flex space-x-4">
            <a href="#" className="text-gray-400 hover:text-white">
              <i className="fa-brands fa-facebook text-2xl"></i>
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <i className="fa-brands fa-instagram text-2xl"></i>
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <i className="fa-brands fa-twitter text-2xl"></i>
            </a>
          </div>
        </div>
      </div>
      <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
        <p>© 2025 RelaxEase. Đã đăng ký bản quyền.</p>
      </div>
    </div>
  </footer>
);

export default Footer; 