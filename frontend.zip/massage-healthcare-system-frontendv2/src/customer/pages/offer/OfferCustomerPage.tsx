import React, { useEffect } from "react";
import Header from "../../components/HeaderCustomer";
import Footer from "../../components/FooterCustomer";
import { FaBookmark } from "react-icons/fa";

const weeklySpecials = [
  { day: 'Thứ Hai', service: 'Massage Đả Thông', discount: '15% OFF' },
  { day: 'Thứ Ba', service: 'Massage Thụy Điển', discount: '20% OFF' },
  { day: 'Thứ Tư', service: 'Massage Đá Nóng', discount: '25% OFF' },
  { day: 'Thứ Năm', service: 'Liệu Pháp Mùi Hương', discount: '20% OFF' },
  { day: 'Thứ Sáu', service: 'Massage Cặp Đôi', discount: '30% OFF' },
  { day: 'Thứ Bảy', service: 'Tất Cả Dịch Vụ', discount: '10% OFF' },
  { day: 'Chủ Nhật', service: 'Combo Dịch Vụ', discount: '25% OFF' }
];

const currentPromotions = [
  {
    id: 1,
    title: 'Ưu Đãi Cặp Đôi',
    image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/82c1b4adb8-620a12d33d46bdc76e8d.png',
    discount: 'Giảm 25%',
    description: 'Đặt lịch massage cặp đôi và nhận ưu đãi 25% cùng champagne miễn phí.',
    code: 'COUPLE25',
    tagType: 'red'
  },
  {
    id: 2,
    title: 'Gói Chăm Sóc Da',
    image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/38465055aa-7c5a4e0605c21be8c4ac.png',
    discount: 'Combo',
    description: 'Mua 3 buổi chăm sóc da tặng 1 buổi, kèm bộ sản phẩm dưỡng da cao cấp.',
    code: 'FACE4',
    tagType: 'green'
  },
  {
    id: 3,
    title: 'Ưu Đãi Khách Mới',
    image: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/33f801be7f-80f7b6fe603e7499249f.png',
    discount: 'Khách Mới',
    description: 'Khách hàng mới được giảm 20% cho mọi dịch vụ và quà tặng chào mừng.',
    code: 'WELCOME20',
    tagType: 'blue'
  }
];

const getTagColor = (type: string) => {
  switch (type) {
    case 'red':
      return 'bg-red-100 text-red-600';
    case 'green':
      return 'bg-green-100 text-green-600';
    case 'blue':
      return 'bg-blue-100 text-blue-600';
    default:
      return 'bg-gray-100 text-gray-600';
  }
};

const OfferCustomerPage: React.FC = () => {
  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px'
    };

    const observer = new window.IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fade-in');
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);

    document.querySelectorAll('.animate-on-scroll').forEach((element) => {
      observer.observe(element);
    });

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <style>{`
        @keyframes float {
          0% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
          100% { transform: translateY(0px); }
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slideIn {
          from { opacity: 0; transform: translateX(-20px); }
          to { opacity: 1; transform: translateX(0); }
        }
        .animate-fade-in {
          animation: fadeIn 0.8s ease-out forwards;
        }
        .float-animation {
          animation: float 3s ease-in-out infinite;
        }
        .slide-in {
          animation: slideIn 0.5s ease-out forwards;
        }
      `}</style>
      <Header />
      <main className="pt-24">
        <div className="container mx-auto px-6 py-8">
          {/* Tiêu đề khuyến mãi */}
          <section id="promotions-header" className="mb-8 animate-on-scroll opacity-0">
            <div className="flex justify-between items-center">
              <h2 className="text-3xl font-bold text-gray-800">Ưu Đãi & Khuyến Mãi Đặc Biệt</h2>
              <div className="text-right">
                <p className="text-[#008080]">Có hiệu lực đến 30/04/2025</p>
              </div>
            </div>
          </section>

          {/* Khuyến mãi nổi bật */}
          <section id="featured-promotion" className="mb-12 animate-on-scroll opacity-0">
            <div className="bg-gradient-to-r from-[#008080] to-[#006666] rounded-xl overflow-hidden transform transition-transform duration-300 hover:scale-[1.02]">
              <div className="flex flex-col md:flex-row">
                <div className="md:w-1/2 p-8 flex flex-col justify-center">
                  <span className="text-white text-sm mb-2">Ưu Đãi Nổi Bật</span>
                  <h3 className="text-3xl font-bold text-white mb-4">Gói Chăm Sóc Mùa Xuân</h3>
                  <p className="text-white/90 mb-6">Giảm 30% cho các gói massage cao cấp khi đặt lịch trong tháng này!</p>
                  <div className="flex gap-4">
                    <button className="bg-white text-[#008080] px-6 py-3 rounded-lg font-bold transition-all duration-300 hover:bg-gray-100 hover:shadow-lg transform hover:-translate-y-1">
                      Đặt Ngay
                    </button>
                    <button className="border border-white text-white px-6 py-3 rounded-lg font-bold transition-all duration-300 hover:bg-white/10 hover:shadow-lg transform hover:-translate-y-1">
                      Tìm Hiểu Thêm
                    </button>
                  </div>
                </div>
                <div className="md:w-1/2">
                  <img
                    className="h-full w-full object-cover transition-transform duration-700 hover:scale-110"
                    src="https://storage.googleapis.com/uxpilot-auth.appspot.com/6c312c1870-93fe2a61b0f31846da6d.png"
                    alt="Phòng massage cao cấp với nến và hoa"
                  />
                </div>
              </div>
            </div>
          </section>

          {/* Khuyến mãi hiện tại */}
          <section id="current-promotions" className="mb-12 animate-on-scroll opacity-0">
            <h3 className="text-xl font-bold text-gray-800 mb-6">Ưu Đãi Hiện Tại</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {currentPromotions.map((promo, index) => (
                <div
                  key={promo.id}
                  className="bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:shadow-xl hover:-translate-y-2"
                  style={{ animationDelay: `${index * 200}ms` }}
                >
                  <div className="h-48 overflow-hidden">
                    <img
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                      src={promo.image}
                      alt={promo.title}
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <h4 className="font-bold text-lg text-gray-800">{promo.title}</h4>
                      <span className={`${getTagColor(promo.tagType)} px-3 py-1 rounded-full text-sm transform transition-transform hover:scale-105`}>
                        {promo.discount}
                      </span>
                    </div>
                    <p className="text-gray-600 mb-4">{promo.description}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-[#008080] font-bold">{promo.code}</span>
                      <button className="text-[#008080] transition-all duration-300 hover:text-[#006666] transform hover:scale-125">
                        <FaBookmark className="text-xl" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Ưu đãi theo tuần */}
          <section id="weekly-specials" className="mb-12 animate-on-scroll opacity-0">
            <h3 className="text-xl font-bold text-gray-800 mb-6">Ưu Đãi Theo Ngày</h3>
            <div className="grid md:grid-cols-7 gap-4">
              {weeklySpecials.map((day, index) => (
                <div
                  key={index}
                  className="bg-white rounded-xl p-4 shadow-lg text-center transform transition-all duration-300 hover:shadow-xl hover:-translate-y-1 float-animation"
                  style={{
                    animationDelay: `${index * 200}ms`,
                    animationDuration: '3s'
                  }}
                >
                  <h5 className="font-bold text-gray-800 mb-2">{day.day}</h5>
                  <p className="text-sm text-gray-600 mb-2">{day.service}</p>
                  <span className="text-[#008080] font-bold">{day.discount}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Điều khoản và điều kiện */}
          <section id="promo-terms" className="bg-gray-50 rounded-xl p-6 animate-on-scroll opacity-0 transition-all duration-300 hover:shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-4">Điều Khoản & Điều Kiện</h3>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Tất cả khuyến mãi tùy thuộc vào tình trạng còn chỗ</li>
              <li>Không áp dụng đồng thời với các ưu đãi khác</li>
              <li>Chỉ áp dụng cho các dịch vụ và thời gian được chỉ định</li>
              <li>Phải đề cập ưu đãi khi đặt lịch</li>
              <li>Giá và khuyến mãi có thể thay đổi mà không cần báo trước</li>
            </ul>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default OfferCustomerPage;
