import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/HeaderCustomer';
import Footer from '../../components/FooterCustomer';
import { User, validatePassword } from '../../../data/authData';
import { motion, AnimatePresence } from 'framer-motion';

interface UserInfo extends Omit<User, 'password' | 'role' | 'id'> {
  preferredMassageType: string;
  pressurePreference: string;
}

const ProfilePageCustomer: React.FC = () => {
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [passwordFields, setPasswordFields] = useState({
    oldPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [passwordError, setPasswordError] = useState<string>('');
  const [passwordSuccess, setPasswordSuccess] = useState<string>('');
  const [avatarError, setAvatarError] = useState<string>('');
  
  const [userInfo, setUserInfo] = useState<UserInfo>({
    email: '',
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    gender: 'male',
    phoneNumber: '',
    avatar: '',
    createdAt: '',
    lastLogin: '',
    membershipLevel: 'bronze',
    preferredMassageType: 'Massage Thụy Điển',
    pressurePreference: 'Vừa'
  });

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
      navigate('/auth');
      return;
    }

    const user = JSON.parse(storedUser);
    if (user.role !== 'customer') {
      navigate('/');
      return;
    }

    setUserInfo(prev => ({
      ...prev,
      ...user,
      phoneNumber: user.phoneNumber || '',
      preferredMassageType: user.preferredMassageType || 'Massage Thụy Điển',
      pressurePreference: user.pressurePreference || 'Vừa'
    }));
  }, [navigate]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleEditProfile = () => {
    setIsEditing(true);
  };

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};
    
    // Validate email
    if (!/\S+@\S+\.\S+/.test(userInfo.email)) {
      newErrors.email = "Email không hợp lệ";
    }

    // Validate phone number
    const phoneRegex = /(84|0[3|5|7|8|9])+([0-9]{8})\b/;
    if (!phoneRegex.test(userInfo.phoneNumber)) {
      newErrors.phoneNumber = "Số điện thoại không hợp lệ";
    }

    // Validate names
    if (!userInfo.firstName.trim()) {
      newErrors.firstName = "Họ không được để trống";
    }
    if (!userInfo.lastName.trim()) {
      newErrors.lastName = "Tên không được để trống";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSaveProfile = () => {
    if (!validateForm()) {
      return;
    }

    // TODO: Implement API call to save profile changes
    localStorage.setItem('user', JSON.stringify({
      ...JSON.parse(localStorage.getItem('user') || '{}'),
      ...userInfo
    }));
    
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    const storedUser = JSON.parse(localStorage.getItem('user') || '{}');
    setUserInfo(prev => ({
      ...prev,
      ...storedUser
    }));
    setIsEditing(false);
    setErrors({});
  };

  const handleChangePassword = () => {
    setShowChangePassword(true);
    setPasswordFields({ oldPassword: '', newPassword: '', confirmPassword: '' });
    setPasswordError('');
    setPasswordSuccess('');
  };

  const handlePasswordFieldChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordFields(prev => ({ ...prev, [name]: value }));
    setPasswordError('');
    setPasswordSuccess('');
  };

  const handleCloseChangePassword = () => {
    setShowChangePassword(false);
    setPasswordFields({ oldPassword: '', newPassword: '', confirmPassword: '' });
    setPasswordError('');
    setPasswordSuccess('');
  };

  const handleSubmitChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');
    const storedUser = JSON.parse(localStorage.getItem('user') || '{}');
    if (!passwordFields.oldPassword || !passwordFields.newPassword || !passwordFields.confirmPassword) {
      setPasswordError('Vui lòng nhập đầy đủ các trường');
      return;
    }
    if (storedUser.password !== passwordFields.oldPassword) {
      setPasswordError('Mật khẩu cũ không đúng');
      return;
    }
    // Kiểm tra độ mạnh mật khẩu mới
    const passwordValidation = validatePassword(passwordFields.newPassword);
    if (!passwordValidation.isValid) {
      setPasswordError(passwordValidation.message);
      return;
    }
    if (passwordFields.newPassword !== passwordFields.confirmPassword) {
      setPasswordError('Mật khẩu xác nhận không khớp');
      return;
    }
    // Lưu mật khẩu mới vào localStorage
    const updatedUser = { ...storedUser, password: passwordFields.newPassword };
    localStorage.setItem('user', JSON.stringify(updatedUser));
    setPasswordSuccess('Đổi mật khẩu thành công!');
    setTimeout(() => {
      setShowChangePassword(false);
    }, 1500);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setUserInfo(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear error when user types
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleAvatarClick = () => {
    if (isEditing && fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setAvatarError('');
    if (file) {
      // Kiểm tra loại file
      const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
      if (!allowedTypes.includes(file.type)) {
        setAvatarError('Chỉ cho phép các định dạng ảnh JPG, PNG, GIF, WEBP.');
        return;
      }
      // Kiểm tra kích thước file (2MB)
      const maxSize = 20 * 1024 * 1024;
      if (file.size > maxSize) {
        setAvatarError('Kích thước ảnh tối đa là 20MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setUserInfo(prev => ({
          ...prev,
          avatar: reader.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'Không xác định';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'Không xác định';
    return new Intl.DateTimeFormat('vi-VN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };

  const getMembershipColor = (level?: string) => {
    switch (level) {
      case 'gold':
        return 'text-yellow-600';
      case 'silver':
        return 'text-gray-500';
      case 'bronze':
        return 'text-amber-700';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      {/* User Dashboard */}
      <main className="pt-24">
        <div className="container mx-auto px-6 py-8">
          {/* Profile Overview */}
          <motion.section
            id="profile-overview"
            className="mb-12"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="bg-white rounded-xl shadow-lg p-8">
              <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
                <motion.div
                  className="relative"
                  whileHover={isEditing ? { scale: 1.05 } : {}}
                  whileTap={isEditing ? { scale: 0.97 } : {}}
                  transition={{ type: 'spring', stiffness: 300 }}
                >
                  <motion.img
                    src={userInfo.avatar || '/default-avatar.png'}
                    alt="User Profile"
                    className={`w-24 h-24 rounded-full object-cover ${isEditing ? 'cursor-pointer hover:opacity-80' : ''}`}
                    onClick={handleAvatarClick}
                    whileHover={isEditing ? { scale: 1.08, opacity: 0.85 } : {}}
                    transition={{ type: 'spring', stiffness: 300 }}
                  />
                  {isEditing && (
                    <motion.div
                      className="absolute inset-0 flex items-center justify-center rounded-full bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-200 cursor-pointer"
                      onClick={handleAvatarClick}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                    >
                      <span className="text-white opacity-0 hover:opacity-100">Thay đổi</span>
                    </motion.div>
                  )}
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept="image/*"
                    onChange={handleAvatarChange}
                  />
                  {avatarError && (
                    <p className="text-red-500 text-sm mt-2">{avatarError}</p>
                  )}
                </motion.div>
                <div className="flex-1">
                  <h2 className="text-3xl font-bold text-gray-800 mb-2">
                    {userInfo.firstName} {userInfo.lastName}
                  </h2>
                  <p className="text-gray-600 mb-2">
                    Thành viên từ {formatDate(userInfo.createdAt)}
                  </p>
                  <p className={`font-medium mb-4 ${getMembershipColor(userInfo.membershipLevel)}`}>
                    Thành viên {userInfo.membershipLevel?.toUpperCase()}
                  </p>
                  <div className="flex gap-4">
                    {!isEditing ? (
                      <motion.button
                        className="px-6 py-2 bg-[#008080] text-white rounded-lg hover:bg-[#006666]"
                        onClick={handleEditProfile}
                        whileTap={{ scale: 0.96 }}
                        whileHover={{ scale: 1.04 }}
                        transition={{ type: 'spring', stiffness: 300 }}
                      >
                        Chỉnh Sửa Thông Tin
                      </motion.button>
                    ) : (
                      <div className="flex gap-4">
                        <motion.button
                          className="px-6 py-2 bg-[#008080] text-white rounded-lg hover:bg-[#006666]"
                          onClick={handleSaveProfile}
                          whileTap={{ scale: 0.96 }}
                          whileHover={{ scale: 1.04 }}
                          transition={{ type: 'spring', stiffness: 300 }}
                        >
                          Lưu Thông Tin
                        </motion.button>
                        <motion.button
                          className="px-6 py-2 border border-[#008080] text-[#008080] rounded-lg hover:bg-[#008080] hover:text-white"
                          onClick={handleCancelEdit}
                          whileTap={{ scale: 0.96 }}
                          whileHover={{ scale: 1.04 }}
                          transition={{ type: 'spring', stiffness: 300 }}
                        >
                          Hủy
                        </motion.button>
                      </div>
                    )}
                    <motion.button
                      className="px-6 py-2 border border-[#008080] text-[#008080] rounded-lg hover:bg-[#008080] hover:text-white"
                      onClick={handleChangePassword}
                      whileTap={{ scale: 0.96 }}
                      whileHover={{ scale: 1.04 }}
                      transition={{ type: 'spring', stiffness: 300 }}
                    >
                      Đổi Mật Khẩu
                    </motion.button>
                  </div>
                </div>
              </div>
            </div>
          </motion.section>

          {/* Main Content Grid */}
          <div className="grid md:grid-cols-3 gap-8">
            {/* Personal Information */}
            <motion.section
              id="personal-info"
              className="md:col-span-2"
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <div className="bg-white rounded-xl shadow-lg p-8">
                <h3 className="text-2xl font-bold mb-6 text-gray-800">Thông Tin Cá Nhân</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-600 mb-2">Họ</label>
                    <input 
                      type="text" 
                      name="firstName"
                      value={userInfo.firstName}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                      className={`w-full px-4 py-3 rounded-lg border ${
                        errors.firstName ? 'border-red-500' : 'border-gray-300'
                      } focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none ${
                        !isEditing ? 'bg-gray-100' : ''
                      }`}
                    />
                    {errors.firstName && (
                      <p className="mt-1 text-sm text-red-500">{errors.firstName}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-gray-600 mb-2">Tên</label>
                    <input 
                      type="text" 
                      name="lastName"
                      value={userInfo.lastName}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                      className={`w-full px-4 py-3 rounded-lg border ${
                        errors.lastName ? 'border-red-500' : 'border-gray-300'
                      } focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none ${
                        !isEditing ? 'bg-gray-100' : ''
                      }`}
                    />
                    {errors.lastName && (
                      <p className="mt-1 text-sm text-red-500">{errors.lastName}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-gray-600 mb-2">Email</label>
                    <input 
                      type="email" 
                      name="email"
                      value={userInfo.email}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                      className={`w-full px-4 py-3 rounded-lg border ${
                        errors.email ? 'border-red-500' : 'border-gray-300'
                      } focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none ${
                        !isEditing ? 'bg-gray-100' : ''
                      }`}
                    />
                    {errors.email && (
                      <p className="mt-1 text-sm text-red-500">{errors.email}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-gray-600 mb-2">Số Điện Thoại</label>
                    <input 
                      type="tel" 
                      name="phoneNumber"
                      value={userInfo.phoneNumber}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                      className={`w-full px-4 py-3 rounded-lg border ${
                        errors.phoneNumber ? 'border-red-500' : 'border-gray-300'
                      } focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none ${
                        !isEditing ? 'bg-gray-100' : ''
                      }`}
                    />
                    {errors.phoneNumber && (
                      <p className="mt-1 text-sm text-red-500">{errors.phoneNumber}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-gray-600 mb-2">Ngày Sinh</label>
                    <input 
                      type="date" 
                      name="dateOfBirth"
                      value={userInfo.dateOfBirth}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                      className={`w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none ${
                        !isEditing ? 'bg-gray-100' : ''
                      }`}
                    />
                  </div>
                  <div>
                    <label className="block text-gray-600 mb-2">Giới Tính</label>
                    <select 
                      name="gender"
                      value={userInfo.gender}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                      className={`w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none ${
                        !isEditing ? 'bg-gray-100' : ''
                      }`}
                    >
                      <option value="male">Nam</option>
                      <option value="female">Nữ</option>
                    </select>
                  </div>
                </div>
              </div>
            </motion.section>

            {/* Side Panel */}
            <div className="space-y-8">
              {/* Quick Stats */}
              <motion.section
                id="quick-stats"
                className="bg-white rounded-xl shadow-lg p-8"
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.3 }}
              >
                <h3 className="text-2xl font-bold mb-6 text-gray-800">Tổng Quan Tài Khoản</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <i className="fa-regular fa-calendar text-[#008080] text-xl"></i>
                      <span className="text-gray-600">Tổng Số Lần Đặt Lịch</span>
                    </div>
                    <span className="text-xl font-bold text-gray-800">12</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <i className="fa-regular fa-clock text-[#008080] text-xl"></i>
                      <span className="text-gray-600">Giờ Thư Giãn</span>
                    </div>
                    <span className="text-xl font-bold text-gray-800">18</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <i className="fa-regular fa-star text-[#008080] text-xl"></i>
                      <span className="text-gray-600">Điểm Thành Viên</span>
                    </div>
                    <span className="text-xl font-bold text-gray-800">250</span>
                  </div>
                </div>
              </motion.section>
            </div>
          </div>
        </div>
      </main>
      {/* Modal đổi mật khẩu */}
      <AnimatePresence>
        {showChangePassword && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="bg-white rounded-xl shadow-lg p-8 w-full max-w-md relative"
              initial={{ scale: 0.8, opacity: 0, y: 60 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.8, opacity: 0, y: 60 }}
              transition={{ duration: 0.3 }}
            >
              <button className="absolute top-3 right-3 text-gray-400 hover:text-gray-700" onClick={handleCloseChangePassword}>
                <i className="fa-solid fa-xmark text-2xl"></i>
              </button>
              <h2 className="text-2xl font-bold mb-6 text-gray-800 text-center">Đổi Mật Khẩu</h2>
              <form onSubmit={handleSubmitChangePassword} className="space-y-4">
                <div>
                  <label className="block text-gray-600 mb-2">Mật khẩu cũ</label>
                  <input
                    type="password"
                    name="oldPassword"
                    value={passwordFields.oldPassword}
                    onChange={handlePasswordFieldChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none"
                    autoComplete="current-password"
                  />
                </div>
                <div>
                  <label className="block text-gray-600 mb-2">Mật khẩu mới</label>
                  <input
                    type="password"
                    name="newPassword"
                    value={passwordFields.newPassword}
                    onChange={handlePasswordFieldChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none"
                    autoComplete="new-password"
                  />
                </div>
                <div>
                  <label className="block text-gray-600 mb-2">Xác nhận mật khẩu mới</label>
                  <input
                    type="password"
                    name="confirmPassword"
                    value={passwordFields.confirmPassword}
                    onChange={handlePasswordFieldChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none"
                    autoComplete="new-password"
                  />
                </div>
                {passwordError && <p className="text-red-500 text-sm">{passwordError}</p>}
                {passwordSuccess && <p className="text-green-600 text-sm">{passwordSuccess}</p>}
                <button
                  type="submit"
                  className="w-full px-6 py-2 bg-[#008080] text-white rounded-lg hover:bg-[#006666]"
                >
                  Đổi Mật Khẩu
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <Footer />
    </div>
  );
};

export default ProfilePageCustomer;
