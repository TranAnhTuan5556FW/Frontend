import Header from "../../components/HeaderCustomer";
import Footer from "../../components/FooterCustomer";
import { FaCrown, FaPercent, FaGift, FaClock } from "react-icons/fa";
import { useEffect } from "react";
import { motion } from "framer-motion";

const MembershipRewards = () => {
  const pointsHistory = [
    {
      date: '15/03/2025',
      activity: 'Đặt lịch Massage Thụy Điển',
      points: '+150',
      balance: '2.450',
      type: 'credit'
    },
    {
      date: '01/03/2025',
      activity: 'Đổi điểm - Buổi massage miễn phí',
      points: '-1.000',
      balance: '2.300',
      type: 'debit'
    },
    {
      date: '15/02/2025',
      activity: 'Massage Đả Thông Kinh Lạc',
      points: '+200',
      balance: '3.300',
      type: 'credit'
    }
  ];


  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="pt-24">
        <div className="container mx-auto px-6 py-8">
          {/* Tiêu đề và Điểm */}
          <motion.section id="membership-header" className="mb-8"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <div className="flex justify-between items-center">
              <h2 className="text-3xl font-bold text-gray-800">Thẻ Thành Viên & Điểm Thưởng</h2>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-gray-600">Điểm hiện có</p>
                  <p className="text-2xl font-bold text-[#008080]">2.450</p>
                </div>
              </div>
            </div>
          </motion.section>

          {/* Thẻ thành viên */}
          <motion.section id="membership-card" className="mb-8"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.7 }}
          >
            <motion.div className="bg-gradient-to-r from-[#008080] to-[#006666] rounded-xl p-6 text-white"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2, duration: 0.7 }}
            >
              <div className="flex justify-between items-start mb-8">
                <div>
                  <p className="text-sm opacity-80 mb-1">Hạng thành viên</p>
                  <h3 className="text-2xl font-bold">Thành viên Vàng</h3>
                </div>
                <FaCrown className="text-3xl text-yellow-300" />
              </div>
              <div className="flex justify-between items-end">
                <div>
                  <p className="text-sm opacity-80 mb-1">Ngày tham gia</p>
                  <p>Tháng 01/2025</p>
                </div>
                <div>
                  <p className="text-sm opacity-80 mb-1">Mã thành viên</p>
                  <p>GLD-2025-1234</p>
                </div>
              </div>
            </motion.div>
          </motion.section>

          {/* Quyền lợi thành viên */}
          <motion.section id="membership-benefits" className="mb-12"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.7 }}
          >
            <h3 className="text-xl font-bold text-gray-800 mb-6">Quyền lợi thành viên Vàng</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {[{
                icon: <FaPercent className="text-3xl text-[#008080] mb-4" />,
                title: 'Giảm 15% tất cả dịch vụ',
                desc: 'Tự động áp dụng cho mọi lần đặt lịch'
              }, {
                icon: <FaGift className="text-3xl text-[#008080] mb-4" />,
                title: 'Ưu đãi sinh nhật',
                desc: 'Nhân đôi điểm trong tháng sinh nhật'
              }, {
                icon: <FaClock className="text-3xl text-[#008080] mb-4" />,
                title: 'Đặt lịch ưu tiên',
                desc: 'Đặt lịch trước 24 giờ'
              }].map((item, idx) => (
                <motion.div
                  key={idx}
                  className="bg-white rounded-xl p-6 shadow-lg"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + idx * 0.1, duration: 0.6 }}
                >
                  {item.icon}
                  <h4 className="font-bold text-gray-800 mb-2">{item.title}</h4>
                  <p className="text-gray-600">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </motion.section>

          {/* Lịch sử điểm */}
          <motion.section id="points-history" className="mb-12"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.7 }}
          >
            <h3 className="text-xl font-bold text-gray-800 mb-6">Lịch sử điểm thưởng</h3>
            <motion.div className="bg-white rounded-xl shadow-lg overflow-hidden"
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4, duration: 0.6 }}
            >
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Ngày</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Hoạt động</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Điểm</th>
                      <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Số dư</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {pointsHistory.map((item, index) => (
                      <motion.tr
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.5 + index * 0.07, duration: 0.5 }}
                      >
                        <td className="px-6 py-4 text-sm text-gray-800">{item.date}</td>
                        <td className="px-6 py-4 text-sm text-gray-800">{item.activity}</td>
                        <td className={`px-6 py-4 text-sm ${item.type === 'credit' ? 'text-green-600' : 'text-red-600'}`}>
                          {item.points}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-800">{item.balance}</td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          </motion.section>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default MembershipRewards;
