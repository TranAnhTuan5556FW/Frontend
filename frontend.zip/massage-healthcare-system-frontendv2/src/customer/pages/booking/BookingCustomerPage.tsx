import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import Header from '../../components/HeaderCustomer';
import Footer from '../../components/FooterCustomer';

interface Therapist {
  name: string;
  experience: string;
}

interface BookingDetails {
  serviceName: string;
  duration: number;
  price: number;
  image?: string;
  isPackage?: boolean;
  packageId?: string;
  therapist?: Therapist;
  therapists?: Therapist[];
  originalAppointmentId?: string;
  isRescheduling?: boolean;
}

interface User {
  firstName?: string;
  lastName?: string;
  email: string;
  phoneNumber: string;
}

interface FormData {
  name: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  specialRequests: string;
  agreeToTerms: boolean;
}

interface ValidationErrors {
  date?: string;
  time?: string;
  [key: string]: string | undefined;
}

const BookingPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [bookingDetails, setBookingDetails] = useState<BookingDetails | null>(null);
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: '',
    specialRequests: '',
    agreeToTerms: false
  });
  const [validationErrors, setValidationErrors] = useState<ValidationErrors>({});
  const [isRescheduling, setIsRescheduling] = useState(false);

  // Tạo mảng các khung giờ cho phép
  const availableTimeSlots = [
    // Buổi sáng: 7AM - 11AM
    '07:00', '07:30', '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00',
    // Buổi chiều: 1PM - 5PM
    '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'
  ];

  useEffect(() => {
    // Lấy thông tin user từ localStorage
    const userString = localStorage.getItem('user');
    if (userString) {
      const user: User = JSON.parse(userString);
      setFormData(prev => ({
        ...prev,
        name: user.firstName && user.lastName ? `${user.firstName} ${user.lastName}` : 
              user.firstName || user.lastName || prev.name,
        email: user.email || prev.email,
        phone: user.phoneNumber || prev.phone
      }));
    } else {
      // Nếu chưa đăng nhập, chuyển về trang đăng nhập
      navigate('/auth');
    }

    // Retrieve booking info from localStorage
    const storedBookingInfo = localStorage.getItem('bookingInfo');
    if (storedBookingInfo) {
      const parsedBookingInfo = JSON.parse(storedBookingInfo) as BookingDetails;
      setBookingDetails(parsedBookingInfo);
      setIsRescheduling(parsedBookingInfo.isRescheduling || false);
    } else {
      // If no booking info, redirect back to service detail page
      navigate(`/services/${id}`);
    }
  }, [id, navigate]);

  // Tính toán ngày tối thiểu cho đặt lịch (ngày mai)
  const getMinBookingDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  const validateForm = () => {
    const errors: ValidationErrors = {};
    const selectedDate = new Date(formData.date);
    const minDate = new Date(getMinBookingDate());

    if (selectedDate < minDate) {
      errors.date = 'Ngày đặt lịch phải sau ngày hiện tại ít nhất 1 ngày';
    }

    if (formData.time) {
      const [hours] = formData.time.split(':').map(Number);
      if ((hours < 7 || hours >= 11) && (hours < 13 || hours >= 17)) {
        errors.time = 'Vui lòng chọn giờ trong khung giờ làm việc (7AM-11AM hoặc 1PM-5PM)';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: undefined
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    if (!validateForm() || !bookingDetails) {
      return;
    }

    const finalBookingData = {
      ...formData,
      ...bookingDetails,
      createdAt: new Date().toISOString(),
      isRescheduled: isRescheduling
    };
    
    if (isRescheduling && bookingDetails.originalAppointmentId) {
      console.log('Rescheduling appointment:', bookingDetails.originalAppointmentId);
    }
    
    // Thêm lịch mới vào localStorage (userAppointments)
    const userAppointments = JSON.parse(localStorage.getItem('userAppointments') || '[]');
    // Tạo id mới (tìm id lớn nhất trong userAppointments)
    let maxId = 0;
    userAppointments.forEach((a: any) => { if (a.id > maxId) maxId = a.id; });
    // Nếu muốn chắc chắn không trùng với mẫu, có thể đặt maxId tối thiểu là 1000
    if (maxId < 1000) maxId = 1000;
    const newId = maxId + 1;
    const newAppointment = {
      id: newId,
      date: formData.date,
      time: formData.time,
      service: bookingDetails.serviceName,
      duration: bookingDetails.duration,
      therapist: bookingDetails.therapist?.name || '',
      therapists: bookingDetails.therapists || undefined,
      status: 'upcoming',
      // Có thể bổ sung các trường khác nếu muốn
    };
    userAppointments.push(newAppointment);
    localStorage.setItem('userAppointments', JSON.stringify(userAppointments));

    localStorage.setItem('confirmedBooking', JSON.stringify(finalBookingData));
    navigate('/confirmation');
  };

  const nextStep = () => {
    if (step === 2) {
      // Validate date and time before moving to confirmation step
      if (!validateForm()) {
        return;
      }
    }
    if (step < 3) {
      setStep(step + 1);
    }
  };

  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  if (!bookingDetails) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      {/* Service Detail Hero */}
      <section id="service-hero" className="pt-16 bg-gray-50">
        <div className="container mx-auto px-6 py-12">
          <div className="flex items-center mb-8">
            {bookingDetails.isPackage ? (
              <Link to={`/packages/${bookingDetails.packageId || id}`} className="text-[#008080] hover:text-[#006666]">
                <i className="fa-solid fa-arrow-left mr-2"></i>
                Quay lại Gói dịch vụ
              </Link>
            ) : (
              <Link to={isRescheduling ? '/customer/appointments' : `/services/${id}`} className="text-[#008080] hover:text-[#006666]">
                <i className="fa-solid fa-arrow-left mr-2"></i>
                {isRescheduling ? 'Quay lại Lịch hẹn' : 'Quay lại Dịch vụ'}
              </Link>
            )}
          </div>
          <div className="grid md:grid-cols-2 gap-12 items-start">
            <div className="relative">
              <img
                className="rounded-2xl shadow-2xl w-full"
                src={bookingDetails.image || "https://storage.googleapis.com/uxpilot-auth.appspot.com/344e4f13f9-038cbe4cb1418ffc1066.png"}
                alt={bookingDetails.serviceName}
              />
              {isRescheduling && (
                <div className="absolute top-4 right-4 bg-yellow-400 text-black px-4 py-2 rounded-lg font-semibold">
                  Đổi lịch hẹn
                </div>
              )}
            </div>
            <div id="service-info">
              <h1 className="text-4xl font-bold text-gray-800 mb-4">
                {bookingDetails.isPackage ? 'Thông tin gói dịch vụ' : bookingDetails.serviceName}
              </h1>
              <div className="flex items-center mb-6">
                <span className="text-2xl font-bold text-[#008080] mr-4">
                  {Number(bookingDetails.price).toLocaleString('vi-VN')}đ/{bookingDetails.duration} phút
                </span>
              </div>
              <div className="bg-gray-100 p-4 rounded-lg mb-6">
                <h3 className="font-bold mb-2">Chi tiết đã chọn:</h3>
                <p className="text-gray-700">Thời lượng: {bookingDetails.duration} phút</p>
                {bookingDetails.isPackage ? (
                  <>
                    <p className="text-gray-700 font-semibold">Kỹ thuật viên:</p>
                    <ul className="list-disc ml-6">
                      {bookingDetails.therapists?.map((t, idx) => (
                        <li key={idx}>{t.name} ({t.experience})</li>
                      ))}
                    </ul>
                  </>
                ) : bookingDetails.therapist && (
                  <>
                    <p className="text-gray-700">Kỹ thuật viên: {bookingDetails.therapist.name}</p>
                    <p className="text-gray-700">Kinh nghiệm: {bookingDetails.therapist.experience}</p>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Progress Bar */}
      <div className="bg-gray-100 py-4">
        <div className="container mx-auto px-6">
          <div className="flex justify-between items-center">
            <div className={`flex items-center ${step >= 1 ? 'text-[#008080]' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-[#008080] text-white' : 'bg-gray-300'}`}>
                1
              </div>
              <span className="ml-2">Thông Tin Cá Nhân</span>
            </div>
            <div className={`flex items-center ${step >= 2 ? 'text-[#008080]' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-[#008080] text-white' : 'bg-gray-300'}`}>
                2
              </div>
              <span className="ml-2">Chi Tiết Đặt Lịch</span>
            </div>
            <div className={`flex items-center ${step >= 3 ? 'text-[#008080]' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-[#008080] text-white' : 'bg-gray-300'}`}>
                3
              </div>
              <span className="ml-2">Xác Nhận</span>
            </div>
          </div>
        </div>
      </div>

      {/* Booking Form */}
      <section className="py-12">
        <div className="container mx-auto px-6">
          <form onSubmit={handleSubmit} className="max-w-2xl mx-auto">
            {step === 1 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold mb-6">Thông Tin Cá Nhân</h2>
                <div>
                  <label className="block text-gray-700 mb-2">Họ và Tên</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-[#008080] bg-gray-100"
                    required
                    readOnly
                  />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-[#008080] bg-gray-100"
                    required
                    readOnly
                  />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">Số Điện Thoại</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-[#008080] bg-gray-100"
                    required
                    readOnly
                  />
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <i className="fa-solid fa-info-circle mr-2"></i>
                    Thông tin cá nhân được lấy từ tài khoản của bạn. Nếu bạn muốn thay đổi, vui lòng cập nhật trong phần thông tin cá nhân.
                  </p>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold mb-6">Chi Tiết Đặt Lịch</h2>
                <div>
                  <label className="block text-gray-700 mb-2">Ngày</label>
                  <input
                    type="date"
                    name="date"
                    value={formData.date}
                    min={getMinBookingDate()}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-[#008080] ${
                      validationErrors.date ? 'border-red-500' : ''
                    }`}
                    required
                  />
                  {validationErrors.date && (
                    <p className="text-red-500 text-sm mt-1">{validationErrors.date}</p>
                  )}
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">Giờ</label>
                  <select
                    name="time"
                    value={formData.time}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-[#008080] ${
                      validationErrors.time ? 'border-red-500' : ''
                    }`}
                    required
                  >
                    <option value="">Chọn giờ</option>
                    <optgroup label="Buổi sáng (7AM - 11AM)">
                      {availableTimeSlots.filter(time => parseInt(time) < 12).map(time => (
                        <option key={time} value={time}>
                          {time}
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="Buổi chiều (1PM - 5PM)">
                      {availableTimeSlots.filter(time => parseInt(time) >= 13).map(time => (
                        <option key={time} value={time}>
                          {time}
                        </option>
                      ))}
                    </optgroup>
                  </select>
                  {validationErrors.time && (
                    <p className="text-red-500 text-sm mt-1">{validationErrors.time}</p>
                  )}
                  <p className="text-gray-500 text-sm mt-2">
                    <i className="fa-solid fa-info-circle mr-1"></i>
                    Giờ làm việc: 7AM-11AM và 1PM-5PM
                  </p>
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">Yêu Cầu Đặc Biệt</label>
                  <textarea
                    name="specialRequests"
                    value={formData.specialRequests}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-[#008080]"
                    rows={4}
                  />
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold mb-6">Xác Nhận Đặt Lịch</h2>
                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="text-lg font-bold mb-4">Tóm Tắt Đặt Lịch</h3>
                  <div className="space-y-4">
                    <div className="border-b pb-4">
                      <h4 className="font-bold text-[#008080] mb-2">Thông tin dịch vụ</h4>
                      <p><span className="font-bold">Dịch vụ:</span> {bookingDetails.serviceName}</p>
                      <p><span className="font-bold">Thời lượng:</span> {bookingDetails.duration} phút</p>
                      <p><span className="font-bold">Giá:</span> {Number(bookingDetails.price).toLocaleString('vi-VN')}đ</p>
                    </div>
                    <div className="border-b pb-4">
                      <h4 className="font-bold text-[#008080] mb-2">Thông tin kỹ thuật viên</h4>
                      {bookingDetails.isPackage ? (
                        <ul className="list-disc ml-6">
                          {bookingDetails.therapists?.map((t, idx) => (
                            <li key={idx}>{t.name} ({t.experience})</li>
                          ))}
                        </ul>
                      ) : (
                        <>
                          <p><span className="font-bold">Tên:</span> {bookingDetails.therapist?.name}</p>
                          <p><span className="font-bold">Kinh nghiệm:</span> {bookingDetails.therapist?.experience}</p>
                        </>
                      )}
                    </div>
                    <div className="border-b pb-4">
                      <h4 className="font-bold text-[#008080] mb-2">Thông tin khách hàng</h4>
                      <p><span className="font-bold">Họ tên:</span> {formData.name}</p>
                      <p><span className="font-bold">Email:</span> {formData.email}</p>
                      <p><span className="font-bold">Số điện thoại:</span> {formData.phone}</p>
                    </div>
                    <div className="border-b pb-4">
                      <h4 className="font-bold text-[#008080] mb-2">Thời gian</h4>
                      <p><span className="font-bold">Ngày:</span> {formData.date}</p>
                      <p><span className="font-bold">Giờ:</span> {formData.time}</p>
                    </div>
                    {formData.specialRequests && (
                      <div>
                        <h4 className="font-bold text-[#008080] mb-2">Yêu cầu đặc biệt</h4>
                        <p>{formData.specialRequests}</p>
                      </div>
                    )}
                  </div>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                  <p className="text-sm text-yellow-800">
                    <i className="fa-solid fa-info-circle mr-2"></i>
                    Vui lòng kiểm tra kỹ thông tin trước khi xác nhận đặt lịch. Sau khi xác nhận, 
                    bạn sẽ nhận được email xác nhận với chi tiết đặt lịch.
                  </p>
                </div>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    name="agreeToTerms"
                    checked={formData.agreeToTerms}
                    onChange={handleInputChange}
                    className="mr-2"
                    required
                  />
                  <label className="text-gray-700">
                    Tôi đồng ý với các điều khoản và điều kiện
                  </label>
                </div>
              </div>
            )}

            <div className="flex justify-between mt-8">
              {step > 1 && (
                <button
                  type="button"
                  onClick={prevStep}
                  className="px-6 py-2 border border-[#008080] text-[#008080] rounded-lg hover:bg-gray-50"
                >
                  Quay Lại
                </button>
              )}
              {step < 3 ? (
                <button
                  type="button"
                  onClick={nextStep}
                  className="px-6 py-2 bg-[#008080] text-white rounded-lg hover:bg-[#006666]"
                >
                  Tiếp Tục
                </button>
              ) : (
                <button
                  type="submit"
                  className="px-6 py-2 bg-[#008080] text-white rounded-lg hover:bg-[#006666]"
                >
                  Xác Nhận Đặt Lịch
                </button>
              )}
            </div>
          </form>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default BookingPage;
