import { useEffect, useState } from 'react';
import Header from '../../components/HeaderCustomer';
import Footer from '../../components/FooterCustomer';

interface Service {
  name: string;
  duration: string;
}

interface Therapist {
  name: string;
  experience: string;
}

interface BookingData {
  isPackage: boolean;
  packageId?: number;
  serviceId?: number;
  serviceName: string;
  duration: string;
  date: string;
  time: string;
  price: number;
  services?: Service[];
  therapist?: Therapist;
  therapists?: Therapist[];
}

const ConfirmationPage = () => {
  const [booking, setBooking] = useState<BookingData | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem('confirmedBooking');
    if (stored) {
      setBooking(JSON.parse(stored));
    }
  }, []);

  if (!booking) return null;

  return (
    <div className="min-h-screen bg-white">
      {/* Confirmation Content */}
      <Header />
      <section id="confirmation" className="pt-24 pb-20">
        <div className="container mx-auto px-6">
          <div id="confirmation-header" className="text-center mb-12">
            <div className="text-[#008080] mb-6">
              <i className="fa-solid fa-circle-check text-6xl"></i>
            </div>
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Đặt Lịch Thành Công!</h2>
            <p className="text-xl text-gray-600">Hành trình thư giãn của bạn đã được lên lịch.</p>
          </div>

          <div className="max-w-3xl mx-auto">
            {/* Appointment Details Card */}
            <div id="appointment-details" className="bg-white rounded-xl shadow-lg p-8 mb-8">
              <h3 className="text-2xl font-bold text-gray-800 mb-6">Chi Tiết Đặt Lịch</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <p className="text-gray-500">{booking.isPackage ? 'Gói dịch vụ' : 'Dịch vụ'}</p>
                    <p className="text-lg font-bold">
                      {booking.isPackage ? (
                        <>
                          {booking.serviceName} ({booking.duration})
                          <ul className="list-disc ml-6 text-base mt-2">
                            {booking.services && booking.services.map((s, idx) => (
                              <li key={idx}>{s.name} ({s.duration})</li>
                            ))}
                          </ul>
                        </>
                      ) : (
                        `${booking.serviceName} (${booking.duration} phút)`
                      )}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-500">Ngày</p>
                    <p className="text-lg font-bold">{booking.date}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Giờ</p>
                    <p className="text-lg font-bold">{booking.time}</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <p className="text-gray-500">Kỹ thuật viên</p>
                    <p className="text-lg font-bold">
                      {booking.isPackage ? (
                        <ul className="list-disc ml-6">
                          {booking.therapists && booking.therapists.map((t, idx) => (
                            <li key={idx}>{t.name} ({t.experience})</li>
                          ))}
                        </ul>
                      ) : (
                        booking.therapist?.name
                      )}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-500">Giá</p>
                    <p className="text-lg font-bold">{booking.price?.toLocaleString('vi-VN')}đ</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Preparation Instructions */}
            <div id="preparation-instructions" className="bg-[#e6e6fa]/20 rounded-xl p-8 mb-8">
              <h3 className="text-2xl font-bold text-gray-800 mb-6">Hướng Dẫn Chuẩn Bị</h3>
              <div className="grid gap-4">
                <div className="flex items-start space-x-4">
                  <i className="fa-solid fa-clock text-[#008080] text-xl mt-1"></i>
                  <div>
                    <p className="font-bold">Đến sớm 15 phút</p>
                    <p className="text-gray-600">Vui lòng đến sớm 15 phút trước giờ hẹn để hoàn thành các thủ tục cần thiết.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <i className="fa-solid fa-shower text-[#008080] text-xl mt-1"></i>
                  <div>
                    <p className="font-bold">Tắm trước buổi massage</p>
                    <p className="text-gray-600">Nên tắm trước buổi massage để có trải nghiệm tốt nhất.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <i className="fa-solid fa-mobile-screen text-[#008080] text-xl mt-1"></i>
                  <div>
                    <p className="font-bold">Tắt thiết bị di động</p>
                    <p className="text-gray-600">Vui lòng tắt hoặc để chế độ im lặng các thiết bị di động trong suốt buổi massage.</p>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default ConfirmationPage;
