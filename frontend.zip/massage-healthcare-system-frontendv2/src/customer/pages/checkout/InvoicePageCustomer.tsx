import React, { useState } from "react";
import Header from "../../components/HeaderCustomer";
import Footer from "../../components/FooterCustomer";
import { invoiceData, Invoice } from "../../../data/invoiceData";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

const statusMap: Record<Invoice["status"], { label: string; className: string }> = {
  paid: { label: "Đã thanh toán", className: "text-green-700 bg-green-100" },
  pending: { label: "Chờ thanh toán", className: "text-red-700 bg-red-100" }
};

const ITEMS_PER_PAGE = 6;

const InvoicePageCustomer: React.FC = () => {
  const [date, setDate] = useState("");
  const [service, setService] = useState("");
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const navigate = useNavigate();

  // Lọc dữ liệu dựa trên các trường tìm kiếm
  const filteredData = invoiceData.filter((inv) => {
    const matchDate = date ? inv.date === date : true;
    const matchService = service ? inv.service.toLowerCase().includes(service.toLowerCase()) : true;
    const matchStatus = status ? inv.status === status : true;
    return matchDate && matchService && matchStatus;
  });

  // Phân trang
  const totalPages = Math.ceil(filteredData.length / ITEMS_PER_PAGE) || 1;
  const paginatedData = filteredData.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);

  // Khi filter thay đổi, reset về trang 1
  React.useEffect(() => {
    setPage(1);
  }, [date, service, status]);

  return (
    <>
      <Header />
      <motion.div className="max-w-7xl mx-auto px-4 pt-32 pb-16 min-h-screen bg-gray-50" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <motion.section id="payment-history" className="bg-white rounded-xl shadow-lg p-6 overflow-x-auto" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }}>
          <motion.h2 className="text-2xl font-bold text-gray-800 mb-6" initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>Lịch sử thanh toán</motion.h2>

          {/* Search and Filter Section */}
          <motion.div id="search-filters" className="mb-8" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
            <div className="grid md:grid-cols-3 gap-4 mb-6">
              {/* Date Search */}
              <div>
                <label className="block text-gray-700 mb-2">Ngày</label>
                <input
                  type="date"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                  value={date}
                  onChange={e => setDate(e.target.value)}
                />
              </div>
              {/* Service Search */}
              <div>
                <label className="block text-gray-700 mb-2">Dịch vụ</label>
                <input
                  type="text"
                  placeholder="Tìm kiếm dịch vụ..."
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                  value={service}
                  onChange={e => setService(e.target.value)}
                />
              </div>
              {/* Payment Status Filter */}
              <div>
                <label className="block text-gray-700 mb-2">Trạng thái thanh toán</label>
                <select
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                  value={status}
                  onChange={e => setStatus(e.target.value)}
                >
                  <option value="">Tất cả</option>
                  <option value="paid">Đã thanh toán</option>
                  <option value="pending">Chờ thanh toán</option>
                </select>
              </div>
            </div>
          </motion.div>

          {/* Payment History Table */}
          <motion.div id="payment-table" className="overflow-x-auto" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            <table className="w-full min-w-[900px]">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-600">Ngày</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-600">Dịch vụ</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-600">Số tiền</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-600">Trạng thái</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-600">Phương thức thanh toán</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-600">Thao tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {paginatedData.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-6 text-gray-500">Không có hóa đơn phù hợp</td>
                  </tr>
                ) : (
                  paginatedData.map((inv, idx) => (
                    <motion.tr
                      className="hover:bg-gray-50"
                      key={idx}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.05 * idx }}
                    >
                      <td className="px-6 py-4 text-sm text-gray-700">{inv.date.split("-").reverse().join("/")}</td>
                      <td className="px-6 py-4 text-sm text-gray-700">{inv.service}</td>
                      <td className="px-6 py-4 text-sm text-gray-700">{inv.amount.toLocaleString()}₫</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 text-xs font-semibold rounded-full ${statusMap[inv.status].className}`}>{statusMap[inv.status].label}</span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-700">{inv.paymentMethod}</td>
                      <td className="px-6 py-4">
                        <div className="flex space-x-2">
                          {(inv.status === "pending") && (
                            <motion.button className="px-3 py-1 text-sm text-white bg-[#008080] rounded hover:bg-[#006666]" onClick={() => navigate('/customer/checkout')} whileHover={{ scale: 1.07 }} whileTap={{ scale: 0.97 }}>Thanh toán</motion.button>
                          )}
                          <motion.button 
                            className="px-3 py-1 text-sm text-gray-600 border border-gray-300 rounded hover:bg-gray-50" 
                            onClick={() => navigate(`/customer/billing/${idx + 1}`)} 
                            whileHover={{ scale: 1.07 }} 
                            whileTap={{ scale: 0.97 }}
                          >
                            Chi tiết
                          </motion.button>
                        </div>
                      </td>
                    </motion.tr>
                  ))
                )}
              </tbody>
            </table>
          </motion.div>

          {/* Pagination */}
          <motion.div id="pagination" className="mt-6 flex items-center justify-between" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
            <div className="text-sm text-gray-600">
              Hiển thị {(filteredData.length === 0 ? 0 : (page - 1) * ITEMS_PER_PAGE + 1)} đến {Math.min(page * ITEMS_PER_PAGE, filteredData.length)} trong tổng số {filteredData.length} mục
            </div>
            <div className="flex space-x-2">
              <motion.button
                className="px-3 py-1 text-sm text-gray-600 border border-gray-300 rounded hover:bg-gray-50"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                whileHover={{ scale: 1.07 }}
                whileTap={{ scale: 0.97 }}
              >
                Trước
              </motion.button>
              {Array.from({ length: totalPages }, (_, i) => (
                <motion.button
                  key={i}
                  className={`px-3 py-1 text-sm rounded ${page === i + 1 ? "text-white bg-[#008080]" : "text-gray-600 border border-gray-300 hover:bg-gray-50"}`}
                  onClick={() => setPage(i + 1)}
                  whileHover={{ scale: 1.07 }}
                  whileTap={{ scale: 0.97 }}
                >
                  {i + 1}
                </motion.button>
              ))}
              <motion.button
                className="px-3 py-1 text-sm text-gray-600 border border-gray-300 rounded hover:bg-gray-50"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                whileHover={{ scale: 1.07 }}
                whileTap={{ scale: 0.97 }}
              >
                Tiếp
              </motion.button>
            </div>
          </motion.div>
        </motion.section>
      </motion.div>
      <Footer />
    </>
  );
};

export default InvoicePageCustomer;
