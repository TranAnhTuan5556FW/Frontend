import React, { useState } from "react";
import Header from "../../components/HeaderCustomer";
import Footer from "../../components/FooterCustomer";
import { useNavigate } from "react-router-dom";

const CheckoutPageCustomer: React.FC = () => {
  const [promo, setPromo] = useState("");
  const [selectedPayment, setSelectedPayment] = useState("");
  const navigate = useNavigate();

  const handleConfirm = () => {
    // Có thể thêm logic xử lý thanh toán ở đây
    navigate("/customer/checkout/confirmation");
  };

  return (
    <>
      <Header />
      <div className="container mx-auto px-4 pt-28 pb-12 min-h-screen bg-gray-50">
        <section id="payment-process" className="max-w-3xl mx-auto bg-white rounded-xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Thanh toán</h2>

          {/* Order Summary */}
          <div id="order-summary" className="border rounded-lg p-6 mb-8">
            <h3 className="text-lg font-semibold mb-4">Tóm tắt đơn hàng</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-medium">Massage Thụy Điển</h4>
                  <p className="text-sm text-gray-600">20/05/2025 | 14:00</p>
                  <p className="text-sm text-gray-600">Kỹ thuật viên: Sarah Johnson</p>
                </div>
                <span className="font-medium">$85.00</span>
              </div>
              <div className="border-t pt-4">
                <div className="flex justify-between text-sm">
                  <span>Giá gốc</span>
                  <span>$85.00</span>
                </div>
                <div className="flex justify-between text-sm text-green-600 mt-2">
                  <span>Khuyến mãi đã áp dụng</span>
                  <span>-$10.00</span>
                </div>
                <div className="flex justify-between font-semibold mt-4 text-lg">
                  <span>Tổng cộng</span>
                  <span>$75.00</span>
                </div>
              </div>
            </div>
          </div>

          {/* Promo Code Section */}
          <div id="promo-section" className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Áp dụng mã khuyến mãi</h3>
            <div className="flex gap-3">
              <input
                type="text"
                placeholder="Nhập mã khuyến mãi"
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                value={promo}
                onChange={e => setPromo(e.target.value)}
              />
              <button className="px-6 py-2 bg-[#008080] text-white rounded-lg hover:bg-[#006666]">Áp dụng</button>
            </div>
          </div>

          {/* Payment Methods */}
          <div id="payment-methods" className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Phương thức thanh toán</h3>
            <div className="space-y-3">
              <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  name="payment"
                  className="mr-3"
                  checked={selectedPayment === "cash"}
                  onChange={() => setSelectedPayment("cash")}
                />
                <i className="fa-solid fa-money-bill-wave text-green-600 mr-3"></i>
                <span>Tiền mặt tại quầy</span>
              </label>
              <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  name="payment"
                  className="mr-3"
                  checked={selectedPayment === "card"}
                  onChange={() => setSelectedPayment("card")}
                />
                <i className="fa-solid fa-credit-card text-blue-600 mr-3"></i>
                <span>Thẻ tín dụng/Ghi nợ</span>
              </label>
              <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  name="payment"
                  className="mr-3"
                  checked={selectedPayment === "ewallet"}
                  onChange={() => setSelectedPayment("ewallet")}
                />
                <i className="fa-solid fa-wallet text-purple-600 mr-3"></i>
                <span>Ví điện tử (MoMo/ZaloPay)</span>
              </label>
            </div>
          </div>

          {/* Support Info */}
          <div id="support-info" className="bg-gray-50 rounded-lg p-4 mb-8 text-sm">
            <div className="flex items-center mb-2">
              <i className="fa-solid fa-circle-info text-[#008080] mr-2"></i>
              <span className="font-medium">Hỗ trợ</span>
            </div>
            <p className="text-gray-600 mb-2">Cần hỗ trợ? Liên hệ: support@relaxease.com</p>
            <p className="text-gray-600">Chính sách hoàn tiền: Hoàn tiền 100% nếu hủy lịch trước 24h so với giờ hẹn</p>
          </div>

          {/* Action Buttons */}
          <div id="action-buttons" className="flex gap-4">
            <button className="flex-1 px-6 py-3 bg-[#008080] text-white rounded-lg hover:bg-[#006666]" onClick={handleConfirm}>
              Xác nhận thanh toán
            </button>
            <button className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50">
              Hủy
            </button>
          </div>
        </section>
      </div>
      <Footer />
    </>
  );
};

export default CheckoutPageCustomer;
