import React from "react";
import Header from "../../components/HeaderCustomer";
import Footer from "../../components/FooterCustomer";
import { useNavigate } from "react-router-dom";
import jsPDF from "jspdf";
// @ts-ignore
import autoTable from "jspdf-autotable";

const ConfirmCheckoutPageCustomer: React.FC = () => {
  const navigate = useNavigate();

  const handleReturn = (): void => {
    navigate("/customer/billing");
  };

  const handleDownloadInvoice = (): void => {
    const doc = new jsPDF();

    // Header
    doc.setFillColor(0, 128, 128);
    doc.roundedRect(10, 10, 190, 15, 4, 4, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.text("Thanh toán thành công!", 105, 20, { align: "center" });

    // Success icon (tick)
    doc.setDrawColor(46, 204, 113);
    doc.setFillColor(46, 204, 113);
    doc.circle(25, 40, 8, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(18);
    doc.text("✔", 25, 45, { align: "center", baseline: "middle" });

    // Transaction code
    doc.setFontSize(12);
    doc.setTextColor(100, 100, 100);
    doc.text("Mã giao dịch: #TRX25052089", 45, 45);

    // Appointment Details Table
    autoTable(doc, {
      startY: 55,
      head: [["Chi tiết lịch hẹn", ""]],
      body: [
        ["Dịch vụ", "Massage Thụy Điển"],
        ["Ngày & Giờ", "20/05/2025 | 14:00"],
        ["Kỹ thuật viên", "Sarah Johnson"],
      ],
      theme: "grid",
      headStyles: { fillColor: [0, 128, 128], textColor: 255, fontStyle: "bold" },
      bodyStyles: { textColor: 50 },
      columnStyles: { 0: { cellWidth: 50 }, 1: { cellWidth: 120 } },
      styles: { fontSize: 11 },
    });

    // Payment Details Table
    autoTable(doc, {
      startY: (doc as any).lastAutoTable.finalY + 8,
      head: [["Chi tiết thanh toán", ""]],
      body: [
        ["Phương thức thanh toán", "Thẻ tín dụng"],
        ["Số tiền đã thanh toán", "$75.00"],
        ["Thời gian giao dịch", "14/05/2025 | 10:30"],
      ],
      theme: "grid",
      headStyles: { fillColor: [0, 128, 128], textColor: 255, fontStyle: "bold" },
      bodyStyles: { textColor: 50 },
      columnStyles: { 0: { cellWidth: 50 }, 1: { cellWidth: 120 } },
      styles: { fontSize: 11 },
    });

    // Footer note
    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(
      "Một email xác nhận đã được gửi đến địa chỉ email của bạn với đầy đủ thông tin chi tiết.",
      14,
      (doc as any).lastAutoTable.finalY + 20
    );

    doc.save("hoa_don_thanh_toan.pdf");
  };

  return (
    <>
      <Header />
      <div className="container mx-auto px-4 mt-24 mb-12">
        <section id="payment-confirmation" className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8">
          {/* Success Header */}
          <div id="confirmation-header" className="text-center mb-8">
            <div className="inline-block p-4 bg-green-100 rounded-full mb-4">
              <i className="fa-solid fa-circle-check text-4xl text-green-500"></i>
            </div>
            <h2 className="text-2xl font-bold text-gray-800">Thanh toán thành công!</h2>
            <p className="text-gray-600 mt-2">Mã giao dịch: #TRX25052089</p>
          </div>

          {/* Appointment Details */}
          <div id="appointment-details" className="border-b pb-6 mb-6">
            <h3 className="text-lg font-semibold mb-4">Chi tiết lịch hẹn</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Dịch vụ</span>
                <span className="font-medium">Massage Thụy Điển</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Ngày &amp; Giờ</span>
                <span className="font-medium">20/05/2025 | 14:00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Kỹ thuật viên</span>
                <span className="font-medium">Sarah Johnson</span>
              </div>
            </div>
          </div>

          {/* Payment Details */}
          <div id="payment-details" className="border-b pb-6 mb-6">
            <h3 className="text-lg font-semibold mb-4">Chi tiết thanh toán</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Phương thức thanh toán</span>
                <span className="font-medium">Thẻ tín dụng</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Số tiền đã thanh toán</span>
                <span className="font-medium text-green-600">$75.00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Thời gian giao dịch</span>
                <span className="font-medium">14/05/2025 | 10:30</span>
              </div>
            </div>
          </div>

          {/* Invoice Actions */}
          <div id="invoice-actions" className="flex flex-col gap-4 mb-8">
            <button className="flex items-center justify-center gap-2 px-6 py-3 bg-white border border-[#008080] text-[#008080] rounded-lg hover:bg-gray-50">
              <i className="fa-solid fa-file-invoice"></i>
              Xem hóa đơn
            </button>
            <button className="flex items-center justify-center gap-2 px-6 py-3 bg-white border border-[#008080] text-[#008080] rounded-lg hover:bg-gray-50" onClick={handleDownloadInvoice}>
              <i className="fa-solid fa-download"></i>
              Tải hóa đơn (PDF)
            </button>
          </div>

          {/* Additional Information */}
          <div id="additional-info" className="bg-gray-50 rounded-lg p-4 text-sm mb-8">
            <div className="flex items-start gap-2">
              <i className="fa-solid fa-circle-info text-[#008080] mt-1"></i>
              <p className="text-gray-600">Một email xác nhận đã được gửi đến địa chỉ email của bạn với đầy đủ thông tin chi tiết.</p>
            </div>
          </div>

          {/* Return Button */}
          <div id="return-action" className="text-center">
            <button className="px-8 py-3 bg-[#008080] text-white rounded-lg hover:bg-[#006666]" onClick={handleReturn}>
              Quay về trang chính
            </button>
          </div>
        </section>
      </div>
      <Footer />
    </>
  );
};

export default ConfirmCheckoutPageCustomer;
