import React from "react";
import { useNavigate } from "react-router-dom";
import HeaderCustomer from "../../components/HeaderCustomer";
import FooterCustomer from "../../components/FooterCustomer";

const InvoiceDetailPageCustomer: React.FC = () => {
  const navigate = useNavigate();

  const handleBack = () => {
    navigate(-1);
  };

  const handleDownload = () => {
    // Implement PDF download functionality
    console.log("Downloading PDF...");
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <HeaderCustomer />
      <main className="flex-grow pt-24 pb-12">
        <div className="container mx-auto px-4">
          <section id="invoice-details-section" className="bg-white rounded-xl shadow-lg p-8 max-w-3xl mx-auto">
            <div className="flex items-center mb-8 gap-4">
              <button 
                onClick={handleBack}
                className="flex items-center px-4 py-2 rounded-lg border border-gray-200 bg-[#e6e6fa] text-[#008080] hover:bg-[#d5d5e8] transition"
              >
                <i className="fa-solid fa-arrow-left mr-2"></i>
                Trở lại
              </button>
              <h2 className="text-3xl font-bold text-gray-800 flex-1 text-center">Chi tiết hóa đơn</h2>
            </div>

            {/* Invoice Overview */}
            <div id="invoice-overview" className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div id="invoice-meta" className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-gray-500 font-semibold">Hóa đơn #:</span>
                  <span className="text-gray-800 font-bold">INV-2025-001</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-gray-500 font-semibold">Ngày phát hành:</span>
                  <span className="text-gray-800">Ngày 15 tháng 5 năm 2025</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-gray-500 font-semibold">ID giao dịch:</span>
                  <span className="text-gray-800">TXN-9576321</span>
                </div>
              </div>
              <div id="invoice-customer" className="bg-[#e6e6fa] rounded-lg p-4 space-y-2">
                <div className="flex items-center gap-2">
                  <i className="fa-regular fa-user text-[#008080]"></i>
                  <span className="font-semibold text-gray-700">Anna Trần</span>
                </div>
                <div className="flex items-center gap-2">
                  <i className="fa-solid fa-phone text-[#008080]"></i>
                  <span className="text-gray-600">+84 912 345 678</span>
                </div>
                <div className="flex items-center gap-2">
                  <i className="fa-regular fa-envelope text-[#008080]"></i>
                  <span className="text-gray-600">anna.tran@email.com</span>
                </div>
              </div>
            </div>

            {/* Service Details */}
            <div id="invoice-services-card" className="mb-8 rounded-lg border border-gray-200 p-6">
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <i className="fa-solid fa-spa text-[#008080]"></i>
                Chi tiết dịch vụ
              </h3>
              <table className="w-full mb-4">
                <thead>
                  <tr className="bg-[#e6e6fa]">
                    <th className="py-2 px-3 text-left text-gray-700 text-sm font-semibold rounded-tl-lg">Dịch vụ</th>
                    <th className="py-2 px-3 text-right text-gray-700 text-sm font-semibold">Đơn giá</th>
                    <th className="py-2 px-3 text-right text-gray-700 text-sm font-semibold rounded-tr-lg">Tổng phụ</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="py-2 px-3 text-gray-800">Massage Thụy Điển</td>
                    <td className="py-2 px-3 text-right text-gray-800">$85,00</td>
                    <td className="py-2 px-3 text-right text-gray-800">$85,00</td>
                  </tr>
                </tbody>
              </table>
              {/* Discount block */}
              <div id="invoice-discount-applied" className="flex items-center gap-3 mb-2">
                <i className="fa-solid fa-gift text-purple-500"></i>
                <span className="text-gray-600">
                  Mã khuyến mãi: <span className="font-semibold text-purple-600">THƯ GIÃN</span> (Giảm giá: <span className="font-bold text-[#008080]">$10,00</span>)
                </span>
              </div>
            </div>

            {/* Payment Summary */}
            <div id="invoice-summary" className="mb-8 rounded-lg bg-[#e6e6fa] p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-700 font-medium">Tổng phụ</span>
                  <span className="text-gray-800 font-bold">$85,00</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-700 font-medium">Giảm giá</span>
                  <span className="text-purple-600 font-bold">- $10,00</span>
                </div>
                <div className="flex justify-between items-center text-lg mt-2">
                  <span className="text-gray-900 font-bold">Tổng cộng</span>
                  <span className="text-[#008080] font-extrabold text-xl">$75,00</span>
                </div>
              </div>
              <div className="flex flex-col md:items-end justify-center gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-gray-600">Tình trạng:</span>
                  <span className="px-3 py-1 text-sm font-semibold text-green-700 bg-green-100 rounded-full">Trả tiền (Trực tuyến)</span>
                </div>
                <div className="flex items-center gap-2">
                  <i className="fa-solid fa-calendar-check text-[#008080]"></i>
                  <span className="text-gray-700">Trả tiền vào ngày 15 tháng 5 năm 2025</span>
                </div>
              </div>
            </div>

            {/* Salon Info & Note */}
            <div id="invoice-salon-card" className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
              <div className="bg-[#e6e6fa] rounded-lg p-4 space-y-2">
                <div className="flex items-center gap-2 mb-1">
                  <i className="fa-solid fa-house-chimney text-[#008080]"></i>
                  <span className="font-semibold text-gray-700">Spa thư giãn</span>
                </div>
                <div className="flex items-center gap-2">
                  <i className="fa-solid fa-location-dot text-[#008080]"></i>
                  <span className="text-gray-600">123 Trần Hưng Đạo, Q1, HCM</span>
                </div>
                <div className="flex items-center gap-2">
                  <i className="fa-solid fa-phone text-[#008080]"></i>
                  <span className="text-gray-600">+84 28 1234 5678</span>
                </div>
                <div className="flex items-center gap-2">
                  <i className="fa-regular fa-envelope text-[#008080]"></i>
                  <span className="text-gray-600">liên hệ@relaxease.com</span>
                </div>
              </div>
              <div className="bg-[#e6e6fa] rounded-lg p-4">
                <h4 className="text-gray-800 font-semibold mb-1 flex items-center gap-2">
                  <i className="fa-solid fa-note-sticky text-[#008080]"></i>
                  Ghi chú
                </h4>
                <p className="text-gray-600 text-sm">
                  * Hoàn tiền chỉ được áp dụng trong vòng 12 giờ sau khi thanh toán nếu dịch vụ không được sử dụng.<br />
                  * Vui lòng xuất trình hóa đơn này khi nhận phòng.<br />
                  * Để biết thêm chi tiết về các chương trình khuyến mãi của chúng tôi, hãy truy cập trang web của chúng tôi.
                </p>
              </div>
            </div>

            {/* Actions */}
            <div id="invoice-actions" className="flex flex-col md:flex-row items-stretch md:items-center gap-4 justify-end">
              <button 
                onClick={handleDownload}
                className="flex items-center justify-center px-5 py-2 bg-[#008080] text-white rounded-lg font-medium shadow hover:bg-[#006666] transition min-w-[140px]"
              >
                <i className="fa-solid fa-download mr-2"></i>
                Tải xuống bản PDF
              </button>
              <button 
                onClick={handlePrint}
                className="flex items-center justify-center px-5 py-2 bg-white border border-[#008080] text-[#008080] rounded-lg font-medium shadow hover:bg-[#e6e6fa] transition min-w-[140px]"
              >
                <i className="fa-solid fa-print mr-2"></i>
                In hóa đơn
              </button>
              <button 
                onClick={handleBack}
                className="flex items-center justify-center px-5 py-2 bg-gray-200 text-gray-700 rounded-lg font-medium shadow hover:bg-gray-300 transition min-w-[140px]"
              >
                <i className="fa-solid fa-arrow-left-long mr-2"></i>
                Quay lại
              </button>
            </div>
          </section>
        </div>
      </main>
      <FooterCustomer />
    </div>
  );
};

export default InvoiceDetailPageCustomer;
