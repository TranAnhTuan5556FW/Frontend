import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Header from '../../components/HeaderCustomer';
import Footer from '../../components/FooterCustomer';
import { services } from '../../../data/individualServiceDataCustomer';
import { motion } from 'framer-motion';

const IndividualServiceDetalPageCustomer = () => {
  const navigate = useNavigate();
  const { serviceId } = useParams();
  const [service, setService] = useState<any>(null);
  const [selectedDuration, setSelectedDuration] = useState<string>('');
  const [selectedTherapist, setSelectedTherapist] = useState<number | null>(null);

  useEffect(() => {
    // Find the service based on serviceId
    const foundService = services.find(s => s.id === Number(serviceId));
    if (foundService) {
      setService(foundService);
    } else {
      // Redirect to services page if service not found
      navigate('/services');
    }
  }, [serviceId, navigate]);

  const handleBack = () => {
    navigate('/services');
  };

  const handleDurationSelect = (duration: string) => {
    setSelectedDuration(duration);
  };

  const handleTherapistSelect = (therapistId: number) => {
    setSelectedTherapist(therapistId);
  };

  const handleContinueToBooking = () => {
    if (!selectedDuration || !selectedTherapist) {
      alert('Vui lòng chọn thời gian và chuyên viên massage');
      return;
    }
    // Prepare booking info
    const therapist = service.therapists.find((t: any) => t.id === selectedTherapist);
    const bookingInfo = {
      serviceName: service.name,
      duration: Number(selectedDuration),
      price: service.prices[selectedDuration],
      image: service.image,
      therapist,
      isPackage: false,
      serviceId: service.id
    };
    localStorage.setItem('bookingInfo', JSON.stringify(bookingInfo));
    navigate(`/booking/${service.id}`);
  };

  if (!service) {
    return null; // or a loading spinner
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(price);
  };
  
  return (
    <>
      <Header />
      <div className="min-h-screen bg-white">
        {/* Service Detail Hero */}
        <motion.section id="service-hero" className="pt-16 bg-gray-50" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.75 }}>
          <div className="container mx-auto px-6 py-12">
            <motion.div className="flex items-center mb-8" initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2, duration: 0.75 }}>
              <motion.button onClick={handleBack} className="text-[#008080] hover:text-[#006666]" whileHover={{ scale: 1.07 }} whileTap={{ scale: 0.97 }} transition={{ duration: 0.3 }}>
                <i className="fa-solid fa-arrow-left mr-2"></i>Quay lại Dịch vụ
              </motion.button>
            </motion.div>
            <div className="grid md:grid-cols-2 gap-12 items-start">
              <motion.div className="relative" initial={{ opacity: 0, x: -40 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3, duration: 0.75 }}>
                <motion.img
                  className="rounded-2xl shadow-2xl w-full"
                  src={service.image}
                  alt={service.name}
                  initial={{ scale: 0.95, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.4, duration: 0.75 }}
                />
                {service.tag && (
                  <motion.span className="absolute top-4 right-4 bg-[#e6e6fa] text-[#008080] px-4 py-1 rounded-full text-sm" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6, duration: 0.75 }}>
                    {service.tag === 'popular' ? 'Phổ biến nhất' : 'Đặc biệt'}
                  </motion.span>
                )}
              </motion.div>
              <motion.div id="service-info" initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4, duration: 0.75 }}>
                <motion.h1 className="text-4xl font-bold text-gray-800 mb-4" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.75 }}>{service.name}</motion.h1>
                <div className="flex items-center mb-6">
                  <motion.span className="text-2xl font-bold text-[#008080] mr-4" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.6, duration: 0.75 }}>
                    {formatPrice(service.prices['60'])}
                  </motion.span>
                </div>
                <motion.p className="text-gray-600 text-lg mb-8" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7, duration: 0.75 }}>{service.description}</motion.p>
                <div id="service-benefits" className="mb-8">
                  <h3 className="text-xl font-bold mb-4">Lợi ích</h3>
                  <ul className="space-y-3">
                    {service.benefits.map((benefit: string, index: number) => (
                      <motion.li key={index} className="flex items-center text-gray-600" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.8 + index * 0.1, duration: 0.75 }}>
                        <i className="fa-solid fa-check text-[#008080] mr-3"></i>
                        {benefit}
                      </motion.li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            </div>
          </div>
        </motion.section>

        {/* Booking Section */}
        <motion.section id="booking-section" className="py-16" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.75, delay: 0.2 }}>
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-12">
              <motion.div id="booking-info" initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3, duration: 0.75 }}>
                <h2 className="text-3xl font-bold mb-6">Đặt Lịch Hẹn</h2>
                <div className="bg-white rounded-xl shadow-lg p-8">
                  <div className="mb-6">
                    <h3 className="text-xl font-bold mb-4">Chọn Thời Gian</h3>
                    <div className="grid grid-cols-3 gap-4">
                      {Object.entries(service.prices).map(([duration], idx) => (
                        <motion.button
                          key={duration}
                          onClick={() => handleDurationSelect(duration)}
                          className={`px-4 py-3 border-2 rounded-lg transition-colors ${selectedDuration === duration
                              ? 'bg-[#008080] text-white border-[#008080]'
                              : 'border-[#008080] text-[#008080] hover:bg-[#008080] hover:text-white'
                            }`}
                          whileHover={{ scale: 1.07 }}
                          whileTap={{ scale: 0.97 }}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.4 + idx * 0.1, duration: 0.75 }}
                        >
                          {duration} phút
                        </motion.button>
                      ))}
                    </div>
                  </div>
                  <div className="mb-6">
                    <h3 className="text-xl font-bold mb-4">Chọn Chuyên Viên</h3>
                    <div className="grid grid-cols-2 gap-4">
                      {service.therapists.map((therapist: any, idx: number) => (
                        <motion.div
                          key={therapist.id}
                          onClick={() => handleTherapistSelect(therapist.id)}
                          className={`group flex items-center p-4 border-2 rounded-lg cursor-pointer transition-colors ${selectedTherapist === therapist.id
                              ? 'bg-[#008080] text-white border-[#008080]'
                              : 'border-[#008080] text-[#008080] hover:bg-[#008080] hover:text-white'
                            }`}
                          whileHover={{ scale: 1.03 }}
                          whileTap={{ scale: 0.97 }}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.6 + idx * 0.1, duration: 0.75 }}
                        >
                          <img
                            src={therapist.image}
                            alt={therapist.name}
                            className="w-12 h-12 rounded-full mr-4"
                          />
                          <div>
                            <h4 className="font-bold">{therapist.name}</h4>
                            <p className={`${selectedTherapist === therapist.id ? 'text-white' : 'text-gray-500 group-hover:text-white'}`}>{therapist.experience}</p>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                  <motion.button
                    onClick={handleContinueToBooking}
                    className="w-full py-4 bg-[#008080] text-white rounded-lg hover:bg-[#006666] text-lg font-bold"
                    whileHover={{ scale: 1.04 }}
                    whileTap={{ scale: 0.97 }}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1.1, duration: 0.75 }}
                  >
                    Tiếp tục đặt lịch
                  </motion.button>
                </div>
              </motion.div>

              <motion.div id="additional-info" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4, duration: 0.75 }}>
                <h2 className="text-3xl font-bold mb-6">Thông tin thêm</h2>
                <div className="space-y-6">
                  {[{
                    icon: 'fa-clock',
                    title: 'Thời gian',
                    content: <p className="text-gray-600">Có nhiều lựa chọn: 60, 90, hoặc 120 phút tùy theo nhu cầu của bạn.</p>
                  }, {
                    icon: 'fa-clipboard-list',
                    title: 'Chuẩn bị',
                    content: <ul className="text-gray-600 space-y-2"><li>• Đến sớm 10-15 phút</li><li>• Mặc trang phục thoải mái</li><li>• Điền phiếu thông tin sức khỏe</li></ul>
                  }, {
                    icon: 'fa-shield-heart',
                    title: 'Chính sách hủy',
                    content: <p className="text-gray-600">Miễn phí hủy lịch trước 24 giờ.</p>
                  }].map((item, idx) => (
                    <motion.div
                      className="bg-white rounded-xl shadow-lg p-6"
                      key={item.title}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.7 + idx * 0.16, duration: 0.75 }}
                    >
                      <div className="flex items-center mb-4">
                        <i className={`fa-solid ${item.icon} text-2xl text-[#008080] mr-4`}></i>
                        <h3 className="text-xl font-bold">{item.title}</h3>
                      </div>
                      {item.content}
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </motion.section>
      </div>
      <Footer />
    </>
  );
};

export default IndividualServiceDetalPageCustomer;