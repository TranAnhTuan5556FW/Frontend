import React, { useState, useMemo, useEffect } from "react";
import { motion, HTMLMotionProps } from "framer-motion";
import Header from "../../components/HeaderCustomer";
import Footer from "../../components/FooterCustomer";
import IndividualServiceCustomer from "./IndividualServiceCustomer";
import PackageServiceCustomer from "./PackageServiveCustomer";
import { services } from '../../../data/individualServiceDataCustomer';
import allPackages, { Package as DataPackage } from '../../../data/packageServiceDataCustomer';
import { removeVietnameseTones } from "../../../utils/stringUtils";

type Category = 'all' | 'relaxation' | 'therapeutic' | 'specialty';
type TabType = 'individual' | 'package';
type SortOption = 'recommended' | 'price-asc' | 'price-desc' | 'duration';


const staggerContainer = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

const itemVariant = {
  hidden: { opacity: 0, y: 20 },
  show: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 1
    }
  }
};

const ServicePageCustomer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('individual');
  const [selectedCategory, setSelectedCategory] = useState<Category>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>('recommended');

  const individualServices = services;
  const packages: DataPackage[] = allPackages;

  const categories: Category[] = ['all', 'relaxation', 'therapeutic', 'specialty'];

  const buttonMotionProps: HTMLMotionProps<"button"> = {
    whileHover: { scale: 1.05 },
    whileTap: { scale: 0.95 }
  };

  const handleTabChange = (tab: TabType) => {
    setActiveTab(tab);
  };

  const handleCategoryChange = (category: Category) => {
    setSelectedCategory(category);
  };

  const extractPrice = (prices: { [key: string]: number }): number => {
    return prices['60'] || 0;
  };


  const filteredServices = useMemo(() => {
    let result = [...individualServices];

    if (selectedCategory !== 'all') {
      result = result.filter(service => service.category === selectedCategory);
    }

    if (searchQuery) {
      const query = removeVietnameseTones(searchQuery.toLowerCase());
      result = result.filter(service => {
        const normalizedName = removeVietnameseTones(service.name.toLowerCase());
        const normalizedDesc = removeVietnameseTones(service.description.toLowerCase());
        return normalizedName.includes(query) || normalizedDesc.includes(query);
      });
    }

    switch (sortOption) {
      case 'price-asc':
        result.sort((a, b) => extractPrice(a.prices) - extractPrice(b.prices));
        break;
      case 'price-desc':
        result.sort((a, b) => extractPrice(b.prices) - extractPrice(a.prices));
        break;
      case 'duration':
        result.sort((a, b) => {
          const durationA = parseInt(a.duration);
          const durationB = parseInt(b.duration);
          return durationB - durationA;
        });
        break;
      default:
        break;
    }

    return result;
  }, [individualServices, selectedCategory, searchQuery, sortOption]);

  const filteredPackages = useMemo(() => {
    let result = [...packages];

    if (selectedCategory !== 'all') {
      result = result.filter(pkg => pkg.category === selectedCategory);
    }

    if (searchQuery) {
      const query = removeVietnameseTones(searchQuery.toLowerCase());
      result = result.filter(pkg => {
        const normalizedName = removeVietnameseTones(pkg.name.toLowerCase());
        const normalizedDesc = removeVietnameseTones(pkg.description.toLowerCase());
        const normalizedBenefits = pkg.benefits.map(benefit =>
          removeVietnameseTones(benefit.toLowerCase())
        ).join(' ');
        return normalizedName.includes(query) ||
          normalizedDesc.includes(query) ||
          normalizedBenefits.includes(query);
      });
    }

    switch (sortOption) {
      case 'price-asc':
        result.sort((a, b) => {
          const priceA = a.prices ? Object.values(a.prices)[0] : 0;
          const priceB = b.prices ? Object.values(b.prices)[0] : 0;
          return priceA - priceB;
        });
        break;
      case 'price-desc':
        result.sort((a, b) => {
          const priceA = a.prices ? Object.values(a.prices)[0] : 0;
          const priceB = b.prices ? Object.values(b.prices)[0] : 0;
          return priceB - priceA;
        });
        break;
      default:
        break;
    }

    return result;
  }, [packages, selectedCategory, searchQuery, sortOption]);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortOption(e.target.value as SortOption);
  };

  useEffect(() => {
    // Scroll to top when page loads
    window.scrollTo({ top: 0, behavior: 'smooth' });

    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px'
    };
    const observer = new window.IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fade-in');
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);
    document.querySelectorAll('.animate-on-scroll').forEach((element) => {
      observer.observe(element);
    });
    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fadeIn 0.8s ease-out forwards;
        }
      `}</style>
      <Header />

      <main className="pt-24 min-h-screen bg-gray-50 animate-on-scroll opacity-0">
        <motion.section
          id="services-header"
          className="bg-white border-b"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          <div className="container mx-auto px-6 py-8">
            <div className="flex gap-8 mb-8">
              <motion.button
                {...buttonMotionProps}
                className={`text-xl font-bold ${activeTab === 'individual' ? 'text-[#008080] border-b-2 border-[#008080]' : 'text-gray-400 hover:text-[#008080]'} pb-2`}
                onClick={() => handleTabChange('individual')}
              >
                Dịch Vụ Đơn Lẻ
              </motion.button>
              <motion.button
                {...buttonMotionProps}
                className={`text-xl font-bold ${activeTab === 'package' ? 'text-[#008080] border-b-2 border-[#008080]' : 'text-gray-400 hover:text-[#008080]'} pb-2`}
                onClick={() => handleTabChange('package')}
              >
                Gói Dịch Vụ
              </motion.button>
            </div>
            <div className="flex flex-wrap gap-4 items-center justify-between">
              <div className="flex gap-3">
                {categories.map((cat) => (
                  <motion.button
                    key={cat}
                    {...buttonMotionProps}
                    className={`px-4 py-2 ${selectedCategory === cat
                        ? 'bg-[#008080] text-white'
                        : 'bg-white border border-gray-200 hover:bg-gray-50'
                      } rounded-lg`}
                    onClick={() => handleCategoryChange(cat)}
                  >
                    {cat === 'all' ? 'Tất cả' :
                      cat === 'relaxation' ? 'Thư giãn' :
                        cat === 'therapeutic' ? 'Trị liệu' : 'Đặc biệt'}
                  </motion.button>
                ))}
              </div>
              <div className="flex items-center gap-4">
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={handleSearchChange}
                    placeholder="Tìm kiếm dịch vụ..."
                    className="pl-10 pr-4 py-2 border rounded-lg w-64 focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                  />
                  <i className="fa-solid fa-search absolute left-3 top-3 text-gray-400"></i>
                </div>
                <select
                  className="px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                  value={sortOption}
                  onChange={handleSortChange}
                >
                  <option value="recommended">Sắp xếp: Đề xuất</option>
                  <option value="price-asc">Giá: Thấp đến cao</option>
                  <option value="price-desc">Giá: Cao đến thấp</option>
                  <option value="duration">Thời gian</option>
                </select>
              </div>
            </div>
          </div>
        </motion.section>

        {activeTab === 'individual' && (
          <IndividualServiceCustomer
            services={filteredServices}
            categories={categories}
            selectedCategory={selectedCategory}
            handleCategoryChange={handleCategoryChange}
            buttonMotionProps={buttonMotionProps}
            staggerContainer={staggerContainer}
            itemVariant={itemVariant}
          />
        )}

        {activeTab === 'package' && (
          <PackageServiceCustomer
            packages={filteredPackages.map(pkg => ({
              ...pkg,
              id: String(pkg.id),
              tag: pkg.tag ?? undefined,
              currentPrice: pkg.currentPrice ?? undefined,
              originalPrice: pkg.originalPrice ?? undefined,
              prices: pkg.prices ? Object.fromEntries(Object.entries(pkg.prices).map(([k, v]) => [k, String(v)])) : undefined
            }))}
            staggerContainer={staggerContainer}
            itemVariant={itemVariant}
          />
        )}
      </main>

      <Footer />
    </div>
  );
};

export default ServicePageCustomer;