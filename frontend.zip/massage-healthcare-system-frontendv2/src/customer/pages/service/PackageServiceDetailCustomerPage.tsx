import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Header from "../../components/HeaderCustomer";
import Footer from "../../components/FooterCustomer";
import allPackages, { Package } from "../../../data/packageServiceDataCustomer";
import { motion } from 'framer-motion';

const terms = [
  "Vui lòng đến trước giờ hẹn 15 phút để làm thủ tục",
  "Đặt lịch trước ít nhất 24 giờ để đảm bảo được phục vụ tốt nhất",
  "Có thể hủy lịch miễn phí trước 24 giờ",
  "Gói dịch vụ có giá trị trong vòng 3 tháng kể từ ngày mua",
  "Không áp dụng chung với các chương trình khuyến mãi khác"
];

const PackageServiceDetailCustomerPage: React.FC = () => {
  const navigate = useNavigate();
  const { packageId } = useParams<{ packageId: string }>();
  const [packageData, setPackageData] = useState<Package | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Scroll to top when page loads
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Simulate API call with the static data
    const fetchPackageData = () => {
      const foundPackage = allPackages.find(p => p.id === Number(packageId));
      if (foundPackage) {
        setPackageData(foundPackage);
      } else {
        // Handle package not found
        navigate('/services');
      }
      setLoading(false);
    };

    fetchPackageData();
  }, [packageId, navigate]);

  const handleBookPackage = () => {
    if (!packageData) return;

    // Prepare booking info for the package
    const bookingInfo = {
      serviceName: packageData.name,
      duration: packageData.duration,
      price: packageData.prices ? Object.values(packageData.prices)[0] : 0,
      image: packageData.image,
      therapists: packageData.therapists,
      isPackage: true,
      packageId: packageData.id,
      services: packageData.services
    };

    // Store booking info in localStorage
    localStorage.setItem('bookingInfo', JSON.stringify(bookingInfo));
    navigate(`/booking/${packageId}`);
  };

  if (loading || !packageData) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="pt-24 flex items-center justify-center min-h-screen bg-gray-50">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#008080] mx-auto"></div>
            <p className="mt-4 text-gray-600">Đang tải thông tin gói dịch vụ...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      {/* Package Detail Section */}
      <motion.section id="package-detail" className="pt-24 min-h-screen bg-gray-50" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.75 }}>
        {/* Package Header */}
        <motion.div className="bg-white border-b" initial={{ opacity: 0, y: -30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.75 }}>
          <div className="container mx-auto px-6 py-8">
            <motion.div className="flex items-center gap-4 mb-6" initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3, duration: 0.75 }}>
              <motion.span className="text-[#008080] cursor-pointer" onClick={() => navigate('/services')} whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.97 }} transition={{ duration: 0.3 }}>
                <i className="fa-solid fa-arrow-left text-xl"></i>
              </motion.span>
              <motion.h1 className="text-3xl font-bold text-gray-800" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4, duration: 0.75 }}>{packageData.name}</motion.h1>
            </motion.div>
            <motion.div className="flex items-center gap-4" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.75 }}>
              {packageData.tag && (
                <motion.span className={`px-4 py-1 rounded-full text-sm font-medium shadow-md ${packageData.tag === 'popular' ? 'bg-white text-[#008080] border border-[#008080]' : 'bg-[#008080] text-white'}`} initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6, duration: 0.75 }}>
                  {packageData.tag === 'popular' ? 'Phổ Biến' : packageData.tag === 'special' ? 'Ưu Đãi Đặc Biệt' : packageData.tag}
                </motion.span>
              )}
              {packageData.rating && packageData.reviews && (
                <span className="text-gray-500">
                  {packageData.rating} <i className="fa-solid fa-star text-yellow-400"></i> ({packageData.reviews} đánh giá)
                </span>
              )}
            </motion.div>
          </div>
        </motion.div>

        {/* Package Content */}
        <motion.div className="container mx-auto px-6 py-12" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6, duration: 0.75 }}>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Main Content */}
            <motion.div className="md:col-span-2" initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.7, duration: 0.75 }}>
              {/* Package Description */}
              <motion.div id="package-description" className="bg-white rounded-xl shadow-sm p-8 mb-8" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8, duration: 0.75 }}>
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Mô tả gói</h2>
                <p className="text-gray-600 mb-6">{packageData.description}</p>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Dịch vụ bao gồm:</h3>
                <ul className="space-y-2 mb-6">
                  {packageData.services.map((s, idx) => (
                    <motion.li className="flex items-center text-gray-700 text-base" key={idx} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.9 + idx * 0.1, duration: 0.75 }}>
                      <i className="fa-solid fa-spa text-[#008080] mr-3"></i>
                      <span>{s.name} <span className="text-gray-500">({s.duration})</span></span>
                    </motion.li>
                  ))}
                </ul>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Lợi ích nổi bật:</h3>
                <ul className="space-y-2 mb-6">
                  {packageData.benefits.map((b, idx) => (
                    <motion.li className="flex items-center text-gray-700 text-base" key={idx} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 1.1 + idx * 0.1, duration: 0.75 }}>
                      <i className="fa-solid fa-check text-[#008080] mr-3"></i>
                      <span>{b}</span>
                    </motion.li>
                  ))}
                </ul>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Chuyên viên thực hiện:</h3>
                <div className="flex flex-wrap gap-4 mb-4">
                  {packageData.therapists.map((t, idx) => (
                    <motion.div key={idx} className="flex items-center gap-2 bg-gray-100 rounded-full px-3 py-1 text-sm" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.3 + idx * 0.08, duration: 0.75 }}>
                      <img src={t.image} alt={t.name} className="w-8 h-8 rounded-full object-cover" />
                      <span className="font-semibold text-gray-700">{t.name}</span>
                      {t.experience && <span className="text-gray-500">({t.experience})</span>}
                    </motion.div>
                  ))}
                </div>
              </motion.div>
              {/* Terms & Conditions */}
              <motion.div id="terms-conditions" className="bg-white rounded-xl shadow-sm p-8" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.5, duration: 0.75 }}>
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Điều khoản & Điều kiện</h2>
                <ul className="space-y-4 text-gray-600">
                  {terms.map((term, idx) => (
                    <motion.li className="flex items-start" key={idx} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 1.6 + idx * 0.1, duration: 0.75 }}>
                      <i className="fa-solid fa-circle text-[#008080] text-xs mt-2 mr-3"></i>
                      <span>{term}</span>
                    </motion.li>
                  ))}
                </ul>
              </motion.div>
            </motion.div>
            {/* Booking Sidebar */}
            <motion.div className="md:col-span-1" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.8, duration: 0.75 }}>
              <div className="sticky top-24">
                <motion.div id="booking-card" className="bg-white rounded-xl shadow-sm p-6" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1, duration: 0.75 }}>
                  <div className="mb-6">
                    <div className="flex items-baseline mb-2">
                      <span className="text-4xl font-bold text-[#008080]">
                        {packageData.currentPrice
                          ? packageData.currentPrice
                          : (packageData.prices && Object.values(packageData.prices)[0]
                              ? `${Number(Object.values(packageData.prices)[0]).toLocaleString('vi-VN')}đ`
                              : '--')}
                      </span>
                      {packageData.originalPrice && packageData.currentPrice && (
                        <span className="text-gray-500 ml-2 line-through text-xl">
                          {packageData.originalPrice}
                        </span>
                      )}
                      <span className="text-gray-500 ml-2">/{packageData.duration}</span>
                    </div>
                    <p className="text-gray-500">Tiết kiệm hơn so với mua lẻ từng buổi</p>
                  </div>
                  <motion.button
                    className="w-full py-4 bg-[#008080] text-white rounded-lg hover:bg-[#006666] mb-4"
                    onClick={handleBookPackage}
                    disabled={packageData.status === 'Chưa bán'}
                    whileHover={{ scale: 1.04 }}
                    whileTap={{ scale: 0.97 }}
                    transition={{ duration: 0.3 }}
                  >
                    {packageData.status === 'Chưa bán' ? 'Sắp ra mắt' : 'Đặt gói ngay'}
                  </motion.button>
                  <motion.button className="w-full py-4 border border-[#008080] text-[#008080] rounded-lg hover:bg-gray-50 mb-6" whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }} transition={{ duration: 0.3 }}>
                    Liên hệ tư vấn
                  </motion.button>
                  <div className="space-y-4 text-sm">
                    <div className="flex items-center text-gray-600">
                      <i className="fa-solid fa-calendar-check mr-3 text-[#008080]"></i>
                      <span>Xác nhận nhanh</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <i className="fa-solid fa-clock mr-3 text-[#008080]"></i>
                      <span>{packageData.duration}</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <i className="fa-solid fa-user-group mr-3 text-[#008080]"></i>
                      <span>Kỹ thuật viên chuyên nghiệp</span>
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </motion.section>
      <Footer />
    </div>
  );
};

export default PackageServiceDetailCustomerPage;