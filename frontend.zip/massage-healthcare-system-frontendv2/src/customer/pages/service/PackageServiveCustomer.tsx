import React, { useState } from "react";
import { motion, Variants } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Pagination } from '../../components/Pagination';

export interface Service {
  name: string;
  duration: string;
}

export interface Therapist {
  name: string;
  image: string;
}

export interface Package {
  id: string;
  name: string;
  image: string;
  tag?: string;
  duration: string;
  currentPrice?: string;
  prices?: { [key: string]: string };
  services: Service[];
  description: string;
  benefits: string[];
  therapists: Therapist[];
}

interface PackageServiceCustomerProps {
  packages: Package[];
  staggerContainer: Variants;
  itemVariant: Variants;
}

const PackageServiceCustomer: React.FC<PackageServiceCustomerProps> = ({
  packages,
  staggerContainer,
  itemVariant,
}) => {
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentPackages = packages.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(packages.length / itemsPerPage);

  return (
    <motion.section 
      id="package-services" 
      className="py-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
    >
      <div className="container mx-auto px-6">
        <motion.div 
          variants={staggerContainer}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {currentPackages.map((pkg) => (
            <motion.div
              key={pkg.id}
              className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden"
              variants={itemVariant}
              whileHover={{ y: -5 }}
              transition={{ duration: 1 }}
            >
              <div className="relative h-56 bg-gray-100 flex items-center justify-center rounded-t-xl overflow-hidden">
                <img src={pkg.image} alt={pkg.name} className="object-cover w-full h-full" />
                {pkg.tag && (
                  <span className={`absolute top-4 right-4 px-4 py-2 rounded-full text-sm font-medium shadow-md ${
                    pkg.tag === 'popular' || pkg.tag === 'Phổ biến nhất' || pkg.tag === 'Tiết kiệm nhất'
                      ? 'bg-white text-[#008080] border border-[#008080]'
                      : 'bg-[#008080] text-white'
                  }`}>
                    {pkg.tag === 'popular' ? 'Phổ Biến' : pkg.tag === 'special' ? 'Ưu Đãi Đặc Biệt' : pkg.tag}
                  </span>
                )}
              </div>
              <div className="p-6 flex flex-col flex-1">
                <div className="flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-gray-800 mb-1">{pkg.name}</h3>
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <i className="fa-regular fa-clock"></i>
                        <span>{pkg.duration}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold text-[#008080]">
                        {pkg.currentPrice ? pkg.currentPrice : (pkg.prices && Object.values(pkg.prices)[0] ? `${Number(Object.values(pkg.prices)[0]).toLocaleString('vi-VN')}đ` : '')}
                      </p>
                      <p className="text-sm text-gray-500">/{pkg.duration}</p>
                    </div>
                  </div>
                  <div className="mb-2">
                    <span className="font-semibold text-gray-700">Bao gồm:</span>
                    <ul className="list-disc list-inside text-gray-600 text-sm mt-1">
                      {pkg.services.map((s, idx) => (
                        <li key={idx}>{s.name} ({s.duration})</li>
                      ))}
                    </ul>
                  </div>
                  <p className="text-gray-600 mb-2 text-sm line-clamp-3">{pkg.description}</p>
                  <div className="mb-2">
                    <span className="font-semibold text-gray-700">Lợi ích:</span>
                    <ul className="list-disc list-inside text-gray-600 text-sm mt-1">
                      {pkg.benefits.map((b, idx) => (
                        <li key={idx}>{b}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="mb-2">
                    <span className="font-semibold text-gray-700">Chuyên viên:</span>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {pkg.therapists.map((t, idx) => (
                        <div key={idx} className="flex items-center gap-1 bg-gray-100 rounded-full px-2 py-1 text-xs">
                          <img src={t.image} alt={t.name} className="w-6 h-6 rounded-full object-cover" />
                          <span>{t.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <button
                  className="w-full py-3 bg-[#008080] text-white rounded-lg hover:bg-[#006666] transition-colors duration-300 flex items-center justify-center gap-2 mt-2"
                  onClick={e => { e.stopPropagation(); navigate(`/packages/${pkg.id}`); }}
                >
                  <i className="fa-solid fa-calendar-plus"></i>
                  <span>Chọn gói</span>
                </button>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          totalItems={packages.length}
          itemsPerPage={itemsPerPage}
          onPageChange={setCurrentPage}
          containerRef="package-services"
          itemName="gói"
        />
      </div>
    </motion.section>
  );
};

export default PackageServiceCustomer;
