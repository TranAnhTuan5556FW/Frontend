import React, { useState } from "react";
import { motion, Variants, HTMLMotionProps } from "framer-motion";
import { Pagination } from '../../components/Pagination';
import { useNavigate } from 'react-router-dom';

// Types should be imported from a shared types file in a real project
export type Service = {
  id: number;
  name: string;
  prices: {
    [key: string]: number;
  };
  duration: string;
  description: string;
  rating: number;
  reviews: number;
  image: string;
  tag?: 'popular' | 'special';
  category: 'relaxation' | 'therapeutic' | 'specialty' | 'beauty';
  benefits: string[];
  therapists: {
    id: number;
    name: string;
    experience: string;
    image: string;
  }[];
};

export type Category = 'all' | 'relaxation' | 'therapeutic' | 'specialty';

interface IndividualServiceCustomerProps {
  services: Service[];
  categories: Category[];
  selectedCategory: Category;
  handleCategoryChange: (category: Category) => void;
  buttonMotionProps: HTMLMotionProps<"button">;
  staggerContainer: Variants;
  itemVariant: Variants;
}

const IndividualServiceCustomer: React.FC<IndividualServiceCustomerProps> = ({
  services,
  staggerContainer,
}) => {
  const navigate = useNavigate();
  // Thêm state cho phân trang
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6; // Số lượng dịch vụ mỗi trang

  // Tính toán các items cho trang hiện tại
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentServices = services.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(services.length / itemsPerPage);

  const handleServiceClick = (serviceId: string) => {
    navigate(`/services/${serviceId}`);
  };

  return (
    <motion.section 
      id="services-grid" 
      className="py-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
    >
      <div className="container mx-auto px-6">
        <motion.div 
          variants={staggerContainer}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8"
        >
          {currentServices.map((service) => (
            <motion.div
              key={service.id}
              className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 flex flex-col h-full"
              whileHover={{ scale: 1.02 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1 }}
            >
              <div className="relative">
                <img 
                  className="w-full h-56 object-cover rounded-t-xl" 
                  src={service.image} 
                  alt={service.name}
                />
                {service.tag && (
                  <span className={`absolute top-4 right-4 px-4 py-2 rounded-full text-sm font-medium shadow-md ${
                    service.tag === 'popular' 
                      ? 'bg-white text-[#008080] border border-[#008080]' 
                      : 'bg-[#008080] text-white'
                  }`}>
                    {service.tag}
                  </span>
                )}
              </div>
              <div className="p-6 flex flex-col flex-1">
                <div className="flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-gray-800 mb-1">{service.name}</h3>
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <i className="fa-regular fa-clock"></i>
                        <span>{service.duration}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold text-[#008080]">{service.prices['current']}</p>
                      {service.prices['old'] && (
                        <p className="text-sm text-gray-500 line-through">{service.prices['old']}</p>
                      )}
                    </div>
                  </div>
                  <p className="text-gray-600 mb-6 line-clamp-2 flex-1">{service.description}</p>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-2">
                      <div className="flex items-center">
                        <i className="fa-solid fa-star text-yellow-400 mr-1"></i>
                        <span className="font-medium">{service.rating}</span>
                      </div>
                      <span className="text-gray-400">|</span>
                      <span className="text-gray-500 text-sm">{service.reviews} đánh giá</span>
                    </div>
                    {service.category && (
                      <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm capitalize">
                        {service.category === 'relaxation' && 'Thư giãn'}
                        {service.category === 'therapeutic' && 'Trị liệu'}
                        {service.category === 'specialty' && 'Đặc biệt'}
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => handleServiceClick(service.id.toString())}
                    className="w-full py-3 bg-[#008080] text-white rounded-lg hover:bg-[#006666] transition-colors duration-300 flex items-center justify-center gap-2"
                  >
                    <i className="fa-solid fa-calendar-plus"></i>
                    <span>Đặt Lịch Ngay</span>
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Add Pagination component */}
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          totalItems={services.length}
          itemsPerPage={itemsPerPage}
          onPageChange={setCurrentPage}
          containerRef="services-grid"
          itemName="dịch vụ"
        />
      </div>
    </motion.section>
  );
};

export default IndividualServiceCustomer;
