import React, { useState, useEffect } from "react";
import Header from "../../components/HeaderCustomer";
import Footer from "../../components/FooterCustomer";
import {
  FaStar,
  FaUsers,
  FaSpa,
  FaCalendarCheck,
  FaArrowRight,
  FaFacebook,
  FaInstagram,
  FaTwitter,
  FaLinkedin
} from "react-icons/fa";

const ReviewsCustomerPage: React.FC = () => {
  const [rating, setRating] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    service: '',
    review: ''
  });

  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px'
    };
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fade-in');
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);
    document.querySelectorAll('.animate-on-scroll').forEach((element) => {
      observer.observe(element);
    });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Xử lý gửi đánh giá
    console.log({ ...formData, rating });
  };

  const reviews = [
    {
      id: 1,
      name: 'Sarah Johnson',
      avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg',
      rating: 5,
      comment: 'Trải nghiệm tuyệt vời! Massage cơ sâu chính xác là những gì tôi cần. Kỹ thuật viên rất chuyên nghiệp và chú ý đến nhu cầu của tôi.',
      service: 'Massage Cơ Sâu',
      date: '15 Tháng 3, 2025'
    },
    {
      id: 2,
      name: 'Michael Chen',
      avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
      rating: 4.5,
      comment: 'Massage Thụy Điển rất thư giãn. Không gian hoàn hảo và nhân viên rất thân thiện. Chắc chắn sẽ quay lại!',
      service: 'Massage Thụy Điển',
      date: '10 Tháng 3, 2025'
    },
    {
      id: 3,
      name: 'Emma Davis',
      avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-5.jpg',
      rating: 5,
      comment: 'Massage đá nóng tốt nhất mà tôi từng trải nghiệm! Kỹ thuật viên rất có kỹ năng và toàn bộ trải nghiệm rất bình yên. Rất đáng để thử!',
      service: 'Massage Đá Nóng',
      date: '5 Tháng 3, 2025'
    }
  ];

  const renderStars = (rating: number) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <FaStar
          key={i}
          className={`${i <= rating ? 'text-yellow-400' : 'text-gray-300'} text-xl`}
        />
      );
    }
    return stars;
  };

  return (
    <div className="min-h-screen bg-white">
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes scaleIn {
          from { transform: scale(0.9); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        @keyframes float {
          0% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
          100% { transform: translateY(0px); }
        }
        .animate-fade-in {
          animation: fadeIn 0.8s ease-out forwards;
        }
        .animate-scale-in {
          animation: scaleIn 0.5s ease-out forwards;
        }
        .float-animation {
          animation: float 3s ease-in-out infinite;
        }
      `}</style>
      <Header />
      {/* Reviews Hero Section */}
      <section id="reviews-hero" className="pt-24 h-[400px] relative overflow-hidden bg-[#008080] animate-on-scroll opacity-0">
        <div className="container mx-auto px-6 h-full flex items-center">
          <div className="text-white">
            <h2 className="text-5xl font-bold mb-6 transform transition-all duration-700 hover:scale-105">Đánh Giá Từ Khách Hàng</h2>
            <p className="text-xl text-white/90">Xem những chia sẻ từ khách hàng về hành trình thư giãn cùng chúng tôi.</p>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-full h-full bg-[#e6e6fa]/5 -z-10"></div>
      </section>
      {/* Reviews Stats Section */}
      <section id="reviews-stats" className="py-16 bg-white animate-on-scroll opacity-0">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            {[
              { icon: <FaStar />, value: "4.8", text: "Đánh Giá Trung Bình" },
              { icon: <FaUsers />, value: "5K+", text: "Khách Hàng Hài Lòng" },
              { icon: <FaSpa />, value: "10+", text: "Dịch Vụ Cung Cấp" },
              { icon: <FaCalendarCheck />, value: "5+", text: "Năm Kinh Nghiệm" }
            ].map((stat, index) => (
              <div key={index}
                className="p-6 rounded-xl bg-gray-50 transform transition-all duration-300 hover:shadow-xl hover:-translate-y-2 float-animation"
                style={{ animationDelay: `${index * 200}ms` }}>
                <div className="text-[#008080] mb-2 transform transition-all duration-300 hover:scale-110">
                  {React.cloneElement(stat.icon, { className: "text-3xl mx-auto" })}
                </div>
                <h3 className="text-4xl font-bold text-gray-800 mb-2">{stat.value}</h3>
                <p className="text-gray-600">{stat.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      {/* Customer Reviews Section */}
      <section id="customer-reviews" className="py-20 bg-gray-50 animate-on-scroll opacity-0">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8">
            {reviews.map((review, index) => (
              <div
                key={review.id}
                className="bg-white p-8 rounded-xl shadow-lg transform transition-all duration-300 hover:shadow-2xl hover:-translate-y-2"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <div className="flex items-center mb-4">
                  <img src={review.avatar} alt="Customer" className="w-12 h-12 rounded-full transform transition-all duration-300 hover:scale-110" />
                  <div className="ml-4">
                    <h4 className="font-bold text-gray-800">{review.name}</h4>
                    <div className="flex">
                      {renderStars(Math.round(review.rating))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600">{review.comment}</p>
                <p className="mt-4 text-sm text-gray-500">{review.service} - {review.date}</p>
              </div>
            ))}
          </div>
          {/* More Reviews Button */}
          <div className="text-center mt-12">
            <button className="px-8 py-3 bg-[#008080] text-white rounded-lg transform transition-all duration-300 hover:bg-[#006666] hover:shadow-lg hover:-translate-y-1 inline-flex items-center">
              Xem Thêm Đánh Giá
              <FaArrowRight className="ml-2 transform transition-all duration-300 group-hover:translate-x-1" />
            </button>
          </div>
        </div>
      </section>
      {/* Leave Review Section */}
      <section id="leave-review" className="py-20 bg-white animate-on-scroll opacity-0">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-800 mb-4 transform transition-all duration-300 hover:scale-105">Chia Sẻ Trải Nghiệm Của Bạn</h3>
            <p className="text-gray-600">Chúng tôi đánh giá cao phản hồi của bạn! Hãy cho chúng tôi biết về trải nghiệm của bạn.</p>
          </div>
          <div className="max-w-2xl mx-auto">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="transform transition-all duration-300 hover:shadow-md rounded-lg">
                <label className="block text-gray-700 mb-2">Họ Tên</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 transition-all duration-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] focus:shadow-lg outline-none"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Dịch Vụ Đã Sử Dụng</label>
                <select
                  name="service"
                  value={formData.service}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none"
                >
                  <option value="">Chọn dịch vụ</option>
                  <option value="deep-tissue">Massage Cơ Sâu</option>
                  <option value="swedish">Massage Thụy Điển</option>
                  <option value="hot-stone">Massage Đá Nóng</option>
                  <option value="aromatherapy">Massage Tinh Dầu</option>
                </select>
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Đánh Giá Của Bạn</label>
                <div className="flex space-x-2 text-2xl">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <FaStar
                      key={star}
                      className={`cursor-pointer ${star <= rating ? 'text-yellow-400' : 'text-gray-300'}`}
                      onClick={() => setRating(star)}
                    />
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Nội Dung Đánh Giá</label>
                <textarea
                  name="review"
                  value={formData.review}
                  onChange={handleInputChange}
                  rows={4}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none"
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full py-3 bg-[#008080] text-white rounded-lg transform transition-all duration-300 hover:bg-[#006666] hover:shadow-lg hover:-translate-y-1"
              >
                Gửi Đánh Giá
              </button>
            </form>
          </div>
        </div>
      </section>
      {/* Social Media Section */}
      <section id="social-media" className="py-16 bg-gray-50 animate-on-scroll opacity-0">
        <div className="container mx-auto px-6 text-center">
          <h3 className="text-3xl font-bold mb-8 text-gray-800">Kết Nối Với Chúng Tôi</h3>
          <div className="flex justify-center space-x-8">
            {[
              { Icon: FaFacebook, href: "#" },
              { Icon: FaInstagram, href: "#" },
              { Icon: FaTwitter, href: "#" },
              { Icon: FaLinkedin, href: "#" }
            ].map((social, index) => (
              <a
                key={index}
                href={social.href}
                className="text-[#008080] transform transition-all duration-300 hover:text-[#006666] hover:scale-125"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <social.Icon className="text-4xl" />
              </a>
            ))}
          </div>
        </div>
      </section>
      {/* Map Section */}
      <section id="map" className="h-[400px] relative animate-on-scroll opacity-0">
        <img
          className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
          src="https://storage.googleapis.com/uxpilot-auth.appspot.com/47945bb2b7-4c7fb0c50d2ac6edbf0a.png"
          alt="Bản đồ vị trí spa"
        />
        <div className="absolute inset-0 bg-black/20 transition-opacity duration-300 hover:bg-black/10"></div>
      </section>
      <Footer />
    </div>
  );
};

export default ReviewsCustomerPage;
