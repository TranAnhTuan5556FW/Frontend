import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { FaTimes, FaPlus } from "react-icons/fa";
import Header from "../../components/HeaderCustomer";
import Footer from "../../components/FooterCustomer";
import {
  appointmentsData,
  getAppointmentStatus,
  AppointmentData,
  parseVietnameseDate
} from "../../../data/appointmentsData";

// Modal xác nhận hủy lịch hẹn
const CancellationModal = ({ isOpen, onClose, onConfirm, appointment }: {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (id: number) => void;
  appointment: AppointmentData | null;
}) => (
  <AnimatePresence>
    {isOpen && appointment && (
      <>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 z-40"
          onClick={onClose}
        />
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed inset-x-0 top-[20%] mx-auto max-w-md z-50 p-6"
        >
          <div className="bg-white rounded-xl shadow-xl p-8">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
                <FaTimes className="text-red-500 text-xl" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Xác nhận hủy lịch hẹn</h3>
              <p className="text-gray-600 mb-6">
                Bạn có chắc chắn muốn hủy lịch hẹn này?
                <br />
                <span className="font-medium">
                  {appointment.service} - {appointment.date} {appointment.time}
                </span>
              </p>
              <div className="flex gap-4 justify-center">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={onClose}
                  className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Đóng
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => onConfirm(appointment.id)}
                  className="px-6 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
                >
                  Xác nhận hủy
                </motion.button>
              </div>
            </div>
          </div>
        </motion.div>
      </>
    )}
  </AnimatePresence>
);

// Modal thành công
const SuccessModal = ({ isOpen, message }: {
  isOpen: boolean;
  onClose: () => void;
  message: string;
}) => (
  <AnimatePresence>
    {isOpen && (
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="fixed top-24 left-0 right-0 z-50"
      >
        <div className="container mx-auto px-6 max-w-md">
          <div className="bg-white rounded-xl shadow-lg p-6 text-center">
            <div className="text-[#008080] mb-4">
              <i className="fa-solid fa-circle-check text-4xl"></i>
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Thành công!</h3>
            <p className="text-gray-600">{message}</p>
          </div>
        </div>
      </motion.div>
    )}
  </AnimatePresence>
);

// Card lịch hẹn
const AppointmentCard = ({ appointment, onCancelClick }: {
  appointment: AppointmentData;
  onCancelClick: (appointment: AppointmentData) => void;
}) => {
  const navigate = useNavigate();
  const currentStatus = getAppointmentStatus(appointment);

  const statusColors: Record<string, string> = {
    upcoming: 'bg-green-500',
    past: 'bg-gray-500',
    cancelled: 'bg-red-500'
  };

  const statusLabels: Record<string, string> = {
    upcoming: 'Sắp tới',
    past: 'Đã qua',
    cancelled: 'Đã hủy'
  };

  const handleReschedule = () => {
    const bookingInfo = {
      serviceName: appointment.service,
      duration: appointment.duration,
      therapist: {
        name: appointment.therapist,
        experience: '5+ years'
      },
      price: 500000,
      isRescheduling: true,
      originalAppointmentId: appointment.id
    };
    localStorage.setItem('bookingInfo', JSON.stringify(bookingInfo));
    navigate(`/booking/${appointment.id}`);
  };

  const handleViewDetails = () => {
    navigate(`/customer/appointments/${appointment.id}`);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-3 h-3 ${statusColors[currentStatus]} rounded-full`}></div>
            <span className={`${currentStatus === 'upcoming' ? 'text-green-500' : currentStatus === 'cancelled' ? 'text-red-500' : 'text-gray-500'} font-semibold`}>
              {statusLabels[currentStatus]}
            </span>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <p className="text-gray-600 mb-1">Ngày & Giờ</p>
              <p className="font-semibold">{appointment.date}</p>
              <p className="font-semibold">{appointment.time}</p>
            </div>
            <div>
              <p className="text-gray-600 mb-1">Dịch vụ</p>
              <p className="font-semibold">{appointment.service}</p>
              <p className="text-gray-600">{appointment.duration} phút</p>
            </div>
            <div>
              <p className="text-gray-600 mb-1">Kỹ thuật viên</p>
              {appointment.therapists && Array.isArray(appointment.therapists) && appointment.therapists.length > 0 ? (
                <p className="font-semibold">
                  {appointment.therapists.map((t: any) => t.name).join(', ')}
                </p>
              ) : (
                <p className="font-semibold">{appointment.therapist}</p>
              )}
            </div>
          </div>
        </div>
        <div className="flex flex-col md:flex-row gap-3">
          {currentStatus === 'upcoming' && (
            <>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleReschedule}
                className="px-6 py-2 bg-[#008080] text-white rounded-lg hover:bg-[#006666]"
              >
                Đổi lịch
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleViewDetails}
                className="px-6 py-2 bg-[#e6e6fa] text-[#008080] rounded-lg hover:bg-[#e6e6fa]/80"
              >
                Xem chi tiết
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onCancelClick(appointment)}
                className="px-6 py-2 border border-red-500 text-red-500 rounded-lg hover:bg-red-50"
              >
                Hủy
              </motion.button>
            </>
          )}
          {currentStatus !== 'upcoming' && (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleViewDetails}
              className="px-6 py-2 bg-[#e6e6fa] text-[#008080] rounded-lg hover:bg-[#e6e6fa]/80"
            >
              Xem chi tiết
            </motion.button>
          )}
        </div>
      </div>
    </div>
  );
};

// Cài đặt thông báo
const NotificationSetting = ({ title, description, defaultChecked = true }: {
  title: string;
  description: string;
  defaultChecked?: boolean;
}) => (
  <div className="flex items-center justify-between py-4 border-b">
    <div>
      <h4 className="font-semibold text-gray-800">{title}</h4>
      <p className="text-gray-600">{description}</p>
    </div>
    <label className="relative inline-flex items-center cursor-pointer">
      <input type="checkbox" className="sr-only peer" defaultChecked={defaultChecked} />
      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#008080]"></div>
    </label>
  </div>
);

const AppointmentCustomerPage: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState<'upcoming' | 'past' | 'cancelled'>('upcoming');
  const [user, setUser] = useState<any>(null);
  const [selectedAppointment, setSelectedAppointment] = useState<AppointmentData | null>(null);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [appointments, setAppointments] = useState<AppointmentData[]>([]);
  const [currentPage, setCurrentPage] = useState({
    upcoming: 1,
    past: 1,
    cancelled: 1
  });
  const appointmentsPerPage = 3;
  const navigate = useNavigate();

  // Helper function for getting full JS Date object from appointment
  const getFullDate = (app: AppointmentData): Date => {
    let dt;
    if (/^\d{4}-\d{2}-\d{2}$/.test(app.date)) { // Format YYYY-MM-DD
      dt = new Date(app.date + 'T' + (app.time || '00:00:00'));
    } else { // Format "DD Tháng MM, YYYY"
      dt = parseVietnameseDate(app.date);
      if (app.time) {
        const [hour, minute] = app.time.split(':').map(Number);
        dt.setHours(hour);
        dt.setMinutes(minute);
        dt.setSeconds(0);
      }
    }
    return dt;
  };

  // Hàm load appointments
  const loadAppointments = () => {
    const userData = localStorage.getItem('user');
    if (!userData) {
      localStorage.setItem('redirectAfterLogin', '/appointments');
      navigate('/auth');
      return;
    }
    setUser(JSON.parse(userData));
    
    const updatedAppointments = appointmentsData.map(appointment => ({
      ...appointment,
      status: getAppointmentStatus(appointment)
    }));
    
    const userAppointments = JSON.parse(localStorage.getItem('userAppointments') || '[]');
    
    const allAppointments = [
      ...updatedAppointments,
      ...userAppointments.map((a: any) => ({ // Cast to any if userAppointments structure is not strictly AppointmentData
        ...a,
        status: getAppointmentStatus(a as AppointmentData) 
      }))
    ].sort((a, b) => {
      const dateA = getFullDate(a as AppointmentData);
      const dateB = getFullDate(b as AppointmentData);
      return dateB.getTime() - dateA.getTime(); // Sắp xếp giảm dần (ngày xa nhất/mới nhất lên đầu)
    });
    setAppointments(allAppointments);
  };

  useEffect(() => {
    loadAppointments(); // Load lần đầu
    window.scrollTo(0, 0);

    // Thêm event listener cho sự kiện focus
    const handleFocus = () => {
      loadAppointments(); // Load lại khi focus
    };
    window.addEventListener('focus', handleFocus);

    // Cleanup event listener
    return () => {
      window.removeEventListener('focus', handleFocus);
    };
  }, [navigate]); // navigate vẫn cần thiết nếu auth redirect

  // Lấy danh sách đã lọc theo filter
  const filteredAppointments = appointments.filter(
    appointment => getAppointmentStatus(appointment) === activeFilter
  );

  // Sắp xếp lại cho mục "Sắp tới" theo ngày gần nhất đến xa nhất
  if (activeFilter === 'upcoming') {
    filteredAppointments.sort((a, b) => {
      const dateA = getFullDate(a);
      const dateB = getFullDate(b);
      return dateA.getTime() - dateB.getTime(); // Sắp xếp tăng dần (ngày gần nhất lên đầu)
    });
  }

  // Tính tổng số trang
  const totalPages = Math.ceil(filteredAppointments.length / appointmentsPerPage);

  // Lấy danh sách lịch hẹn cho trang hiện tại
  const paginatedAppointments = filteredAppointments.slice(
    (currentPage[activeFilter] - 1) * appointmentsPerPage,
    currentPage[activeFilter] * appointmentsPerPage
  );

  // Khi đổi filter thì về trang 1
  const handleFilterChange = (filter: 'upcoming' | 'past' | 'cancelled') => {
    setActiveFilter(filter);
    setCurrentPage(prev => ({ ...prev, [filter]: 1 }));
  };

  // Chuyển trang
  const handlePageChange = (direction: number) => {
    setCurrentPage(prev => {
      const newPage = prev[activeFilter] + direction;
      if (newPage < 1 || newPage > totalPages) return prev;
      return { ...prev, [activeFilter]: newPage };
    });
  };

  const handleNewBooking = () => {
    navigate('/services');
  };

  const handleCancelClick = (appointment: AppointmentData) => {
    setSelectedAppointment(appointment);
    setShowCancelModal(true);
  };

  const handleCancelConfirm = (appointmentId: number) => {
    setAppointments(appointments.map(app =>
      app.id === appointmentId
        ? { ...app, status: 'cancelled' as const }
        : app
    ));
    setShowCancelModal(false);
    setShowSuccessModal(true);
    setTimeout(() => {
      setShowSuccessModal(false);
    }, 3000);
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="pt-24">
        <div className="container mx-auto px-6 py-8">
          {/* Appointment Management Header */}
          <motion.section className="mb-8" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div className="flex justify-between items-center">
              <motion.h2 className="text-3xl font-bold text-gray-800" initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>Lịch hẹn của tôi</motion.h2>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
                onClick={handleNewBooking}
                className="px-6 py-3 bg-[#008080] text-white rounded-lg hover:bg-[#006666] flex items-center gap-2"
              >
                <FaPlus />
                Đặt lịch mới
              </motion.button>
            </div>
          </motion.section>

          {/* Appointment Filters */}
          <motion.section className="mb-8" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }}>
            <div className="flex flex-wrap gap-4">
              {['upcoming', 'past', 'cancelled'].map((filter) => (
                <motion.button
                  key={filter}
                  className={`px-6 py-2 rounded-lg ${
                    activeFilter === filter
                      ? 'bg-[#008080] text-white'
                      : 'border border-gray-300 text-gray-600 hover:border-[#008080]'
                  }`}
                  onClick={() => handleFilterChange(filter as any)}
                  whileHover={{ scale: 1.07 }}
                  whileTap={{ scale: 0.97 }}
                  transition={{ type: 'spring', stiffness: 300 }}
                >
                  {filter === 'upcoming' ? 'Sắp tới' : filter === 'past' ? 'Đã qua' : 'Đã hủy'}
                </motion.button>
              ))}
            </div>
          </motion.section>

          {/* Appointments List */}
          <motion.section className="space-y-6" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
            {paginatedAppointments.length === 0 ? (
              <motion.div className="text-center py-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
                <p className="text-gray-600">Không có lịch hẹn nào trong mục này</p>
              </motion.div>
            ) : (
              paginatedAppointments.map((appointment, idx) => (
                <motion.div
                  key={appointment.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * idx }}
                >
                  <AppointmentCard
                    appointment={appointment}
                    onCancelClick={handleCancelClick}
                  />
                </motion.div>
              ))
            )}
            {/* Pagination Controls */}
            {totalPages > 1 && (
              <div className="flex justify-center items-center gap-4 mt-6">
                <motion.button
                  className="px-4 py-2 border rounded disabled:opacity-50"
                  onClick={() => handlePageChange(-1)}
                  disabled={currentPage[activeFilter] === 1}
                  whileHover={{ scale: 1.07 }}
                  whileTap={{ scale: 0.97 }}
                >
                  Trang trước
                </motion.button>
                <span>
                  Trang {currentPage[activeFilter]} / {totalPages}
                </span>
                <motion.button
                  className="px-4 py-2 border rounded disabled:opacity-50"
                  onClick={() => handlePageChange(1)}
                  disabled={currentPage[activeFilter] === totalPages}
                  whileHover={{ scale: 1.07 }}
                  whileTap={{ scale: 0.97 }}
                >
                  Trang sau
                </motion.button>
              </div>
            )}
          </motion.section>

          {/* Notifications Section */}
          <motion.section className="mt-12" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }}>
            <h3 className="text-2xl font-bold text-gray-800 mb-6">Cài đặt thông báo</h3>
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="space-y-6">
                <NotificationSetting
                  title="Nhắc nhở qua Email"
                  description="Nhận thông báo lịch hẹn qua email"
                />
                <NotificationSetting
                  title="Thông báo SMS"
                  description="Nhận tin nhắn về lịch hẹn của bạn"
                />
                <div className="flex items-center justify-between py-4">
                  <div>
                    <h4 className="font-semibold text-gray-800">Thời gian nhắc nhở</h4>
                    <p className="text-gray-600">Chọn thời điểm nhận thông báo</p>
                  </div>
                  <select className="px-4 py-2 border border-gray-300 rounded-lg focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none">
                    <option>24 giờ trước</option>
                    <option>12 giờ trước</option>
                    <option>2 giờ trước</option>
                  </select>
                </div>
              </div>
            </div>
          </motion.section>
        </div>
      </main>

      {/* Modals */}
      <CancellationModal
        isOpen={showCancelModal}
        onClose={() => setShowCancelModal(false)}
        onConfirm={handleCancelConfirm}
        appointment={selectedAppointment}
      />

      <SuccessModal
        isOpen={showSuccessModal}
        onClose={() => setShowSuccessModal(false)}
        message="Lịch hẹn đã được hủy thành công!"
      />

      <Footer />
    </div>
  );
};

export default AppointmentCustomerPage;
