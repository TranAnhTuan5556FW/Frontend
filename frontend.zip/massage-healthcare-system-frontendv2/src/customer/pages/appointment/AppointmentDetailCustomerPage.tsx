import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import HeaderCustomer from "../../components/HeaderCustomer";
import FooterCustomer from "../../components/FooterCustomer";
import { AppointmentData, getAppointmentById, getAppointmentStatus } from "../../../data/appointmentsData";

const AppointmentDetailCustomerPage: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [appointment, setAppointment] = useState<AppointmentData | null>(null);
  const [status, setStatus] = useState<'upcoming' | 'past' | 'cancelled'>('upcoming');

  useEffect(() => {
    console.log('Current appointment ID:', id);
    if (id) {
      const appointmentData = getAppointmentById(Number(id));
      console.log('Found appointment:', appointmentData);
      if (appointmentData) {
        setAppointment(appointmentData);
        setStatus(getAppointmentStatus(appointmentData));
      } else {
        console.log('Appointment not found, redirecting...');
        navigate('/customer/appointments');
      }
    }
  }, [id, navigate]);

  const handleBack = () => {
    navigate('/customer/appointments');
  };

  const handleReschedule = () => {
    if (appointment) {
      const bookingInfo = {
        serviceName: appointment.service,
        duration: appointment.duration,
        therapist: {
          name: appointment.therapist,
          experience: '5+ years'
        },
        price: appointment.servicePrice || 500000,
        isRescheduling: true,
        originalAppointmentId: appointment.id
      };
      localStorage.setItem('bookingInfo', JSON.stringify(bookingInfo));
      navigate(`/booking/${appointment.id}`);
    }
  };

  if (!appointment) {
    return (
      <div className="min-h-screen flex flex-col">
        <HeaderCustomer />
        <main className="flex-grow pt-24 pb-12">
          <div className="container mx-auto px-6 max-w-3xl">
            <div className="text-center">
              <p className="text-gray-600">Đang tải thông tin lịch hẹn...</p>
            </div>
          </div>
        </main>
        <FooterCustomer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <HeaderCustomer />
      <main className="flex-grow pt-24 pb-12">
        <div className="container mx-auto px-6 max-w-3xl">
            {/* Back Button */}
            <button
              onClick={handleBack}
              className="mb-6 flex items-center gap-2 text-[#008080] hover:text-[#006666] transition-colors"
            >
              <i className="fa-solid fa-arrow-left"></i>
              <span>Quay lại Lịch hẹn</span>
            </button>

            {/* Appointment Detail Card */}
            <section id="appointment-detail-card" className="bg-white rounded-xl shadow-lg p-8 mb-10">
                <div className="flex flex-col md:flex-row items-start md:items-center md:justify-between mb-6">
                    <div>
                        <div className="flex items-center gap-3 mb-2">
                            <div className={`w-3 h-3 ${
                              status === 'upcoming' ? 'bg-green-500' : 
                              status === 'cancelled' ? 'bg-red-500' : 
                              'bg-gray-500'
                            } rounded-full`}></div>
                            <span className={`${
                              status === 'upcoming' ? 'text-green-500' : 
                              status === 'cancelled' ? 'text-red-500' : 
                              'text-gray-500'
                            } font-semibold text-lg`}>
                              {status === 'upcoming' ? 'Sắp tới' : 
                               status === 'cancelled' ? 'Đã hủy' : 
                               'Đã qua'}
                            </span>
                        </div>
                        <h2 className="text-3xl font-bold text-gray-800 mb-1">{appointment.service}</h2>
                        <p className="text-gray-600">{appointment.duration} phút</p>
                    </div>
                    {status === 'upcoming' && (
                      <div className="flex gap-3 mt-6 md:mt-0">
                          <button 
                            onClick={handleReschedule}
                            className="px-6 py-2 bg-[#008080] text-white rounded-lg hover:bg-[#006666] text-lg"
                          >
                              Đổi lịch
                          </button>
                          <button className="px-6 py-2 border border-red-500 text-red-500 rounded-lg hover:bg-red-50 text-lg">
                              Hủy
                          </button>
                      </div>
                    )}
                </div>
                <div className="grid md:grid-cols-2 gap-8">
                    <div>
                        <h4 className="text-[#008080] font-bold mb-2 text-xl">Ngày & Giờ</h4>
                        <div className="flex items-center gap-3 mb-2">
                            <i className="fa-regular fa-calendar-days text-[#008080] text-xl"></i>
                            <span className="font-semibold text-gray-800 text-lg">{appointment.date}</span>
                        </div>
                        <div className="flex items-center gap-3">
                            <i className="fa-regular fa-clock text-[#008080] text-xl"></i>
                            <span className="font-semibold text-gray-800 text-lg">{appointment.time}</span>
                        </div>
                    </div>
                    <div>
                        <h4 className="text-[#008080] font-bold mb-2 text-xl">Kỹ thuật viên</h4>
                        <div className="flex items-center gap-4">
                            <img src={appointment.staffAvatar || "https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-6.jpg"} 
                                 alt="Kỹ thuật viên" 
                                 className="w-14 h-14 rounded-full object-cover shadow-md" />
                            <div>
                                <span className="font-semibold text-gray-800 text-lg block">{appointment.therapist}</span>
                                <span className="text-gray-500">Kỹ thuật viên chuyên nghiệp</span>
                                <div className="flex gap-1 mt-1">
                                    <i className="fa-solid fa-star text-yellow-400"></i>
                                    <i className="fa-solid fa-star text-yellow-400"></i>
                                    <i className="fa-solid fa-star text-yellow-400"></i>
                                    <i className="fa-solid fa-star text-yellow-400"></i>
                                    <i className="fa-regular fa-star text-yellow-400"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Appointment Location */}
                <div className="mt-8">
                    <h4 className="text-[#008080] font-bold mb-2 text-xl">Địa điểm</h4>
                    <div className="flex items-center gap-3">
                        <i className="fa-solid fa-location-dot text-[#008080] text-xl"></i>
                        <span className="font-semibold text-gray-800 text-lg">123 Đường Thư Giãn, Thành phố Wellness, WC 12345</span>
                    </div>
                </div>

                {/* Notes */}
                <div className="mt-8">
                    <h4 className="text-[#008080] font-bold mb-2 text-xl">Ghi chú lịch hẹn</h4>
                    <div className="bg-[#e6e6fa]/60 rounded-lg p-4 text-gray-700 text-lg">
                        {appointment.notes || "Vui lòng đến sớm 10 phút. Hãy cho chúng tôi biết nếu bạn có yêu cầu đặc biệt hoặc vấn đề về sức khỏe."}
                    </div>
                </div>
            </section>

            {/* Chỉ hiển thị cho lịch hẹn sắp tới */}
            {status === 'upcoming' && (
                <>
                    {/* Appointment Timeline */}
                    <section id="appointment-timeline" className="mb-10">
                        <h3 className="text-2xl font-bold text-gray-800 mb-6">Tiến trình lịch hẹn</h3>
                        <div className="relative pl-8">
                            <div className="absolute top-0 bottom-0 left-2 w-1 bg-[#e6e6fa] rounded-full"></div>
                            <div className="space-y-8">
                                <div className="flex items-start gap-4 relative">
                                    <div className="relative z-10">
                                        <div className="w-5 h-5 bg-[#008080] rounded-full flex items-center justify-center">
                                            <i className="fa-solid fa-check text-white text-xs"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <p className="font-semibold text-gray-900">Đã đặt lịch hẹn</p>
                                        <p className="text-gray-500 text-base">5 Tháng 3, 2025, 10:00</p>
                                    </div>
                                </div>
                                <div className="flex items-start gap-4 relative">
                                    <div className="relative z-10">
                                        <div className="w-5 h-5 bg-[#008080] rounded-full flex items-center justify-center">
                                            <i className="fa-solid fa-envelope text-white text-xs"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <p className="font-semibold text-gray-900">Đã gửi email xác nhận</p>
                                        <p className="text-gray-500 text-base">5 Tháng 3, 2025, 10:01</p>
                                    </div>
                                </div>
                                <div className="flex items-start gap-4 relative">
                                    <div className="relative z-10">
                                        <div className="w-5 h-5 bg-gray-300 rounded-full flex items-center justify-center">
                                            <i className="fa-regular fa-clock text-white text-xs"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <p className="font-semibold text-gray-900">Lịch hẹn sắp tới</p>
                                        <p className="text-gray-500 text-base">{appointment.date}, {appointment.time}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    {/* Reminders/Notifications */}
                    <section id="appointment-reminders" className="mb-12">
                        <h3 className="text-2xl font-bold text-gray-800 mb-6">Nhắc nhở & Thông báo</h3>
                        <div className="bg-white rounded-xl shadow-lg p-6">
                            <div className="space-y-6">
                                <div className="flex items-center justify-between py-4 border-b">
                                    <div>
                                        <h4 className="font-semibold text-gray-800">Nhắc nhở qua Email</h4>
                                        <p className="text-gray-600">Sẽ được gửi 24 giờ trước lịch hẹn</p>
                                    </div>
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" className="sr-only peer" defaultChecked />
                                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#008080]"></div>
                                    </label>
                                </div>
                                <div className="flex items-center justify-between py-4">
                                    <div>
                                        <h4 className="font-semibold text-gray-800">Nhắc nhở qua SMS</h4>
                                        <p className="text-gray-600">Sẽ được gửi 2 giờ trước lịch hẹn</p>
                                    </div>
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" className="sr-only peer" defaultChecked />
                                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#008080]"></div>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </section>
                </>
            )}
        </div>
      </main>
      <FooterCustomer />
    </div>
  );
};

export default AppointmentDetailCustomerPage;
