import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../../components/HeaderCustomer";
import Footer from "../../components/FooterCustomer";
import { FaSearch, FaCheck, FaTimes, FaClock, FaDollarSign } from "react-icons/fa";
import { motion } from "framer-motion";
import mockBookings from "../../../data/historyAppointmentData";

const BookingHistoryCustomerPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [timeFilter, setTimeFilter] = useState("last-30-days");
  const [bookings, setBookings] = useState<any[]>([]);

  useEffect(() => {
    const user = localStorage.getItem("user");
    if (!user) {
      localStorage.setItem("redirectAfterLogin", "/booking-history");
      navigate("/auth");
      return;
    }
    setBookings(mockBookings);
  }, [navigate]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const stats = {
    completed: bookings.filter((b) => b.status === "completed").length,
    cancelled: bookings.filter((b) => b.status === "cancelled").length,
    rescheduled: bookings.filter((b) => b.status === "rescheduled").length,
    totalSpent: bookings.reduce((sum, b) => (b.status === "completed" ? sum + b.amount : sum), 0),
  };

  const handleBookAgain = (serviceId: number) => {
    navigate(`/booking/${serviceId}`);
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed":
        return "Đã hoàn thành";
      case "cancelled":
        return "Đã hủy";
      case "rescheduled":
        return "Đã đổi lịch";
      default:
        return status;
    }
  };

  // Hàm lọc bookings theo searchTerm và timeFilter
  const filterBookings = () => {
    // Lọc theo searchTerm
    let filtered = bookings.filter((booking) => {
      const search = searchTerm.toLowerCase();
      return (
        booking.service.toLowerCase().includes(search) ||
        booking.therapist.toLowerCase().includes(search) ||
        booking.date.toLowerCase().includes(search)
      );
    });

    // Lọc theo timeFilter
    const now = new Date();
    filtered = filtered.filter((booking) => {
      // Giả sử booking.date có dạng "1 Tháng 3, 2025"
      const [day, , month, year] = booking.date.replace(",", "").split(" ");
      const monthMap: Record<string, number> = {
        "1": 0, "2": 1, "3": 2, "4": 3, "5": 4, "6": 5, "7": 6, "8": 7, "9": 8, "10": 9, "11": 10, "12": 11
      };
      const bookingDate = new Date(parseInt(year), monthMap[String(month)], parseInt(day));
      let compareDate = new Date(now);
      switch (timeFilter) {
        case "last-30-days":
          compareDate.setDate(now.getDate() - 30);
          break;
        case "last-3-months":
          compareDate.setMonth(now.getMonth() - 3);
          break;
        case "last-6-months":
          compareDate.setMonth(now.getMonth() - 6);
          break;
        case "last-year":
          compareDate.setFullYear(now.getFullYear() - 1);
          break;
        default:
          return true;
      }
      return bookingDate >= compareDate && bookingDate <= now;
    });
    return filtered;
  };

  const filteredBookings = filterBookings();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="pt-24">
        <div className="container mx-auto px-6 py-8">
          {/* Booking History Header */}
          <motion.section id="history-header" className="mb-8" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <motion.h2 className="text-3xl font-bold text-gray-800" initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>Lịch Sử Đặt Lịch</motion.h2>
              <div className="flex gap-4 w-full md:w-auto">
                <div className="relative w-full md:w-auto">
                  <input
                    type="text"
                    placeholder="Tìm kiếm lịch hẹn..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none w-full md:w-64"
                  />
                  <FaSearch className="absolute left-3 top-3 text-gray-400" />
                </div>
                <select
                  value={timeFilter}
                  onChange={(e) => setTimeFilter(e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none"
                >
                  <option value="last-30-days">30 ngày qua</option>
                  <option value="last-3-months">3 tháng qua</option>
                  <option value="last-6-months">6 tháng qua</option>
                  <option value="last-year">1 năm qua</option>
                </select>
              </div>
            </div>
          </motion.section>

          {/* History Stats */}
          <motion.section id="history-stats" className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }}>
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <FaCheck className="text-green-500 text-xl" />
                </div>
                <div>
                  <p className="text-gray-600">Đã hoàn thành</p>
                  <p className="text-2xl font-bold">{stats.completed}</p>
                </div>
              </div>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                  <FaTimes className="text-red-500 text-xl" />
                </div>
                <div>
                  <p className="text-gray-600">Đã hủy</p>
                  <p className="text-2xl font-bold">{stats.cancelled}</p>
                </div>
              </div>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <FaClock className="text-blue-500 text-xl" />
                </div>
                <div>
                  <p className="text-gray-600">Đã đổi lịch</p>
                  <p className="text-2xl font-bold">{stats.rescheduled}</p>
                </div>
              </div>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <FaDollarSign className="text-purple-500 text-xl" />
                </div>
                <div>
                  <p className="text-gray-600">Tổng chi tiêu</p>
                  <p className="text-2xl font-bold">{stats.totalSpent.toLocaleString('vi-VN')}đ</p>
                </div>
              </div>
            </div>
          </motion.section>

          {/* Appointment History List */}
          <motion.section id="history-list" className="bg-white rounded-xl shadow-lg overflow-hidden" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Ngày</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Dịch vụ</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Kỹ thuật viên</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Số tiền</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Trạng thái</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-600">Thao tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredBookings.map((booking, idx) => (
                    <motion.tr
                      key={booking.id}
                      className="hover:bg-gray-50"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.05 * idx }}
                    >
                      <td className="px-6 py-4">
                        <p className="font-semibold">{booking.date}</p>
                        <p className="text-gray-600">{booking.time}</p>
                      </td>
                      <td className="px-6 py-4">
                        <p className="font-semibold">{booking.service}</p>
                        <p className="text-gray-600">{booking.duration}</p>
                      </td>
                      <td className="px-6 py-4">{booking.therapist}</td>
                      <td className="px-6 py-4">{booking.amount.toLocaleString('vi-VN')}đ</td>
                      <td className="px-6 py-4">
                        <span
                          className={`px-3 py-1 rounded-full text-sm ${
                            booking.status === "completed"
                              ? "bg-green-100 text-green-700"
                              : booking.status === "cancelled"
                              ? "bg-red-100 text-red-700"
                              : "bg-blue-100 text-blue-700"
                          }`}
                        >
                          {getStatusText(booking.status)}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <motion.button
                          onClick={() => handleBookAgain(booking.id)}
                          className="text-[#008080] hover:text-[#006666]"
                          whileHover={{ scale: 1.07 }}
                          whileTap={{ scale: 0.97 }}
                        >
                          Đặt lại
                        </motion.button>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* Pagination */}
            <div className="px-6 py-4 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <p className="text-gray-600">Hiển thị 1-{filteredBookings.length} trong số {bookings.length} lịch hẹn</p>
                <div className="flex gap-2">
                  <motion.button className="px-4 py-2 border border-gray-300 rounded-lg hover:border-[#008080]" whileHover={{ scale: 1.07 }} whileTap={{ scale: 0.97 }}>Trước</motion.button>
                  <motion.button className="px-4 py-2 bg-[#008080] text-white rounded-lg" whileHover={{ scale: 1.07 }} whileTap={{ scale: 0.97 }}>1</motion.button>
                  <motion.button className="px-4 py-2 border border-gray-300 rounded-lg hover:border-[#008080]" whileHover={{ scale: 1.07 }} whileTap={{ scale: 0.97 }}>2</motion.button>
                  <motion.button className="px-4 py-2 border border-gray-300 rounded-lg hover:border-[#008080]" whileHover={{ scale: 1.07 }} whileTap={{ scale: 0.97 }}>3</motion.button>
                  <motion.button className="px-4 py-2 border border-gray-300 rounded-lg hover:border-[#008080]" whileHover={{ scale: 1.07 }} whileTap={{ scale: 0.97 }}>Sau</motion.button>
                </div>
              </div>
            </div>
          </motion.section>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default BookingHistoryCustomerPage;
