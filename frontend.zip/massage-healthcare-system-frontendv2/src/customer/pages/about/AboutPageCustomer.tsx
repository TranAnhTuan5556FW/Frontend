import React, { useEffect } from "react";
import Header from "../../components/HeaderCustomer";
import Footer from "../../components/FooterCustomer";
import '@fortawesome/fontawesome-free/css/all.min.css';

const AboutPageCustomer: React.FC = () => {
  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px'
    };
    const observer = new window.IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fade-in');
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);
    document.querySelectorAll('.animate-on-scroll').forEach((element) => {
      observer.observe(element);
    });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fadeIn 0.8s ease-out forwards;
        }
      `}</style>
      <Header />
      {/* Phần Hero của Đánh Giá */}
      <section id="testimonials-hero" className="pt-24 bg-[#e6e6fa]/10 animate-on-scroll opacity-0">
        <div className="container mx-auto px-6 py-16">
          <h2 className="text-5xl font-bold text-center text-gray-800 mb-6">Câu Chuyện Khách Hàng</h2>
          <p className="text-xl text-gray-600 text-center max-w-2xl mx-auto mb-8">
            Khám phá những chia sẻ từ khách hàng về trải nghiệm tuyệt vời tại RelaxEase.
          </p>
        </div>
      </section>

      {/* Phần Đánh Giá Nổi Bật */}
      <section id="featured-testimonials" className="py-16 animate-on-scroll opacity-0">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-8">
            <div id="featured-testimonial-1" className="bg-white p-8 rounded-xl shadow-lg">
              <div className="flex items-center mb-6">
                <img 
                  src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg" 
                  alt="Khách hàng" 
                  className="w-20 h-20 rounded-full mr-4"
                />
                <div>
                  <h4 className="text-xl font-bold">Nguyễn Thị Hương</h4>
                  <p className="text-gray-500">Thành viên thường xuyên</p>
                  <div className="flex text-[#008080] mt-2">
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 text-lg leading-relaxed">
                "Tôi đã đến RelaxEase hơn một năm nay và có thể tự tin nói rằng dịch vụ ở đây đã thay đổi hoàn toàn thói quen chăm sóc sức khỏe của tôi. Các chuyên viên massage rất chuyên nghiệp và luôn quan tâm đến nhu cầu của tôi. Không gian thư giãn tuyệt vời, và tôi luôn cảm thấy thoải mái sau mỗi lần trải nghiệm."
              </p>
            </div>

            <div id="featured-testimonial-2" className="bg-white p-8 rounded-xl shadow-lg">
              <div className="flex items-center mb-6">
                <img 
                  src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg" 
                  alt="Khách hàng" 
                  className="w-20 h-20 rounded-full mr-4"
                />
                <div>
                  <h4 className="text-xl font-bold">Trần Minh Đức</h4>
                  <p className="text-gray-500">Vận động viên chuyên nghiệp</p>
                  <div className="flex text-[#008080] mt-2">
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 text-lg leading-relaxed">
                "Là một vận động viên chuyên nghiệp, tôi cần một dịch vụ massage đáng tin cậy để duy trì phong độ tốt nhất. Các buổi massage tại RelaxEase đã trở thành một phần không thể thiếu trong chế độ luyện tập của tôi. Kết quả thật sự ấn tượng!"
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Phần Lưới Đánh Giá */}
      <section id="testimonials-grid" className="py-16 bg-gray-50 animate-on-scroll opacity-0">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8">
            <div id="testimonial-card-1" className="bg-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center mb-4">
                <img 
                  src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-6.jpg" 
                  alt="Khách hàng" 
                  className="w-16 h-16 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-bold">Lê Thị Mai</h4>
                  <p className="text-gray-500">Người yêu thích spa</p>
                  <div className="flex text-[#008080] mt-1">
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                  </div>
                </div>
              </div>
              <p className="text-gray-600">"Massage đá nóng ở đây thật sự tuyệt vời. Chưa bao giờ tôi cảm thấy thư giãn đến thế!"</p>
            </div>

            <div id="testimonial-card-2" className="bg-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center mb-4">
                <img 
                  src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-3.jpg" 
                  alt="Khách hàng" 
                  className="w-16 h-16 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-bold">Phạm Văn Nam</h4>
                  <p className="text-gray-500">Nhân viên văn phòng</p>
                  <div className="flex text-[#008080] mt-1">
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                  </div>
                </div>
              </div>
              <p className="text-gray-600">"Giải pháp hoàn hảo cho các vấn đề đau lưng do công việc văn phòng. Các chuyên viên thực sự hiểu rõ nhu cầu của dân văn phòng."</p>
            </div>

            <div id="testimonial-card-3" className="bg-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center mb-4">
                <img 
                  src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-7.jpg" 
                  alt="Khách hàng" 
                  className="w-16 h-16 rounded-full mr-4"
                />
                <div>
                  <h4 className="font-bold">Hoàng Thị Lan</h4>
                  <p className="text-gray-500">Giáo viên yoga</p>
                  <div className="flex text-[#008080] mt-1">
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                    <i className="fa-solid fa-star"></i>
                  </div>
                </div>
              </div>
              <p className="text-gray-600">"Kết hợp hoàn hảo với việc tập yoga của tôi. Các chuyên viên ở đây thực sự là những người chữa lành tài năng."</p>
            </div>
          </div>
        </div>
      </section>

      {/* Phần Video Đánh Giá */}
      <section id="video-testimonials" className="py-16 animate-on-scroll opacity-0">
        <div className="container mx-auto px-6">
          <h3 className="text-3xl font-bold text-center mb-12">Video Cảm Nhận Khách Hàng</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div id="video-testimonial-1" className="relative h-[300px] rounded-xl overflow-hidden bg-gray-200">
              <img 
                className="absolute inset-0 w-full h-full object-cover" 
                src="https://storage.googleapis.com/uxpilot-auth.appspot.com/6c91104d97-68f4f17770a24f2a0317.png" 
                alt="khách hàng chia sẻ cảm nhận trong không gian spa thư giãn, ánh sáng chuyên nghiệp" 
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <button className="bg-white/90 rounded-full p-4 text-[#008080] hover:bg-white">
                  <i className="fa-solid fa-play text-2xl"></i>
                </button>
              </div>
            </div>
            <div id="video-testimonial-2" className="relative h-[300px] rounded-xl overflow-hidden bg-gray-200">
              <img 
                className="absolute inset-0 w-full h-full object-cover" 
                src="https://storage.googleapis.com/uxpilot-auth.appspot.com/8fa102dd0a-cf61107eaacc6c89584c.png" 
                alt="khách hàng chia sẻ trải nghiệm massage trong không gian spa" 
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <button className="bg-white/90 rounded-full p-4 text-[#008080] hover:bg-white">
                  <i className="fa-solid fa-play text-2xl"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default AboutPageCustomer;
