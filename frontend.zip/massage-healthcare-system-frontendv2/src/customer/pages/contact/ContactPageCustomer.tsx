import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Header from "../../components/HeaderCustomer";
import Footer from "../../components/FooterCustomer";
import '@fortawesome/fontawesome-free/css/all.min.css';

const ContactPageCustomer: React.FC = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px'
    };
    const observer = new window.IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fade-in');
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);
    document.querySelectorAll('.animate-on-scroll').forEach((element) => {
      observer.observe(element);
    });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSuccess(true);
    setFormData({ name: "", email: "", phone: "", message: "" });
    setTimeout(() => setShowSuccess(false), 4000);
  };

  return (
    <div className="min-h-screen bg-white">
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fadeIn 0.8s ease-out forwards;
        }
      `}</style>
      <Header />
      {/* Contact Hero Section */}
      <section id="contact-hero" className="pt-24 h-[400px] relative overflow-hidden bg-[#008080] animate-on-scroll opacity-0">
        <div className="container mx-auto px-6 h-full flex items-center">
          <div className="text-white">
            <h2 className="text-5xl font-bold mb-6">Liên Hệ Với Chúng Tôi</h2>
            <p className="text-xl text-white/90">Chúng tôi luôn sẵn sàng giải đáp thắc mắc và giúp bạn tìm được liệu trình massage phù hợp nhất.</p>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-full h-full bg-[#e6e6fa]/5 -z-10"></div>
      </section>

      {/* Success Message */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-24 left-0 right-0 z-50"
          >
            <div className="container mx-auto px-6 max-w-3xl">
              <div className="bg-white rounded-xl shadow-lg p-8 text-center">
                <div className="text-[#008080] mb-6">
                  <i className="fa-solid fa-circle-check text-6xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-4">Gửi Tin Nhắn Thành Công!</h3>
                <p className="text-gray-600">Cảm ơn bạn đã liên hệ với chúng tôi. Chúng tôi sẽ phản hồi trong thời gian sớm nhất.</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Contact Information Section */}
      <section id="contact-info" className="py-20 animate-on-scroll opacity-0">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div id="contact-form" className="bg-white p-8 rounded-xl shadow-lg">
              <h3 className="text-2xl font-bold mb-6 text-gray-800">Gửi Tin Nhắn Cho Chúng Tôi</h3>
              <form className="space-y-6" onSubmit={handleSubmit}>
                <div>
                  <label className="block text-gray-700 mb-2">Họ và Tên</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">Số Điện Thoại</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-gray-700 mb-2">Nội Dung</label>
                  <textarea
                    rows={4}
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none"
                    required
                  ></textarea>
                </div>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-3 bg-[#008080] text-white rounded-lg hover:bg-[#006666] transition-colors"
                  type="submit"
                >
                  Gửi Tin Nhắn
                </motion.button>
              </form>
            </div>

            {/* Contact Details */}
            <div id="contact-details" className="space-y-8">
              <motion.div
                id="location"
                className="bg-white p-8 rounded-xl shadow-lg"
                whileHover={{ y: -5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="text-[#008080] mb-4">
                  <i className="fa-solid fa-location-dot text-3xl"></i>
                </div>
                <h4 className="text-xl font-bold mb-2">Địa Chỉ</h4>
                <p className="text-gray-600">123 Đường Thư Giãn</p>
                <p className="text-gray-600">Thành phố Sức Khỏe, WC 12345</p>
              </motion.div>

              <motion.div
                id="contact-methods"
                className="bg-white p-8 rounded-xl shadow-lg"
                whileHover={{ y: -5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="text-[#008080] mb-4">
                  <i className="fa-solid fa-phone text-3xl"></i>
                </div>
                <h4 className="text-xl font-bold mb-2">Thông Tin Liên Hệ</h4>
                <p className="text-gray-600">Điện thoại: (555) 123-4567</p>
                <p className="text-gray-600">Email: info@relaxease.com</p>
              </motion.div>

              <motion.div
                id="business-hours"
                className="bg-white p-8 rounded-xl shadow-lg"
                whileHover={{ y: -5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="text-[#008080] mb-4">
                  <i className="fa-solid fa-clock text-3xl"></i>
                </div>
                <h4 className="text-xl font-bold mb-2">Giờ Làm Việc</h4>
                <p className="text-gray-600">Thứ Hai - Thứ Sáu: 9h - 20h</p>
                <p className="text-gray-600">Thứ Bảy: 10h - 18h</p>
                <p className="text-gray-600">Chủ Nhật: 10h - 16h</p>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ContactPageCustomer;
