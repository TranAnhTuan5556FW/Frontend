import HeaderAdmin from "../../components/HeaderAdmin";
import SideBarAdmin from "../../components/SideBarAdmin";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSpa, faShoePrints, faHotTubPerson, faArrowLeft, faPen, faCheck } from '@fortawesome/free-solid-svg-icons';
import { useNavigate, useParams } from 'react-router-dom';
import allPackages from '../../../data/packageServiceDataCustomer';

const iconMap: Record<string, any> = {
  'Massage body': faSpa,
  'Foot spa': faShoePrints,
  'Xông hơi': faHotTubPerson,
  // Add more mappings as needed
};

const PackagesServiceDetailPageAdmin = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const packageData = allPackages.find(pkg => String(pkg.id) === String(id));

  if (!packageData) {
    return (
      <div className="min-h-screen bg-gray-100">
        <HeaderAdmin user={{ avatar: '', role: 'admin' }} handleLogout={() => {}} />
        <SideBarAdmin />
        <div className="flex-1 ml-64 pt-16 flex items-center justify-center">
          <div className="bg-white p-8 rounded-lg shadow text-center">
            <h2 className="text-2xl font-bold mb-4">Không tìm thấy gói dịch vụ</h2>
            <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg" onClick={() => navigate(-1)}>Quay lại</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <HeaderAdmin user={{ avatar: '', role: 'admin' }} handleLogout={() => {}} />
      {/* Sidebar */}
      <SideBarAdmin />
      {/* Top Header */}
      <div className="flex-1 ml-64 pt-16">
        <header id="header" className="bg-white shadow-sm">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center">
              <button
                type="button"
                className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
                onClick={() => navigate(-1)}
              >
                <FontAwesomeIcon icon={faArrowLeft} className="mr-2" />
                Quay lại
              </button>
              <h2 className="text-xl font-bold ml-4">Chi tiết {packageData.name}</h2>
            </div>
            <div className="flex items-center space-x-4">
              <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                <FontAwesomeIcon icon={faPen} className="mr-2" />
                Chỉnh sửa
              </button>
              <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <FontAwesomeIcon icon={faCheck} className="mr-2" />
                {packageData.status === 'Đang bán' ? 'Đang hoạt động' : packageData.status || 'Chưa bán'}
              </button>
            </div>
          </div>
        </header>
        {/* Main Content */}
        <div className="p-6 grid grid-cols-3 gap-6">
          {/* Main Info Section */}
          <div id="package-main-info" className="col-span-2 space-y-6">
            {/* Basic Info Card */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold mb-4">Thông tin cơ bản</h3>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <p className="text-gray-500 mb-1">Tên gói dịch vụ</p>
                  <p className="font-medium">{packageData.name}</p>
                </div>
                <div>
                  <p className="text-gray-500 mb-1">Thời gian thực hiện</p>
                  <p className="font-medium">{packageData.duration}</p>
                </div>
                <div>
                  <p className="text-gray-500 mb-1">Giá gói hiện tại</p>
                  <p className="font-medium">{packageData.currentPrice || '--'}</p>
                </div>
                <div>
                  <p className="text-gray-500 mb-1">Giá gói gốc</p>
                  <p className="font-medium line-through text-gray-500">{packageData.originalPrice || '--'}</p>
                </div>
              </div>
            </div>
            {/* Services Included */}
            <div id="package-services" className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold mb-4">Dịch vụ bao gồm</h3>
              <div className="grid grid-cols-1 gap-4">
                {packageData.services.map((service, idx) => (
                  <div key={service.id || idx} className="flex items-center p-4 border rounded-lg">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                      <FontAwesomeIcon icon={iconMap[service.name] || faSpa} className="text-blue-600 text-xl" />
                    </div>
                    <div>
                      <h4 className="font-medium">{service.name}</h4>
                      <p className="text-gray-500">{service.duration}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            {/* Description */}
            <div id="package-description" className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold mb-4">Mô tả gói dịch vụ</h3>
              <p className="text-gray-600 leading-relaxed">
                {packageData.description}
              </p>
            </div>
            {/* Benefits */}
            <div id="package-benefits" className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold mb-4">Lợi ích nổi bật</h3>
              <ul className="space-y-2">
                {packageData.benefits && packageData.benefits.length > 0 ? packageData.benefits.map((benefit, idx) => (
                  <li key={idx} className="flex items-center text-gray-700">
                    <FontAwesomeIcon icon={faCheck} className="text-green-600 mr-2" />
                    {benefit}
                  </li>
                )) : <li className="text-gray-500">Không có thông tin lợi ích</li>}
              </ul>
            </div>
          </div>
          {/* Side Stats */}
          <div className="space-y-6">
            {/* Performance Stats */}
            <div id="package-performance" className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold mb-4">Hiệu suất gói dịch vụ</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-500">Đã bán tháng này</span>
                    <span className="font-medium">{packageData.soldCount ? packageData.soldCount + ' gói' : '--'}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '75%' }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-500">Tỷ lệ hoàn thành</span>
                    <span className="font-medium">95%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: '95%' }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-500">Đánh giá trung bình</span>
                    <span className="font-medium">4.8/5</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-yellow-600 h-2 rounded-full" style={{ width: '96%' }}></div>
                  </div>
                </div>
              </div>
            </div>
            {/* Recent Bookings */}
            <div id="recent-bookings" className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold mb-4">Đặt lịch gần đây</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg" alt="Customer" className="w-10 h-10 rounded-full mr-3" />
                  <div>
                    <p className="font-medium">Nguyễn Thị Anh</p>
                    <p className="text-sm text-gray-500">15:30 - 27/05/2025</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg" alt="Customer" className="w-10 h-10 rounded-full mr-3" />
                  <div>
                    <p className="font-medium">Trần Văn Bình</p>
                    <p className="text-sm text-gray-500">10:00 - 27/05/2025</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-3.jpg" alt="Customer" className="w-10 h-10 rounded-full mr-3" />
                  <div>
                    <p className="font-medium">Lê Minh Tuấn</p>
                    <p className="text-sm text-gray-500">16:00 - 26/05/2025</p>
                  </div>
                </div>
              </div>
            </div>
            {/* Package History */}
            <div id="package-history" className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold mb-4">Lịch sử thay đổi</h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="w-2 h-2 mt-2 rounded-full bg-blue-600 mr-3"></div>
                  <div>
                    <p className="font-medium">Cập nhật giá gói</p>
                    <p className="text-sm text-gray-500">20/05/2025</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-2 h-2 mt-2 rounded-full bg-blue-600 mr-3"></div>
                  <div>
                    <p className="font-medium">Thêm dịch vụ Foot spa</p>
                    <p className="text-sm text-gray-500">15/05/2025</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-2 h-2 mt-2 rounded-full bg-blue-600 mr-3"></div>
                  <div>
                    <p className="font-medium">Tạo gói dịch vụ</p>
                    <p className="text-sm text-gray-500">01/05/2025</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PackagesServiceDetailPageAdmin;
