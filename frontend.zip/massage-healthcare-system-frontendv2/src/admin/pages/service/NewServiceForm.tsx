import React, { useState, ChangeEvent, FormEvent } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Service } from "../../../data/individualServiceDataCustomer";

interface ServiceForm {
  name: string;
  code: string;
  category: 'relaxation' | 'therapeutic' | 'specialty' | 'beauty';
  duration: string;
  prices: {
    [key: string]: number;
  };
  description: string;
  benefits: string[];
  room: 'VIP' | 'Trị liệu' | 'Spa';
  staff: number;
  status: 'active' | 'inactive';
  tag?: 'popular' | 'special';
}

interface Errors {
  name?: string;
  code?: string;
  prices?: string;
}

interface NewServiceFormProps {
  onCancel: () => void;
  onSubmit: (data: ServiceForm) => void;
  initialData?: Service | null;
}

const initialState: ServiceForm = {
  name: "",
  code: "",
  category: "relaxation",
  duration: "60 phút",
  prices: {
    "60": 0,
    "90": 0,
    "120": 0
  },
  description: "",
  benefits: ["", "", "", ""],
  room: "VIP",
  staff: 1,
  status: "active"
};

const categoryLabels: Record<string, string> = {
  'relaxation': 'Thư giãn',
  'therapeutic': 'Trị liệu',
  'specialty': 'Đặc biệt',
  'beauty': 'Làm đẹp'
};

const NewServiceForm: React.FC<NewServiceFormProps> = ({ onCancel, onSubmit, initialData }) => {
  const [form, setForm] = useState<ServiceForm>(
    initialData ? {
      name: initialData.name,
      code: initialData.id.toString(),
      category: initialData.category,
      duration: initialData.duration,
      prices: initialData.prices,
      description: initialData.description,
      benefits: initialData.benefits || ["", "", "", ""],
      room: initialData.room,
      staff: initialData.staff,
      status: initialData.status,
      tag: initialData.tag
    } : initialState
  );
  const [errors, setErrors] = useState<Errors>({});

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    if (name.startsWith('price_')) {
      // Handle price changes
      const duration = name.split('_')[1];
      setForm(prev => ({
        ...prev,
        prices: {
          ...prev.prices,
          [duration]: parseInt(value) || 0
        }
      }));
    } else {
      setForm(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleBenefitChange = (idx: number, value: string) => {
    setForm(prev => {
      const newBenefits = [...prev.benefits];
      newBenefits[idx] = value;
      return { ...prev, benefits: newBenefits };
    });
  };

  const validate = () => {
    const newErrors: Errors = {};
    if (!form.name.trim()) newErrors.name = "Vui lòng nhập tên dịch vụ";
    if (!form.code.trim()) newErrors.code = "Vui lòng nhập mã dịch vụ";
    
    // Validate at least one price is set
    const hasPrice = Object.values(form.prices).some(price => price > 0);
    if (!hasPrice) newErrors.prices = "Vui lòng nhập ít nhất một mức giá";
    
    return newErrors;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) {
      toast.error("Vui lòng kiểm tra lại thông tin!");
      return;
    }
    onSubmit(form);
  };

  return (
    <div className="max-w-4xl w-full mx-auto bg-white rounded-lg shadow-lg mb-8">
      <header id="header" className="bg-white shadow-sm rounded-t-lg">
        <div className="flex items-center justify-between px-6 py-4">
          <h2 className="text-xl font-bold">
            {initialData ? 'Chỉnh sửa thông tin dịch vụ' : 'Thêm Dịch vụ mới'}
          </h2>
          <button 
            type="button" 
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg" 
            onClick={onCancel}
          >
            <i className="fa-solid fa-xmark mr-2"></i>
            Đóng
          </button>
        </div>
      </header>

      <div className="p-6">
        <form className="p-6" onSubmit={handleSubmit}>
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Thông tin cơ bản</h3>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tên dịch vụ *</label>
                <input
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border ${errors.name ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500`}
                  placeholder="Nhập tên dịch vụ"
                />
                {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Mã dịch vụ *</label>
                <input
                  type="text"
                  name="code"
                  value={form.code}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border ${errors.code ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500`}
                  placeholder="VD: SV001"
                />
                {errors.code && <p className="text-red-500 text-xs mt-1">{errors.code}</p>}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Nhóm dịch vụ</label>
                <select
                  name="category"
                  value={form.category}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  {Object.entries(categoryLabels).map(([value, label]) => (
                    <option key={value} value={value}>{label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tag</label>
                <select
                  name="tag"
                  value={form.tag || ''}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Không có</option>
                  <option value="popular">Phổ biến</option>
                  <option value="special">Đặc biệt</option>
                </select>
              </div>
            </div>
          </div>

          {/* Pricing */}
          <div className="space-y-4 mt-6">
            <h3 className="text-lg font-semibold">Giá dịch vụ *</h3>
            <div className="grid grid-cols-3 gap-6">
              {['60', '90', '120'].map(duration => (
                <div key={duration}>
                  <label className="block text-sm font-medium text-gray-700 mb-2">{duration} phút</label>
                  <input
                    type="number"
                    name={`price_${duration}`}
                    value={form.prices[duration] || ''}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="VD: 600000"
                  />
                </div>
              ))}
            </div>
            {errors.prices && <p className="text-red-500 text-xs mt-1">{errors.prices}</p>}
          </div>

          {/* Description */}
          <div className="space-y-4 mt-6">
            <h3 className="text-lg font-semibold">Mô tả dịch vụ</h3>
            <div>
              <textarea
                name="description"
                value={form.description}
                onChange={handleChange}
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Nhập mô tả chi tiết về dịch vụ..."
              ></textarea>
            </div>
          </div>

          {/* Lợi ích */}
          <div className="space-y-4 mt-6">
            <h3 className="text-lg font-semibold">Lợi ích</h3>
            <div className="grid grid-cols-2 gap-6">
              {[0,1,2,3].map(idx => (
                <div key={idx}>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Lợi ích {idx+1}</label>
                  <input
                    type="text"
                    value={form.benefits[idx] || ''}
                    onChange={e => handleBenefitChange(idx, e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder={`Nhập lợi ích ${idx+1}`}
                    maxLength={60}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Status */}
          {initialData && (
            <div className="space-y-4 mt-6">
              <h3 className="text-lg font-semibold">Trạng thái</h3>
              <div className="flex space-x-4">
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="status"
                    value="active"
                    checked={form.status === "active"}
                    onChange={handleChange}
                    className="form-radio text-blue-600"
                  />
                  <span className="ml-2">Hoạt động</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="status"
                    value="inactive"
                    checked={form.status === "inactive"}
                    onChange={handleChange}
                    className="form-radio text-blue-600"
                  />
                  <span className="ml-2">Tạm ngưng</span>
                </label>
              </div>
            </div>
          )}

          {/* Form Actions */}
          <div className="flex justify-end space-x-4 pt-6 border-t mt-6">
            <button
              type="button"
              onClick={onCancel}
              className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              {initialData ? 'Cập nhật dịch vụ' : 'Lưu dịch vụ'}
            </button>
          </div>
        </form>
      </div>
      <ToastContainer position="top-right" autoClose={2000} />
    </div>
  );
};

export default NewServiceForm;
