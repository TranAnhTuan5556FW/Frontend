import React, { useState, useMemo } from 'react';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import '@fortawesome/fontawesome-free/css/all.min.css';
import allPackages from '../../../data/packageServiceDataCustomer';
import { useNavigate } from 'react-router-dom';
import NewPackageServiceForm from './NewPackageServiceForm';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const ITEMS_PER_PAGE = 3;

const PackagesServicePageAdmin: React.FC = () => {
  // Static user for header
  const [user] = useState({
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    role: 'admin',
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [showForm, setShowForm] = useState(false);
  const [editPackage, setEditPackage] = useState<any | null>(null);
  const [packages, setPackages] = useState(allPackages);
  const navigate = useNavigate();

  // Pagination logic
  const totalPackages = packages.length;
  const totalPages = Math.ceil(totalPackages / ITEMS_PER_PAGE);
  const paginatedPackages = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    return packages.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [currentPage, packages]);

  const handleLogout = () => {
    // TODO: Implement logout logic
    console.log('Logging out...');
  };

  const handleBack = () => {
    navigate(-1);
  };

  const handleAddPackage = () => {
    setEditPackage(null);
    setShowForm(true);
  };

  const handleEditPackage = (pkg: any) => {
    // Map package data to form fields
    setEditPackage({
      name: pkg.name,
      duration: pkg.duration,
      services: pkg.services.map((s: any) => ({
        serviceId: s.id ? String(s.id) : '',
        duration: s.duration || '',
      })),
      price: pkg.originalPrice ? pkg.originalPrice.replace(/[^\d]/g, '') : '',
      salePrice: pkg.currentPrice ? pkg.currentPrice.replace(/[^\d]/g, '') : '',
      description: pkg.description,
      status: pkg.status || 'Đang bán',
      benefits: pkg.benefits || ['', '', '', ''],
    });
    setShowForm(true);
  };

  const handleCancelForm = () => {
    setShowForm(false);
    setEditPackage(null);
  };

  const handleSubmitForm = (data: any) => {
    // TODO: Add logic to save new or updated package
    console.log(editPackage ? 'Update package:' : 'New package data:', data);
    setShowForm(false);
    setEditPackage(null);
  };

  const handleDeletePackage = (pkg: any) => {
    if (window.confirm(`Bạn có chắc chắn muốn xóa gói dịch vụ "${pkg.name}"?`)) {
      setPackages(prev => prev.filter(p => p.id !== pkg.id));
      toast.success(`Đã xóa gói dịch vụ ${pkg.name}`);
    }
  };

  // Stats (example: you can calculate these from packages if needed)
  const totalActive = packages.filter(pkg => pkg.status === 'Đang bán').length;
  const totalSold = packages.reduce((sum, pkg) => sum + (pkg.soldCount || 0), 0);
  // Example revenue: sum all soldCount * currentPrice (if available)
  const totalRevenue = packages.reduce((sum, pkg) => {
    if (pkg.soldCount && pkg.currentPrice) {
      // Remove non-numeric chars from price string
      const price = Number(pkg.currentPrice.replace(/[^\d]/g, ''));
      return sum + price * pkg.soldCount;
    }
    return sum;
  }, 0);

  return (
    <div className="min-h-screen bg-gray-100">
      <HeaderAdmin user={user} handleLogout={handleLogout} />
      <SideBarAdmin />
      <ToastContainer position="top-right" autoClose={2000} />
      <main className="ml-64 pt-16">
        {/* Top Header */}
        {!showForm && (
          <header id="header" className="bg-white shadow-sm">
            <div className="flex items-center justify-between px-6 py-4">
              <div className="flex items-center gap-4">
                <button 
                  type="button"
                  className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
                  onClick={handleBack}
                >
                  <i className="fa-solid fa-arrow-left mr-2"></i>
                  Quay lại
                </button>
                <h2 className="text-xl font-bold">Quản lý Gói Dịch vụ</h2>
              </div>
              <div className="flex items-center space-x-4">
                <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700" onClick={handleAddPackage}>
                  <i className="fa-solid fa-plus mr-2"></i>
                  Tạo gói mới
                </button>
                <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  <i className="fa-solid fa-file-export mr-2"></i>
                  Xuất báo cáo
                </button>
              </div>
            </div>
          </header>
        )}
        {showForm ? (
          <div className="max-w-4xl w-full mx-auto bg-white rounded-lg shadow-lg mb-8">
            <NewPackageServiceForm onCancel={handleCancelForm} onSubmit={handleSubmitForm} initialData={editPackage} />
          </div>
        ) : (
          <>
            {/* Package Stats */}
            <div id="package-stats" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 p-6">
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-500">Tổng gói dịch vụ</p>
                    <h3 className="text-2xl font-bold mt-2">{totalPackages}</h3>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <i className="fa-solid fa-box text-blue-600 text-xl"></i>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-500">Gói đang hoạt động</p>
                    <h3 className="text-2xl font-bold mt-2">{totalActive}</h3>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <i className="fa-solid fa-check-circle text-green-600 text-xl"></i>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-500">Khách hàng đã mua</p>
                    <h3 className="text-2xl font-bold mt-2">{totalSold}</h3>
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                    <i className="fa-solid fa-users text-purple-600 text-xl"></i>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-500">Doanh thu từ gói</p>
                    <h3 className="text-2xl font-bold mt-2">{totalRevenue ? (totalRevenue/1000000).toFixed(0) + 'M' : 0}</h3>
                  </div>
                  <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                    <i className="fa-solid fa-coins text-yellow-600 text-xl"></i>
                  </div>
                </div>
              </div>
            </div>
            {/* Package Table */}
            <div id="package-table" className="px-6">
              <div className="bg-white rounded-lg shadow">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="px-6 py-4">Tên gói dịch vụ</th>
                      <th className="px-6 py-4">Dịch vụ bao gồm</th>
                      <th className="px-6 py-4">Giá gói</th>
                      <th className="px-6 py-4">Đã bán</th>
                      <th className="px-6 py-4">Trạng thái</th>
                      <th className="px-6 py-4">Hành động</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedPackages.map(pkg => (
                      <tr key={pkg.id} className="border-b hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div className="font-medium text-blue-600 hover:underline cursor-pointer" onClick={() => navigate(`/admin/packages/${pkg.id}`)}>{pkg.name}</div>
                          <div className="text-sm text-gray-500">{pkg.duration}</div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-wrap gap-2">
                            {pkg.services.map(service => (
                              <span key={service.id} className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">
                                {service.name}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          {pkg.currentPrice || pkg.originalPrice ? (
                            <>
                              <div className="font-medium">{pkg.currentPrice || '--'}</div>
                              {pkg.originalPrice && (
                                <div className="text-sm text-gray-500 line-through">{pkg.originalPrice}</div>
                              )}
                            </>
                          ) : (
                            pkg.prices ? (
                              Object.entries(pkg.prices).map(([duration, price]) => (
                                <div key={duration} className="text-sm">
                                  {duration} phút: {price.toLocaleString('vi-VN')}đ
                                </div>
                              ))
                            ) : '--'
                          )}
                        </td>
                        <td className="px-6 py-4">
                          <div>{pkg.soldCount ? pkg.soldCount + ' gói' : '--'}</div>
                          {pkg.growth && (
                            <div className="text-sm text-green-600">{pkg.growth} tháng này</div>
                          )}
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full ${pkg.status === 'Đang bán' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                            {pkg.status || '--'}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <button className="text-blue-600 hover:text-blue-800 mr-3">
                            <i className="fa-solid fa-chart-line"></i>
                          </button>
                          <button className="text-gray-600 hover:text-gray-800 mr-3" onClick={() => handleEditPackage(pkg)}>
                            <i className="fa-solid fa-pen"></i>
                          </button>
                          <button className="text-red-600 hover:text-red-800" onClick={() => handleDeletePackage(pkg)}>
                            <i className="fa-solid fa-trash"></i>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {/* Pagination */}
                <div className="px-6 py-4 flex items-center justify-between border-t">
                  <div className="text-gray-600">
                    Hiển thị {(currentPage - 1) * ITEMS_PER_PAGE + 1}-{Math.min(currentPage * ITEMS_PER_PAGE, totalPackages)} trong tổng số {totalPackages} gói dịch vụ
                  </div>
                  <div className="flex space-x-2">
                    <button
                      className="px-3 py-1 border rounded hover:bg-gray-50 disabled:opacity-50"
                      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                    >
                      <i className="fa-solid fa-chevron-left"></i>
                    </button>
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                      <button
                        key={page}
                        onClick={() => setCurrentPage(page)}
                        className={`px-3 py-1 rounded ${currentPage === page ? 'bg-blue-600 text-white' : 'border hover:bg-gray-50'}`}
                      >
                        {page}
                      </button>
                    ))}
                    <button
                      className="px-3 py-1 border rounded hover:bg-gray-50 disabled:opacity-50"
                      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                    >
                      <i className="fa-solid fa-chevron-right"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default PackagesServicePageAdmin;
