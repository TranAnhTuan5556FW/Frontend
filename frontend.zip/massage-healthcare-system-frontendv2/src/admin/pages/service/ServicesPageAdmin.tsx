import React, { useState, useMemo } from 'react';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import NewServiceForm from './NewServiceForm';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { services as initialServices, Service } from '../../../data/individualServiceDataCustomer';
import { useNavigate } from 'react-router-dom';

const categoryColors: Record<string, string> = {
    'relaxation': 'bg-green-100 text-green-700',
    'therapeutic': 'bg-blue-100 text-blue-700',
    'specialty': 'bg-purple-100 text-purple-700',
    'beauty': 'bg-pink-100 text-pink-700'
};

const ITEMS_PER_PAGE = 3;

const ServicesPageAdmin: React.FC = () => {
    const navigate = useNavigate();
    // State
    const [services, setServices] = useState<Service[]>(initialServices);
    const [selectedCategory, setSelectedCategory] = useState<string>('Tất cả');
    const [currentPage, setCurrentPage] = useState(1);
    const [showServiceForm, setShowServiceForm] = useState(false);
    const [editService, setEditService] = useState<Service | null>(null);
    const [user] = useState({
        avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
        role: 'admin',
    });

    // Filter services based on category
    const filteredServices = useMemo(() => {
        return services.filter(service => 
            selectedCategory === 'Tất cả' || service.category === selectedCategory
        );
    }, [services, selectedCategory]);

    // Calculate pagination
    const totalPages = Math.ceil(filteredServices.length / ITEMS_PER_PAGE);
    const paginatedServices = useMemo(() => {
        const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
        return filteredServices.slice(startIndex, startIndex + ITEMS_PER_PAGE);
    }, [filteredServices, currentPage]);

    // Reset to first page when changing category
    const handleCategoryChange = (category: string) => {
        setSelectedCategory(category);
        setCurrentPage(1);
    };

    // Handlers
    const handleLogout = () => {
        // TODO: Implement logout logic
        console.log('Logging out...');
    };

    const handleAddService = () => {
        setEditService(null);
        setShowServiceForm(true);
    };

    const handleServiceFormCancel = () => {
        setShowServiceForm(false);
        setEditService(null);
    };

    const handleServiceFormSubmit = (data: any) => {
        if (editService) {
            setServices(prev => prev.map(s => s.id === editService.id ? { ...s, ...data } : s));
            toast.success('Đã cập nhật dịch vụ thành công!');
        } else {
            const newId = Math.max(...services.map(s => s.id)) + 1;
            setServices(prev => [...prev, { ...data, id: newId }]);
            toast.success('Đã thêm dịch vụ mới thành công!');
        }
        setShowServiceForm(false);
        setEditService(null);
    };

    const handleEditService = (id: number) => {
        const serviceToEdit = services.find(s => s.id === id);
        if (serviceToEdit) {
            setEditService(serviceToEdit);
            setShowServiceForm(true);
        }
    };

    const handleDeleteService = (id: number) => {
        const serviceToDelete = services.find(s => s.id === id);
        if (!serviceToDelete) return;

        if (window.confirm(`Bạn có chắc chắn muốn xóa dịch vụ "${serviceToDelete.name}"?`)) {
            setServices(prev => prev.filter(s => s.id !== id));
            toast.success(`Đã xóa dịch vụ "${serviceToDelete.name}" thành công!`);
        }
    };

    const handleManagePackages = () => {
        // Navigate to service packages management page
        navigate('/admin/packages');
    };

    const handleViewService = (id: number) => {
        navigate(`/admin/services/${id}`);
    };

    // Categories for filter
    const categories = ['Tất cả', 'relaxation', 'therapeutic', 'specialty', 'beauty'];
    const categoryLabels: Record<string, string> = {
        'relaxation': 'Thư giãn',
        'therapeutic': 'Trị liệu',
        'specialty': 'Đặc biệt',
        'beauty': 'Làm đẹp'
    };

    // Generate page numbers for pagination
    const pageNumbers = useMemo(() => {
        const pages = [];
        for (let i = 1; i <= totalPages; i++) {
            pages.push(i);
        }
        return pages;
    }, [totalPages]);

    return (
        <div className="min-h-screen bg-gray-50">
            <HeaderAdmin user={user} handleLogout={handleLogout} />
            <SideBarAdmin />
            <ToastContainer position="top-right" autoClose={2000} />
            
            <main className="ml-64 pt-16">
                {showServiceForm ? (
                    <NewServiceForm
                        onCancel={handleServiceFormCancel}
                        onSubmit={handleServiceFormSubmit}
                        initialData={editService}
                    />
                ) : (
                    <>
                        {/* Page Header */}
                        <header id="header" className="bg-white shadow-sm">
                            <div className="flex items-center justify-between px-6 py-4">
                                <h2 className="text-xl font-bold">Quản lý Dịch vụ</h2>
                                <div className="flex items-center space-x-4">
                                    <button 
                                        className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                                        onClick={handleAddService}
                                    >
                                        <i className="fa-solid fa-plus mr-2"></i>
                                        Thêm dịch vụ
                                    </button>
                                    <button 
                                        className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                                        onClick={handleManagePackages}
                                    >
                                        <i className="fa-solid fa-box-archive mr-2"></i>
                                        Quản lý Gói Dịch vụ
                                    </button>
                                    <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                                        <i className="fa-solid fa-file-export mr-2"></i>
                                        Xuất danh sách
                                    </button>
                                </div>
                            </div>
                        </header>

                        {/* Service Categories */}
                        <div id="service-categories" className="p-6">
                            <div className="flex space-x-4 mb-6">
                                {categories.map((category) => (
                                    <button
                                        key={category}
                                        onClick={() => handleCategoryChange(category)}
                                        className={`px-4 py-2 rounded-lg ${
                                            selectedCategory === category
                                                ? 'bg-blue-600 text-white'
                                                : 'border border-gray-300 hover:bg-gray-50'
                                        }`}
                                    >
                                        {category === 'Tất cả' ? category : categoryLabels[category]}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Services Table */}
                        <div id="services-table" className="px-6">
                            <div className="bg-white rounded-lg shadow">
                                <table className="w-full">
                                    <thead>
                                        <tr className="text-left border-b">
                                            <th className="px-6 py-4">Tên dịch vụ</th>
                                            <th className="px-6 py-4">Nhóm</th>
                                            <th className="px-6 py-4">Thời gian</th>
                                            <th className="px-6 py-4">Giá</th>
                                            <th className="px-6 py-4">Trạng thái</th>
                                            <th className="px-6 py-4">Hành động</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {paginatedServices.map((service) => (
                                            <tr key={service.id} className="border-b hover:bg-gray-50">
                                                <td className="px-6 py-4">
                                                    <div 
                                                        className="font-medium cursor-pointer hover:text-blue-600"
                                                        onClick={() => handleViewService(service.id)}
                                                    >
                                                        {service.name}
                                                    </div>
                                                    <div className="text-sm text-gray-500">ID: #{service.id}</div>
                                                    {service.tag && (
                                                        <span className="inline-block px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800 mt-1">
                                                            {service.tag === 'popular' ? 'Phổ biến' : 'Đặc biệt'}
                                                        </span>
                                                    )}
                                                </td>
                                                <td className="px-6 py-4">
                                                    <span className={`px-3 py-1 rounded-full ${categoryColors[service.category]}`}>
                                                        {categoryLabels[service.category]}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4">{service.duration}</td>
                                                <td className="px-6 py-4">
                                                    {Object.entries(service.prices).map(([duration, price]) => (
                                                        <div key={duration} className="text-sm">
                                                            {duration} phút: {price.toLocaleString('vi-VN')}đ
                                                        </div>
                                                    ))}
                                                </td>
                                                <td className="px-6 py-4">
                                                    <span className={`px-3 py-1 rounded-full ${
                                                        service.status === 'active'
                                                            ? 'bg-blue-100 text-blue-700'
                                                            : 'bg-gray-100 text-gray-700'
                                                    }`}>
                                                        {service.status === 'active' ? 'Đang hoạt động' : 'Tạm ngưng'}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4">
                                                    <button
                                                        className="text-blue-600 hover:text-blue-800 mr-3"
                                                        onClick={() => handleViewService(service.id)}
                                                    >
                                                        <i className="fa-solid fa-eye"></i>
                                                    </button>
                                                    <button
                                                        className="text-gray-600 hover:text-gray-800 mr-3"
                                                        onClick={() => handleEditService(service.id)}
                                                    >
                                                        <i className="fa-solid fa-pen"></i>
                                                    </button>
                                                    <button
                                                        className="text-red-600 hover:text-red-800"
                                                        onClick={() => handleDeleteService(service.id)}
                                                    >
                                                        <i className="fa-solid fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>

                                {/* Pagination */}
                                <div className="px-6 py-4 flex items-center justify-between border-t">
                                    <div className="text-gray-600">
                                        Hiển thị {(currentPage - 1) * ITEMS_PER_PAGE + 1}-{Math.min(currentPage * ITEMS_PER_PAGE, filteredServices.length)} trong tổng số {filteredServices.length} dịch vụ
                                    </div>
                                    <div className="flex space-x-2">
                                        <button 
                                            className="px-3 py-1 border rounded hover:bg-gray-50 disabled:opacity-50"
                                            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                                            disabled={currentPage === 1}
                                        >
                                            <i className="fa-solid fa-chevron-left"></i>
                                        </button>
                                        {pageNumbers.map(number => (
                                            <button
                                                key={number}
                                                onClick={() => setCurrentPage(number)}
                                                className={`px-3 py-1 rounded ${
                                                    currentPage === number
                                                        ? 'bg-blue-600 text-white'
                                                        : 'border hover:bg-gray-50'
                                                }`}
                                            >
                                                {number}
                                            </button>
                                        ))}
                                        <button 
                                            className="px-3 py-1 border rounded hover:bg-gray-50 disabled:opacity-50"
                                            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                                            disabled={currentPage === totalPages}
                                        >
                                            <i className="fa-solid fa-chevron-right"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </>
                )}
            </main>
        </div>
    );
};

export default ServicesPageAdmin;
