import React, { useState, ChangeEvent, FormEvent } from 'react';
import { services } from '../../../data/individualServiceDataCustomer';

const DURATION_OPTIONS = [
  '60 phút',
  '90 phút',
  '120 phút',
  '150 phút',
  '180 phút',
];


const STATUS_OPTIONS = [
  'Đang bán',
  'Tạm ngưng',
  'Sắp ra mắt',
];

interface PackageServiceItem {
  serviceId: string;
  duration: string;
}

interface PackageForm {
  name: string;
  services: PackageServiceItem[];
  price: string;
  salePrice: string;
  description: string;
  benefits: string[];
  status: string;
}

interface Errors {
  name?: string;
  price?: string;
}

interface NewPackageServiceFormProps {
  onCancel: () => void;
  onSubmit: (data: PackageForm) => void;
  initialData?: Partial<PackageForm>;
}

const initialState: PackageForm = {
  name: '',
  services: [
    { serviceId: '', duration: DURATION_OPTIONS[0] },
    { serviceId: '', duration: DURATION_OPTIONS[0] },
  ],
  price: '',
  salePrice: '',
  description: '',
  benefits: ['', '', '', ''],
  status: STATUS_OPTIONS[0],
};

const NewPackageServiceForm: React.FC<NewPackageServiceFormProps> = ({ onCancel, onSubmit, initialData }) => {
  const [form, setForm] = useState<PackageForm>(
    initialData
      ? {
          ...initialState,
          ...initialData,
          services: initialData.services && Array.isArray(initialData.services)
            ? initialData.services.map((s: any, _idx: number) => ({
                serviceId: s.serviceId || '',
                duration: s.duration || DURATION_OPTIONS[0],
              }))
            : [
                { serviceId: '', duration: DURATION_OPTIONS[0] },
                { serviceId: '', duration: DURATION_OPTIONS[0] },
              ],
          benefits: initialData.benefits || ['', '', '', ''],
        }
      : initialState
  );
  const [errors, setErrors] = useState<Errors>({});

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleServiceItemChange = (idx: number, field: 'serviceId' | 'duration', value: string) => {
    setForm(prev => {
      const newServices = [...prev.services];
      newServices[idx] = { ...newServices[idx], [field]: value };
      if (idx === 0 && newServices[1] && newServices[1].serviceId === value) {
        newServices[1] = { ...newServices[1], serviceId: '' };
      }
      return { ...prev, services: newServices };
    });
  };

  const handleBenefitChange = (idx: number, value: string) => {
    setForm(prev => {
      const newBenefits = [...prev.benefits];
      newBenefits[idx] = value;
      return { ...prev, benefits: newBenefits };
    });
  };

  const validate = () => {
    const newErrors: Errors = {};
    if (!form.name.trim()) newErrors.name = 'Vui lòng nhập tên gói dịch vụ';
    if (!form.price.trim()) newErrors.price = 'Vui lòng nhập giá niêm yết';
    return newErrors;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;
    onSubmit(form);
  };

  return (
    <div className="max-w-4xl w-full mx-auto bg-white rounded-lg shadow-lg mb-8">
      <header id="header" className="bg-white shadow-sm rounded-t-lg">
        <div className="flex items-center justify-between px-6 py-4">
          <h2 className="text-xl font-bold">
            {initialData ? 'Chỉnh sửa gói dịch vụ' : 'Tạo Gói Dịch Vụ Mới'}
          </h2>
          <button type="button" className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg" onClick={onCancel}>
            <i className="fa-solid fa-xmark mr-2"></i>
            Đóng
          </button>
        </div>
      </header>
      <div className="p-6">
        <form className="p-6 space-y-6" onSubmit={handleSubmit}>
          {/* Basic Information */}
          <div id="basic-info" className="space-y-4">
            <h3 className="text-lg font-semibold border-b pb-3">Thông tin cơ bản</h3>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tên gói dịch vụ</label>
                <input type="text" name="name" value={form.name} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Nhập tên gói dịch vụ" required />
                {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
              </div>
            </div>
          </div>
          {/* Services Included */}
          <div id="services-included" className="space-y-4">
            <h3 className="text-lg font-semibold border-b pb-3">Dịch vụ bao gồm</h3>
            {[0, 1].map(idx => {
              const selectedService1 = form.services[0]?.serviceId;
              const availableServices = idx === 0
                ? services
                : services.filter(s => String(s.id) !== selectedService1);
              return (
                <div key={idx} className="flex items-center gap-4 mb-2">
                  <span className="font-medium">Dịch vụ {idx + 1}</span>
                  <select
                    className="px-4 py-2 border rounded-lg"
                    value={form.services[idx]?.serviceId || ''}
                    onChange={e => handleServiceItemChange(idx, 'serviceId', e.target.value)}
                  >
                    <option value="">Chọn dịch vụ</option>
                    {availableServices.map(s => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                  <select
                    className="px-4 py-2 border rounded-lg"
                    value={form.services[idx]?.duration || DURATION_OPTIONS[0]}
                    onChange={e => handleServiceItemChange(idx, 'duration', e.target.value)}
                  >
                    {DURATION_OPTIONS.map(option => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </div>
              );
            })}
          </div>
          {/* Pricing */}
          <div id="pricing" className="space-y-4">
            <h3 className="text-lg font-semibold border-b pb-3">Giá gói dịch vụ</h3>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Giá niêm yết</label>
                <div className="relative">
                  <input type="text" name="price" value={form.price} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Nhập giá niêm yết" />
                  <span className="absolute right-4 top-2 text-gray-500">VNĐ</span>
                </div>
                {errors.price && <p className="text-red-500 text-xs mt-1">{errors.price}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Giá khuyến mãi</label>
                <div className="relative">
                  <input type="text" name="salePrice" value={form.salePrice} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Nhập giá khuyến mãi" />
                  <span className="absolute right-4 top-2 text-gray-500">VNĐ</span>
                </div>
              </div>
            </div>
          </div>
          {/* Additional Information */}
          <div id="additional-info" className="space-y-4">
            <h3 className="text-lg font-semibold border-b pb-3">Thông tin bổ sung</h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Mô tả gói dịch vụ</label>
              <textarea name="description" rows={4} value={form.description} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Nhập mô tả chi tiết về gói dịch vụ"></textarea>
            </div>
            {/* Lợi ích */}
            <div className="space-y-4 mt-6">
              <h3 className="text-lg font-semibold">Lợi ích</h3>
              <div className="grid grid-cols-2 gap-6">
                {[0,1,2,3].map(idx => (
                  <div key={idx}>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Lợi ích {idx+1}</label>
                    <input
                      type="text"
                      value={form.benefits[idx] || ''}
                      onChange={e => handleBenefitChange(idx, e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder={`Nhập lợi ích ${idx+1}`}
                      maxLength={60}
                    />
                  </div>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-6">
              {initialData && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Trạng thái</label>
                  <select name="status" value={form.status} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    {STATUS_OPTIONS.map(option => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>
          {/* Form Actions */}
          <div id="form-actions" className="flex items-center justify-end space-x-4 pt-6 border-t">
            <button type="button" className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50" onClick={onCancel}>
              Hủy
            </button>
            <button type="submit" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
              <i className="fa-solid fa-check mr-2"></i>
              {initialData ? 'Cập nhật gói dịch vụ' : 'Tạo gói dịch vụ'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewPackageServiceForm;
