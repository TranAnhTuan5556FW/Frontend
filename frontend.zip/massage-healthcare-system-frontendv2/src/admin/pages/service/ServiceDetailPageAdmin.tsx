import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import { services } from '../../../data/individualServiceDataCustomer';

const ServiceDetailPageAdmin: React.FC = () => {
    const navigate = useNavigate();
    const { id } = useParams();
    const service = services.find(s => s.id === Number(id));

    const [user] = React.useState({
        avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
        role: 'admin',
    });

    const handleLogout = () => {
        // TODO: Implement logout logic
        console.log('Logging out...');
    };

    const handleBack = () => {
        navigate('/admin/services');
    };

    const handleEdit = () => {
        // TODO: Implement edit logic
        console.log('Editing service...');
    };

    const handleDelete = () => {
        if (window.confirm('Bạn có chắc chắn muốn xóa dịch vụ này?')) {
            // TODO: Implement delete logic
            console.log('Deleting service...');
            navigate('/admin/services');
        }
    };

    if (!service) {
        return <div>Không tìm thấy dịch vụ</div>;
    }

    return (
        <div className="min-h-screen bg-gray-50">
            <HeaderAdmin user={user} handleLogout={handleLogout} />
            <SideBarAdmin />
            <main className="ml-64 pt-16">
                {/* Top Header */}
                <header id="header" className="bg-white shadow-sm">
                    <div className="flex items-center justify-between px-6 py-4">
                        <div className="flex items-center space-x-2">
                            <button 
                                type="button"
                                className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
                                onClick={handleBack}
                            >
                                <i className="fa-solid fa-arrow-left mr-2"></i>
                                Quay lại
                            </button>
                            <h2 className="text-xl font-bold ml-2">Chi tiết dịch vụ</h2>
                        </div>
                        <div className="flex items-center space-x-4">
                            <button 
                                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                                onClick={handleEdit}
                            >
                                <i className="fa-solid fa-pen-to-square mr-2"></i>
                                Chỉnh sửa
                            </button>
                            <button 
                                className="flex items-center px-4 py-2 border border-red-500 text-red-500 rounded-lg hover:bg-red-50"
                                onClick={handleDelete}
                            >
                                <i className="fa-solid fa-trash mr-2"></i>
                                Xóa dịch vụ
                            </button>
                        </div>
                    </div>
                </header>

                {/* Service Details */}
                <div id="service-details" className="p-6 space-y-6">
                    {/* Basic Info Card */}
                    <div id="basic-info" className="bg-white rounded-lg shadow p-6">
                        <h3 className="text-lg font-semibold mb-4">Thông tin cơ bản</h3>
                        <div className="grid grid-cols-2 gap-6">
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm text-gray-600 mb-1">Tên dịch vụ</label>
                                    <div className="font-medium">{service.name}</div>
                                </div>
                                <div>
                                    <label className="block text-sm text-gray-600 mb-1">Mã dịch vụ</label>
                                    <div className="font-medium">SV{String(service.id).padStart(3, '0')}</div>
                                </div>
                                <div>
                                    <label className="block text-sm text-gray-600 mb-1">Kỹ năng cần có</label>
                                    <div className="flex flex-wrap gap-2">
                                        {service.requiredSkills && service.requiredSkills.length > 0 ? (
                                            service.requiredSkills.map((skill, idx) => (
                                                <span key={idx} className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm font-medium">
                                                    {skill}
                                                </span>
                                            ))
                                        ) : (
                                            <span className="text-gray-400 italic">Không yêu cầu</span>
                                        )}
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm text-gray-600 mb-1">Nhóm dịch vụ</label>
                                    <span className={`px-3 py-1 rounded-full ${
                                        service.category === 'relaxation' ? 'bg-green-100 text-green-700' :
                                        service.category === 'therapeutic' ? 'bg-blue-100 text-blue-700' :
                                        service.category === 'specialty' ? 'bg-purple-100 text-purple-700' :
                                        'bg-pink-100 text-pink-700'
                                    }`}>
                                        {service.category === 'relaxation' ? 'Thư giãn' :
                                         service.category === 'therapeutic' ? 'Trị liệu' :
                                         service.category === 'specialty' ? 'Đặc biệt' : 'Làm đẹp'}
                                    </span>
                                </div>
                            </div>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm text-gray-600 mb-1">Thời gian thực hiện</label>
                                    <div className="font-medium">{service.duration}</div>
                                </div>
                                <div>
                                    <label className="block text-sm text-gray-600 mb-1">Giá dịch vụ</label>
                                    <div className="font-medium">
                                        {Object.entries(service.prices).map(([duration, price]) => (
                                            <div key={duration}>{duration} phút: {price.toLocaleString('vi-VN')}đ</div>
                                        ))}
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm text-gray-600 mb-1">Trạng thái</label>
                                    <span className={`px-3 py-1 rounded-full ${
                                        service.status === 'active' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'
                                    }`}>
                                        {service.status === 'active' ? 'Đang hoạt động' : 'Tạm ngưng'}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Description Card */}
                    <div id="description" className="bg-white rounded-lg shadow p-6">
                        <h3 className="text-lg font-semibold mb-4">Mô tả dịch vụ</h3>
                        <p className="text-gray-600 mb-4">{service.description}</p>
                        <div className="space-y-2">
                            {service.benefits.map((benefit, index) => (
                                <div key={index} className="flex items-center space-x-2">
                                    <i className="fa-solid fa-check text-green-500"></i>
                                    <span>{benefit}</span>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Statistics Card */}
                    <div id="statistics" className="bg-white rounded-lg shadow p-6">
                        <h3 className="text-lg font-semibold mb-4">Thống kê sử dụng</h3>
                        <div className="grid grid-cols-4 gap-6">
                            <div className="text-center">
                                <div className="text-2xl font-bold text-blue-600">{service.statistics.orders}</div>
                                <div className="text-sm text-gray-600">Lượt đặt tháng này</div>
                            </div>
                            <div className="text-center">
                                <div className="text-2xl font-bold text-green-600">{service.statistics.positiveRate}</div>
                                <div className="text-sm text-gray-600">Đánh giá tích cực</div>
                            </div>
                            <div className="text-center">
                                <div className="text-2xl font-bold text-purple-600">{service.statistics.frequentCustomers}</div>
                                <div className="text-sm text-gray-600">Khách hàng thường xuyên</div>
                            </div>
                            <div className="text-center">
                                <div className="text-2xl font-bold text-orange-600">{service.statistics.avgRating}</div>
                                <div className="text-sm text-gray-600">Điểm đánh giá trung bình</div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default ServiceDetailPageAdmin;
