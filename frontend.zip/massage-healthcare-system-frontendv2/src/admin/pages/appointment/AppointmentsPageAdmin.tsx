import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import NewAppointmentForm from './NewAppointmentForm';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { appointmentsData, AppointmentData } from '../../../data/appointmentsData';

const AppointmentsPageAdmin: React.FC = () => {
    const navigate = useNavigate();
    // User info for header (similar to CustomerPageAdmin)
    const [user] = useState({
        avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
        role: 'admin',
    });

    const [showNewAppointmentForm, setShowNewAppointmentForm] = useState(false);
    const [currentDate, setCurrentDate] = useState(new Date());
    const [appointments, setAppointments] = useState<AppointmentData[]>(appointmentsData);
    const [currentPage, setCurrentPage] = useState(1);
    const pageSize = 3;
    const totalPages = Math.ceil(appointments.length / pageSize);
    const paginatedAppointments = appointments.slice((currentPage - 1) * pageSize, currentPage * pageSize);

    const handleLogout = () => {
        // TODO: Implement logout logic
        console.log('Logging out...');
    };

    // Format date for display
    const formatDate = (date: Date) => {
        const days = ['Chủ nhật', 'Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7'];
        const day = days[date.getDay()];
        const dateNum = date.getDate();
        const month = date.getMonth() + 1;
        const year = date.getFullYear();
        return `${day}, ${dateNum} tháng ${month}, ${year}`;
    };

    const handlePreviousDay = () => {
        const prevDate = new Date(currentDate);
        prevDate.setDate(currentDate.getDate() - 1);
        setCurrentDate(prevDate);
        toast.info(`Đã chuyển đến ${formatDate(prevDate)}`);
    };

    const handleNextDay = () => {
        const nextDate = new Date(currentDate);
        nextDate.setDate(currentDate.getDate() + 1);
        setCurrentDate(nextDate);
        toast.info(`Đã chuyển đến ${formatDate(nextDate)}`);
    };

    const handleToday = () => {
        const today = new Date();
        setCurrentDate(today);
        toast.info('Đã chuyển về ngày hôm nay');
    };

    const handleNewAppointment = () => {
        setShowNewAppointmentForm(true);
    };

    const handleCloseAppointmentForm = () => {
        setShowNewAppointmentForm(false);
    };

    const handleAppointmentSubmit = (appointmentData: any) => {
        const newAppointment = {
            ...appointmentData,
            id: String(Date.now()),
            status: 'upcoming',
        };
        setAppointments(prev => [...prev, newAppointment]);
        toast.success('Đã tạo lịch hẹn mới thành công!');
        setShowNewAppointmentForm(false);
    };

    const handleNavigateToReminders = () => {
        navigate('/admin/reminders');
    };

    const handleCancelAppointment = (appointment: any) => {
        const confirmMessage = appointment.status === 'past' 
            ? `Bạn có chắc chắn muốn hủy lịch hẹn của khách hàng ${appointment.customerName}?`
            : `Bạn có chắc chắn muốn hủy lịch hẹn đang chờ của khách hàng ${appointment.customerName}?`;

        if (window.confirm(confirmMessage)) {
            setAppointments(prev =>
                prev.map(apt =>
                    apt.id === appointment.id ? { ...apt, status: 'cancelled' } : apt
                )
            );
            toast.info(`Lịch hẹn của khách hàng ${appointment.customerName} đã được chuyển sang trạng thái 'Đã hủy lịch hẹn'.`);
        }
    };

    const handleConfirmAppointment = (appointment: any) => {
        if (appointment.status === 'past') {
            toast.info('Lịch hẹn đã được xác nhận trước đó!');
            return;
        }
        setAppointments(prev =>
            prev.map(apt =>
                apt.id === appointment.id ? { ...apt, status: 'past' } : apt
            )
        );
        toast.success(`Đã xác nhận lịch hẹn cho khách hàng ${appointment.customerName}`);
    };

    const handleViewDetail = (appointment: any) => {
        navigate(`/admin/appointments/${appointment.id}`);
    };

    const handlePageChange = (page: number) => {
        if (page >= 1 && page <= totalPages) {
            setCurrentPage(page);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50">
            <HeaderAdmin user={user} handleLogout={handleLogout} />
            <SideBarAdmin />
            <ToastContainer position="top-right" autoClose={2000} />
            <main className="ml-64 pt-16">
                {showNewAppointmentForm ? (
                    <NewAppointmentForm 
                        onClose={handleCloseAppointmentForm}
                        onSubmit={handleAppointmentSubmit}
                    />
                ) : (
                    <>
                        {/* Page Header */}
                        <header id="header" className="bg-white shadow-sm">
                            <div className="flex items-center justify-between px-6 py-4">
                                <h2 className="text-xl font-bold">Quản lý Lịch hẹn</h2>
                                <div className="flex items-center space-x-4">
                                    <button 
                                        className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                                        onClick={handleNewAppointment}
                                    >
                                        <i className="fa-solid fa-plus mr-2"></i>
                                        Đặt lịch mới
                                    </button>
                                    <button 
                                        className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                                        onClick={handleNavigateToReminders}
                                    >
                                        <i className="fa-solid fa-bell mr-2"></i>
                                        Quản lý nhắc nhở lịch hẹn
                                    </button>
                                </div>
                            </div>
                        </header>

                        {/* Date Navigation */}
                        <div id="date-nav" className="p-6 bg-white border-b">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-4">
                                    <button 
                                        className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                                        onClick={handlePreviousDay}
                                        title="Ngày trước"
                                    >
                                        <i className="fa-solid fa-chevron-left"></i>
                                    </button>
                                    <h3 className="text-xl font-semibold">{formatDate(currentDate)}</h3>
                                    <button 
                                        className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                                        onClick={handleNextDay}
                                        title="Ngày tiếp theo"
                                    >
                                        <i className="fa-solid fa-chevron-right"></i>
                                    </button>
                                </div>
                                <button 
                                    className="px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                                    onClick={handleToday}
                                >
                                    Hôm nay
                                </button>
                            </div>
                        </div>

                        {/* Schedule Grid */}
                        <div id="schedule-grid" className="p-6">
                            <div className="grid grid-cols-1 gap-4">
                                {paginatedAppointments.map((appointment) => (
                                    <div key={appointment.id} className="bg-white rounded-lg shadow">
                                    <div className="p-4 border-b">
                                        <div className="flex items-center justify-between">
                                                <h4 className="text-lg font-semibold">{appointment.time} - {appointment.duration} phút</h4>
                                                <span className={`px-3 py-1 rounded-full ${
                                                    appointment.status === 'upcoming'
                                                        ? 'bg-yellow-100 text-yellow-700'
                                                        : appointment.status === 'past'
                                                            ? 'bg-green-100 text-green-700'
                                                            : 'bg-red-100 text-red-700'
                                                }`}>
                                                    {appointment.status === 'upcoming' ? 'Đang chờ' : appointment.status === 'past' ? 'Đã xác nhận' : 'Đã hủy lịch hẹn'}
                                                </span>
                                        </div>
                                        <div className="mt-4 grid grid-cols-3 gap-4">
                                            <div>
                                                <p className="text-gray-500">Khách hàng</p>
                                                <div className="flex items-center mt-1">
                                                        <img src={appointment.customerAvatar} className="w-8 h-8 rounded-full mr-2" alt="Customer" />
                                                        <span className="font-medium">{appointment.customerName}</span>
                                                    </div>
                                            </div>
                                            <div>
                                                <p className="text-gray-500">Dịch vụ</p>
                                                    <p className="mt-1 font-medium">{appointment.service}</p>
                                            </div>
                                            <div>
                                                <p className="text-gray-500">Nhân viên</p>
                                                <div className="flex items-center mt-1">
                                                        <img src={appointment.staffAvatar} className="w-8 h-8 rounded-full mr-2" alt="Staff" />
                                                        <span className="font-medium">{appointment.staffName}</span>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="p-4 bg-gray-50 flex justify-end space-x-2">
                                            {appointment.status === 'upcoming' && (
                                                <button
                                                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                                                    onClick={() => handleConfirmAppointment(appointment)}
                                                >
                                                    <i className="fa-solid fa-check mr-2"></i>
                                                    Xác nhận
                                                </button>
                                            )}
                                            <button
                                                className="px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg border border-blue-200"
                                                onClick={() => handleViewDetail(appointment)}
                                            >
                                                <i className="fa-solid fa-eye mr-2"></i>
                                                Xem chi tiết
                                            </button>
                                            {appointment.status !== 'cancelled' && (
                                                <button 
                                                    className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg"
                                                    onClick={() => handleCancelAppointment(appointment)}
                                                >
                                                    <i className="fa-solid fa-times mr-2"></i>
                                                    Hủy lịch
                                                </button>
                                            )}
                                    </div>
                                </div>
                                ))}
                            </div>
                            {/* Pagination Controls */}
                            <div className="flex justify-center mt-6 space-x-2">
                                <button
                                    className="px-3 py-1 rounded border border-gray-300 bg-white hover:bg-gray-100"
                                    onClick={() => handlePageChange(currentPage - 1)}
                                    disabled={currentPage === 1}
                                >
                                    &lt;
                                </button>
                                {Array.from({ length: totalPages }, (_, idx) => (
                                    <button
                                        key={idx + 1}
                                        className={`px-3 py-1 rounded border ${currentPage === idx + 1 ? 'bg-blue-600 text-white' : 'bg-white hover:bg-gray-100'}`}
                                        onClick={() => handlePageChange(idx + 1)}
                                    >
                                        {idx + 1}
                                    </button>
                                ))}
                                <button
                                    className="px-3 py-1 rounded border border-gray-300 bg-white hover:bg-gray-100"
                                    onClick={() => handlePageChange(currentPage + 1)}
                                    disabled={currentPage === totalPages}
                                >
                                    &gt;
                                </button>
                            </div>
                        </div>
                    </>
                )}
            </main>
        </div>
    );
};

export default AppointmentsPageAdmin;
