import React, { useState, useEffect } from 'react';
import NewCustomerFormAdmin from '../customer/NewCustomerFormAdmin';
import { toast } from 'react-toastify';
import { services as individualServices } from '../../../data/individualServiceDataCustomer';
import { allPackages } from '../../../data/packageServiceDataCustomer';
import { customers } from '../../../data/customerData';


interface Staff {
  id: string;
  name: string;
  experience: string;
  avatar: string;
}

interface Appointment {
  customerId?: string;
  customerName?: string;
  serviceId?: string;
  date?: string;
  time?: string;
  staffId?: string;
  notes?: string;
}


const staff: Staff[] = [
  {
    id: '1',
    name: 'Lê Thị Mai',
    experience: 'Có kinh nghiệm',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-5.jpg'
  },
  {
    id: '2',
    name: 'Phạm Thị Hoa',
    experience: 'Chuyên gia',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-6.jpg'
  },
  {
    id: '3',
    name: 'Trần Thị Lan',
    experience: 'Mới',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-7.jpg'
  },
];

const timeSlots = [
  '7:00', '7:30', '8:00', '8:30', '9:00', '9:30', '10:00', '10:30',
  '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30'
];

interface NewAppointmentFormProps {
  onClose: () => void;
  initialData?: {
    id?: string;
    customerId?: string;
    customerName?: string;
    customerAvatar?: string;
    serviceId?: string;
    date?: string;
    time?: string;
    staffId?: string;
    notes?: string;
    status?: string;
  };
  onSubmit?: (data: any) => void;
  isEditMode?: boolean;
}

const NewAppointmentForm: React.FC<NewAppointmentFormProps> = ({ onClose, initialData, onSubmit, isEditMode = false }) => {
  const [showNewCustomerForm, setShowNewCustomerForm] = useState(false);
  const [appointment, setAppointment] = useState<Appointment>({});
  const [, setSelectedService] = useState<string | null>(null);
  const [, setCustomerSearch] = useState('');
  const [serviceType, setServiceType] = useState<'single' | 'package'>('single');
  const [selectedServiceDropdown, setSelectedServiceDropdown] = useState<string>('');
  const [selectedDuration, setSelectedDuration] = useState<string>('');

  useEffect(() => {
    if (initialData) {
      setAppointment(initialData);
      setSelectedService(initialData.serviceId || null);
      if (initialData.customerName) {
        setCustomerSearch(initialData.customerName);
      }
      // Xác định loại dịch vụ và set dropdown
      if (initialData.serviceId) {
        const isSingle = individualServices.some(s => String(s.id) === String(initialData.serviceId));
        setServiceType(isSingle ? 'single' : 'package');
        setSelectedServiceDropdown(initialData.serviceId);
      }
      // Nếu có duration trong initialData thì set luôn
      if ((initialData as any).duration) {
        setSelectedDuration((initialData as any).duration);
      }
    }
  }, [initialData]);


  const handleCustomerSubmit = (customerData: any) => {
    setAppointment(prev => ({
      ...prev,
      customerId: customerData.id,
      customerName: customerData.name,
      customerAvatar: customerData.avatar
    }));
    setShowNewCustomerForm(false);
  };

  const handleSubmit = () => {
    // Validate required fields
    if (!appointment.customerId || !appointment.serviceId || !appointment.date || !appointment.time || !appointment.staffId || (serviceType === 'single' && !selectedDuration)) {
      toast.error('Vui lòng điền đầy đủ thông tin bắt buộc');
      return;
    }

    // Call onSubmit with appointment data
    if (onSubmit) {
      onSubmit({
        ...appointment,
        id: initialData?.id, // Preserve the ID if editing
        duration: serviceType === 'single' ? selectedDuration : undefined
      });
    }
    onClose();
  };

  // Tính ngày mai cho min attribute của input date
  const getTomorrow = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  if (showNewCustomerForm) {
    return (
      <NewCustomerFormAdmin
        onCancel={() => setShowNewCustomerForm(false)}
        onSubmit={handleCustomerSubmit}
      />
    );
  }

  return (
    <div className="max-w-4xl w-full mx-auto bg-white rounded-lg shadow-lg mb-8">
      {/* Top Header */}
      <header id="header" className="bg-white shadow-sm rounded-t-lg">
        <div className="flex items-center justify-between px-6 py-4">
          <h2 className="text-xl font-bold">{isEditMode ? 'Chỉnh sửa lịch hẹn' : 'Đặt lịch mới'}</h2>
          <button
            type="button"
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
            onClick={onClose}
          >
            <i className="fa-solid fa-xmark mr-2"></i>
            Đóng
          </button>
        </div>
      </header>

      <div className="p-6">
        <form className="p-6" onSubmit={(e) => { e.preventDefault(); handleSubmit(); }}>
          {/* Customer Information */}
          <div id="customer-info" className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Thông tin khách hàng</h3>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Chọn khách hàng</label>
                <select
                  className="w-full px-4 py-2 border rounded-lg"
                  value={appointment.customerId || ''}
                  onChange={e => {
                    const selected = customers.find(c => c.id === e.target.value);
                    setAppointment(prev => ({
                      ...prev,
                      customerId: selected?.id,
                      customerName: selected?.name,
                      customerAvatar: selected?.avatar
                    }));
                  }}
                >
                  <option value="">Chọn khách hàng</option>
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>{c.name} - {c.phone}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Service Selection */}
          <div id="service-selection" className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Chọn dịch vụ</h3>
            {/* Dropdown menus for service type and service/package selection */}
            <div className="flex flex-row gap-4 items-end">
              <div className="w-1/3">
                <label className="block text-sm font-medium text-gray-700 mb-2">Loại dịch vụ</label>
                <select
                  className="w-full px-4 py-2 border rounded-lg"
                  value={serviceType}
                  onChange={e => {
                    setServiceType(e.target.value as 'single' | 'package');
                    setSelectedServiceDropdown('');
                  }}
                >
                  <option value="single">Dịch vụ đơn lẻ</option>
                  <option value="package">Gói dịch vụ</option>
                </select>
              </div>
              <div className="w-2/3">
                <label className="block text-sm font-medium text-gray-700 mb-2">{serviceType === 'single' ? 'Chọn dịch vụ đơn lẻ' : 'Chọn gói dịch vụ'}</label>
                <select
                  className="w-full px-4 py-2 border rounded-lg"
                  value={selectedServiceDropdown}
                  onChange={e => {
                    setSelectedServiceDropdown(e.target.value);
                    setAppointment(prev => ({ ...prev, serviceId: e.target.value }));
                  }}
                >
                  <option value="">Chọn {serviceType === 'single' ? 'dịch vụ đơn lẻ' : 'gói dịch vụ'}</option>
                  {(serviceType === 'single' ? individualServices : allPackages).map(item => (
                    <option key={item.id} value={item.id}>{item.name}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4 mb-6 pt-4">
              {/* Hiển thị duy nhất dịch vụ/gói đã chọn từ dropdown */}
              {serviceType === 'single' && selectedServiceDropdown && (() => {
                const s = individualServices.find(item => String(item.id) === selectedServiceDropdown);
                if (!s) return null;
                // Nếu có nhiều mức giá, hiển thị mỗi mức giá là một thẻ grid
                return (
                  <>
                    {s.prices && Object.entries(s.prices).map(([duration, price]) => (
                      <div
                        key={duration}
                        className={`border rounded-lg p-4 cursor-pointer transition-all ${selectedDuration === duration ? 'ring-2 ring-blue-600 border-blue-600' : ''}`}
                        onClick={() => setSelectedDuration(duration)}
                      >
                        <p className="text-sm text-gray-500 mt-1">{duration} phút</p>
                        <p className="text-blue-600 mt-2">{Number(price).toLocaleString()}đ</p>
                        {selectedDuration === duration && (
                          <div className="mt-2 text-xs text-blue-600 font-semibold">Đã chọn</div>
                        )}
                      </div>
                    ))}
                  </>
                );
              })()}
              {serviceType === 'package' && selectedServiceDropdown && (() => {
                const p = allPackages.find(item => String(item.id) === selectedServiceDropdown);
                if (!p) return null;
                // Ưu tiên currentPrice, nếu không có thì lấy giá đầu tiên trong prices
                let price = p.currentPrice;
                if (!price && p.prices) {
                  const firstPrice = Object.values(p.prices)[0];
                  price = firstPrice ? firstPrice.toLocaleString() + 'đ' : '';
                }
                return (
                  <div className="border rounded-lg p-4">
                    <p className="text-sm text-gray-500 mt-1">{p.duration}</p>
                    <p className="text-blue-600 mt-2">{price}</p>
                  </div>
                );
              })()}
            </div>

          </div>

          {/* Date & Time Selection */}
          <div id="datetime-selection" className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Chọn thời gian</h3>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Ngày</label>
                <input
                  type="date"
                  className="w-full px-4 py-2 border rounded-lg"
                  value={appointment.date || ''}
                  min={getTomorrow()}
                  onChange={(e) => setAppointment(prev => ({ ...prev, date: e.target.value }))}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Thời gian</label>
                <select
                  className="w-full px-4 py-2 border rounded-lg"
                  value={appointment.time || ''}
                  onChange={(e) => setAppointment(prev => ({ ...prev, time: e.target.value }))}
                >
                  <option value="">Chọn thời gian</option>
                  {timeSlots.map((time) => (
                    <option key={time} value={time}>{time}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Staff Selection */}
          <div id="staff-selection" className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Chọn nhân viên</h3>
            <div className="grid grid-cols-4 gap-4">
              {staff.map((person) => (
                <div
                  key={person.id}
                  className={`text-center cursor-pointer ${appointment.staffId === person.id ? 'ring-2 ring-blue-600 rounded-lg p-2' : ''
                    }`}
                  onClick={() => setAppointment(prev => ({ ...prev, staffId: person.id }))}
                >
                  <img
                    src={person.avatar}
                    alt={person.name}
                    className="w-16 h-16 rounded-full mx-auto mb-2"
                  />
                  <p className="font-medium">{person.name}</p>
                  <p className="text-sm text-gray-500">{person.experience}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div id="booking-notes" className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Ghi chú</h3>
            <textarea
              className="w-full px-4 py-2 border rounded-lg"
              rows={3}
              placeholder="Thêm ghi chú về lịch hẹn..."
              value={appointment.notes || ''}
              onChange={(e) => setAppointment(prev => ({ ...prev, notes: e.target.value }))}
            ></textarea>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-4 pt-6 border-t">
            <button
              type="button"
              className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              onClick={onClose}
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center"
            >
              <i className="fa-solid fa-check mr-2"></i>
              {isEditMode ? 'Cập nhật lịch hẹn' : 'Xác nhận đặt lịch'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewAppointmentForm;
