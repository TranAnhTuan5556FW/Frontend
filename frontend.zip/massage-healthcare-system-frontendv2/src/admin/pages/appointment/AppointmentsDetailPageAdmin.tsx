import React from 'react';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import { useParams, useNavigate } from 'react-router-dom';
import { getAppointmentById, AppointmentData } from '../../../data/appointmentsData';

const AppointmentsDetailPageAdmin: React.FC = () => {
  // Static user for header
  const user = {
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    role: 'admin',
  };

  // Lấy id từ URL
  const { id } = useParams<{ id: string }>();
  const appointment: AppointmentData | undefined = id ? getAppointmentById(Number(id)) : undefined;

  // Dummy logout handler for consistency
  const handleLogout = () => {
    // TODO: Implement logout logic
    console.log('Logging out...');
  };

  const navigate = useNavigate();
  const handleBack = () => {
    navigate(-1);
  };

  if (!appointment) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="bg-white p-8 rounded shadow text-center">
          <h2 className="text-xl font-bold mb-4">Không tìm thấy lịch hẹn</h2>
          <button onClick={handleBack} className="px-4 py-2 bg-blue-600 text-white rounded-lg">Quay lại</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <HeaderAdmin user={user} handleLogout={handleLogout} />
      <SideBarAdmin />
      <main className="ml-64 pt-16">
        {/* Page Header (not fixed) */}
        <div className="bg-white shadow-sm">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center space-x-3">
              <button 
                className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
                onClick={handleBack}
              >
                <i className="fa-solid fa-arrow-left mr-2"></i>
                Quay lại
              </button>
              <h2 className="text-xl font-bold">Chi tiết lịch hẹn #A12345</h2>
              <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full">Đã xác nhận</span>
            </div>
            <div className="flex items-center space-x-3">
              <button className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">
                <i className="fa-solid fa-print mr-2"></i>
                In phiếu hẹn
              </button>
            </div>
          </div>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-3 gap-6">
            {/* Left Column */}
            <div className="col-span-2 space-y-6">
              {/* Appointment Details */}
              <div id="appointment-details" className="bg-white rounded-lg shadow">
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Thông tin lịch hẹn</h3>
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <p className="text-gray-500">Ngày hẹn</p>
                      <p className="font-medium mt-1">{appointment.date}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Thời gian</p>
                      <p className="font-medium mt-1">{appointment.time} ({appointment.duration} phút)</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Dịch vụ</p>
                      <p className="font-medium mt-1">{appointment.service}</p>
                    </div>
                  </div>
                </div>
              </div>
              {/* Service Details */}
              <div id="service-details" className="bg-white rounded-lg shadow">
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Chi tiết dịch vụ</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <i className="fa-solid fa-spa text-2xl text-blue-600"></i>
                        <div>
                          <h4 className="font-medium">{appointment.service}</h4>
                          <p className="text-gray-500">{appointment.duration} phút</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{appointment.servicePrice ? appointment.servicePrice.toLocaleString() + 'đ' : '-'}</p>
                        <p className="text-sm text-gray-500">Đã bao gồm VAT</p>
                      </div>
                    </div>
                  </div>
                  <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">Tổng cộng</span>
                      <span className="text-xl font-bold">{appointment.servicePrice ? appointment.servicePrice.toLocaleString() + 'đ' : '-'}</span>
                    </div>
                  </div>
                </div>
              </div>
              {/* Notes */}
              <div id="appointment-notes" className="bg-white rounded-lg shadow">
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Ghi chú</h3>
                  <div className="bg-yellow-50 p-4 rounded-lg">
                    <p className="text-gray-700">{appointment.notes}</p>
                  </div>
                </div>
              </div>
            </div>
            {/* Right Column */}
            <div className="space-y-6">
              {/* Customer Info */}
              <div id="customer-info" className="bg-white rounded-lg shadow">
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Thông tin khách hàng</h3>
                  <div className="flex items-center mb-4">
                    <img src={appointment.customerAvatar} className="w-16 h-16 rounded-full mr-4" alt="avatar" />
                    <div>
                      <h4 className="font-medium">{appointment.customerName}</h4>
                      <p className="text-gray-500">{appointment.customerType}</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <p className="text-gray-500">Số điện thoại</p>
                      <p className="font-medium">{appointment.customerPhone}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Email</p>
                      <p className="font-medium">{appointment.customerEmail}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Số lần sử dụng dịch vụ</p>
                      <p className="font-medium">{appointment.customerUsageCount} lần</p>
                    </div>
                  </div>
                </div>
              </div>
              {/* Staff Info */}
              <div id="staff-info" className="bg-white rounded-lg shadow">
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Nhân viên phục vụ</h3>
                  <div className="flex items-center mb-4">
                    <img src={appointment.staffAvatar} className="w-16 h-16 rounded-full mr-4" alt="avatar" />
                    <div>
                      <h4 className="font-medium">{appointment.staffName}</h4>
                      <p className="text-gray-500">{appointment.staffRole}</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <p className="text-gray-500">Kinh nghiệm</p>
                      <p className="font-medium">{appointment.staffExperience} năm</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Chuyên môn</p>
                      <p className="font-medium">{appointment.staffSpecialty}</p>
                    </div>
                  </div>
                </div>
              </div>
              {/* Appointment History */}
              <div id="appointment-history" className="bg-white rounded-lg shadow">
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Lịch sử đặt hẹn</h3>
                  <div className="space-y-4">
                    {appointment.history && appointment.history.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{item.date}</p>
                          <p className="text-gray-500">{item.service}</p>
                        </div>
                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">{item.status}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AppointmentsDetailPageAdmin;
