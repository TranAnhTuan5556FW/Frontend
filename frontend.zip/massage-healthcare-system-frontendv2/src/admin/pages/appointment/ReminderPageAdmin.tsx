import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import '@fortawesome/fontawesome-free/css/all.min.css';

const ReminderPageAdmin: React.FC = () => {
    const navigate = useNavigate();
    // User info for header - reusing from CustomerPageAdmin
    const [user] = useState({
        avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
        role: 'admin',
    });

    const handleLogout = () => {
        // TODO: Implement logout logic
        console.log('Logging out...');
    };

    const handleBack = () => {
        navigate('/admin/appointments');
    };

    const handleSendManualReminder = () => {
        navigate('/admin/send-manual-reminder');
    };

    return (
        <div className="min-h-screen bg-gray-50">
            <HeaderAdmin user={user} handleLogout={handleLogout} />
            <SideBarAdmin />
            <main className="ml-64 pt-16">
                {/* Page Header */}
                <header id="header" className="bg-white shadow-sm">
                    <div className="flex items-center justify-between px-6 py-4">
                        <div className="flex items-center space-x-4">
                            <button 
                                type="button"
                                className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
                                onClick={handleBack}
                            >
                                <i className="fa-solid fa-arrow-left mr-2"></i>
                                Quay lại
                            </button>
                            <h2 className="text-xl font-bold">Quản lý nhắc nhở lịch hẹn</h2>
                        </div>
                        <div className="flex items-center space-x-4">
                            <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700" onClick={handleSendManualReminder}>
                                <i className="fa-solid fa-paper-plane mr-2"></i>
                                Gửi nhắc nhở thủ công
                            </button>
                            <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                                <i className="fa-solid fa-gear mr-2"></i>
                                Cài đặt tự động
                            </button>
                        </div>
                    </div>
                </header>

                {/* Stats Cards */}
                <div id="reminder-stats" className="grid grid-cols-4 gap-6 p-6">
                    <div className="bg-white rounded-lg shadow p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-500">Tổng nhắc nhở</p>
                                <h3 className="text-2xl font-bold mt-1">156</h3>
                            </div>
                            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                                <i className="fa-solid fa-bell text-blue-600 text-xl"></i>
                            </div>
                        </div>
                        <p className="text-green-600 mt-4">
                            <i className="fa-solid fa-arrow-up"></i>
                            <span className="ml-1">12% so với tuần trước</span>
                        </p>
                    </div>

                    <div className="bg-white rounded-lg shadow p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-500">Tỷ lệ xác nhận</p>
                                <h3 className="text-2xl font-bold mt-1">85%</h3>
                            </div>
                            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                                <i className="fa-solid fa-check text-green-600 text-xl"></i>
                            </div>
                        </div>
                        <p className="text-green-600 mt-4">
                            <i className="fa-solid fa-arrow-up"></i>
                            <span className="ml-1">5% so với tuần trước</span>
                        </p>
                    </div>

                    <div className="bg-white rounded-lg shadow p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-500">Tỷ lệ hủy</p>
                                <h3 className="text-2xl font-bold mt-1">8%</h3>
                            </div>
                            <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                                <i className="fa-solid fa-xmark text-red-600 text-xl"></i>
                            </div>
                        </div>
                        <p className="text-red-600 mt-4">
                            <i className="fa-solid fa-arrow-down"></i>
                            <span className="ml-1">2% so với tuần trước</span>
                        </p>
                    </div>

                    <div className="bg-white rounded-lg shadow p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-500">No-show</p>
                                <h3 className="text-2xl font-bold mt-1">7%</h3>
                            </div>
                            <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                                <i className="fa-solid fa-user-clock text-yellow-600 text-xl"></i>
                            </div>
                        </div>
                        <p className="text-yellow-600 mt-4">
                            <i className="fa-solid fa-minus"></i>
                            <span className="ml-1">Không đổi so với tuần trước</span>
                        </p>
                    </div>
                </div>

                {/* Reminder History Table */}
                <div id="reminder-history" className="px-6">
                    <div className="bg-white rounded-lg shadow">
                        <div className="p-6 border-b">
                            <h3 className="text-lg font-semibold">Lịch sử nhắc nhở</h3>
                        </div>
                        <table className="w-full">
                            <thead>
                                <tr className="text-left border-b">
                                    <th className="px-6 py-4">Khách hàng</th>
                                    <th className="px-6 py-4">Lịch hẹn</th>
                                    <th className="px-6 py-4">Phương thức</th>
                                    <th className="px-6 py-4">Thời gian gửi</th>
                                    <th className="px-6 py-4">Trạng thái</th>
                                    <th className="px-6 py-4">Phản hồi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className="border-b hover:bg-gray-50">
                                    <td className="px-6 py-4">
                                        <div className="flex items-center space-x-3">
                                            <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg" className="w-10 h-10 rounded-full" alt="Avatar" />
                                            <div>
                                                <div className="font-medium">Nguyễn Thị Anh</div>
                                                <div className="text-sm text-gray-500">0912345678</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div>Massage thư giãn</div>
                                        <div className="text-sm text-gray-500">15:00 - 26/04/2025</div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full">SMS</span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div>25/04/2025</div>
                                        <div className="text-sm text-gray-500">14:00</div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full">Đã gửi</span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full">Đã xác nhận</span>
                                    </td>
                                </tr>

                                <tr className="border-b hover:bg-gray-50">
                                    <td className="px-6 py-4">
                                        <div className="flex items-center space-x-3">
                                            <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg" className="w-10 h-10 rounded-full" alt="Avatar" />
                                            <div>
                                                <div className="font-medium">Trần Văn Bình</div>
                                                <div className="text-sm text-gray-500">0987654321</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div>Massage chân</div>
                                        <div className="text-sm text-gray-500">16:30 - 26/04/2025</div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full">Email</span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div>25/04/2025</div>
                                        <div className="text-sm text-gray-500">14:00</div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full">Đã gửi</span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full">Đã hủy</span>
                                    </td>
                                </tr>

                                <tr className="hover:bg-gray-50">
                                    <td className="px-6 py-4">
                                        <div className="flex items-center space-x-3">
                                            <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-5.jpg" className="w-10 h-10 rounded-full" alt="Avatar" />
                                            <div>
                                                <div className="font-medium">Lê Thị Cúc</div>
                                                <div className="text-sm text-gray-500">0965432198</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div>Massage body</div>
                                        <div className="text-sm text-gray-500">17:00 - 26/04/2025</div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full">SMS</span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div>25/04/2025</div>
                                        <div className="text-sm text-gray-500">14:00</div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full">Đã gửi</span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full">Chưa phản hồi</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        {/* Pagination */}
                        <div className="px-6 py-4 flex items-center justify-between border-t">
                            <div className="text-gray-600">
                                Hiển thị 1-3 trong tổng số 28 nhắc nhở
                            </div>
                            <div className="flex space-x-2">
                                <button className="px-3 py-1 border rounded hover:bg-gray-50">
                                    <i className="fa-solid fa-chevron-left"></i>
                                </button>
                                <button className="px-3 py-1 bg-blue-600 text-white rounded">1</button>
                                <button className="px-3 py-1 border rounded hover:bg-gray-50">2</button>
                                <button className="px-3 py-1 border rounded hover:bg-gray-50">3</button>
                                <button className="px-3 py-1 border rounded hover:bg-gray-50">
                                    <i className="fa-solid fa-chevron-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default ReminderPageAdmin;
