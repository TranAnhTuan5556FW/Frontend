import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import '@fortawesome/fontawesome-free/css/all.min.css';

const SendManualReminders: React.FC = () => {
  const navigate = useNavigate();
  const [user] = useState({
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    role: 'admin',
    name: 'Admin',
  });

  // Function to get tomorrow's date in ISO format for datetime-local input
  const getTomorrowDateTime = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    // Format to YYYY-MM-DDThh:mm
    return tomorrow.toISOString().slice(0, 16);
  };

  const handleLogout = () => {
    // TODO: Implement logout logic
    console.log('Logging out...');
  };

  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <HeaderAdmin user={user} handleLogout={handleLogout} />
      <SideBarAdmin />
      <main className="ml-64 pt-16 flex-1">
        {/* Top Header */}
        <header id="header" className="bg-white shadow-sm">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center space-x-4">
              <button
                className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                onClick={handleBack}
              >
                <i className="fa-solid fa-arrow-left mr-2"></i>
                Quay lại
              </button>
              <h2 className="text-xl font-bold">Gửi nhắc nhở thủ công</h2>
            </div>
          </div>
        </header>

        {/* Manual Reminder Form */}
        <div id="manual-reminder-form" className="p-6">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="grid grid-cols-2 gap-6">
              {/* Left Column */}
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Chọn khách hàng</label>
                  <div className="flex items-center space-x-4">
                    <select className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                      <option>Chọn khách hàng...</option>
                      <option>Nguyễn Thị Anh - 0912345678</option>
                      <option>Trần Văn Bình - 0987654321</option>
                      <option>Lê Thị Cúc - 0965432198</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Chọn lịch hẹn</label>
                  <select className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500">
                    <option>Chọn lịch hẹn...</option>
                    <option>Massage thư giãn - 15:00 26/04/2025</option>
                    <option>Massage chân - 16:30 26/04/2025</option>
                    <option>Massage body - 17:00 26/04/2025</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phương thức gửi</label>
                  <div className="space-y-2">
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" className="rounded text-blue-600 focus:ring-blue-500" />
                      <span>SMS</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" className="rounded text-blue-600 focus:ring-blue-500" />
                      <span>Email</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" className="rounded text-blue-600 focus:ring-blue-500" />
                      <span>Zalo</span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Thời gian gửi</label>
                  <input 
                    type="datetime-local" 
                    className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    min={getTomorrowDateTime()}
                  />
                  <p className="mt-1 text-sm text-gray-500">Thời gian gửi phải sau ngày hiện tại ít nhất 1 ngày</p>
                </div>
              </div>

              {/* Right Column */}
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Nội dung mẫu</label>
                  <select className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500 mb-4">
                    <option>Chọn mẫu tin nhắn...</option>
                    <option>Nhắc nhở lịch hẹn cơ bản</option>
                    <option>Nhắc nhở VIP</option>
                    <option>Nhắc nhở khuyến mãi</option>
                  </select>
                  <textarea
                    rows={8}
                    className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    placeholder={`Kính gửi [Tên khách hàng],\n\nChúng tôi xin nhắc nhở bạn có lịch hẹn [Tên dịch vụ] vào lúc [Giờ] ngày [Ngày].\n\nVui lòng xác nhận lại lịch hẹn bằng cách trả lời tin nhắn này.\n\nTrân trọng,\n[Tên Spa]`}
                  ></textarea>
                  <div className="mt-2 flex items-center space-x-4 text-sm text-gray-500">
                    <span><i className="fa-solid fa-wand-magic-sparkles mr-1"></i> Mẫu</span>
                    <span><i className="fa-solid fa-user mr-1"></i> Tên KH</span>
                    <span><i className="fa-solid fa-calendar mr-1"></i> Ngày giờ</span>
                    <span><i className="fa-solid fa-spa mr-1"></i> Tên DV</span>
                  </div>
                </div>
                <div className="pt-4">
                  <button className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 flex items-center justify-center">
                    <i className="fa-solid fa-paper-plane mr-2"></i>
                    Gửi nhắc nhở
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Preview Section */}
        <div id="preview-section" className="px-6 pb-6">
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Xem trước tin nhắn</h3>
            <div className="grid grid-cols-3 gap-6">
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium">SMS Preview</span>
                  <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">SMS</span>
                </div>
                <div className="bg-gray-50 rounded-lg p-3 text-sm">
                  Kính gửi Nguyễn Thị Anh,<br />
                  Chúng tôi xin nhắc nhở bạn có lịch hẹn Massage thư giãn vào lúc 15:00 ngày 26/04/2025...
                </div>
              </div>
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium">Email Preview</span>
                  <span className="px-2 py-1 bg-purple-100 text-purple-700 rounded-full text-xs">Email</span>
                </div>
                <div className="bg-gray-50 rounded-lg p-3 text-sm">
                  [Email template preview]
                </div>
              </div>
              <div className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium">Zalo Preview</span>
                  <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">Zalo</span>
                </div>
                <div className="bg-gray-50 rounded-lg p-3 text-sm">
                  [Zalo message preview]
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default SendManualReminders;
