import React, { useState, useMemo } from 'react';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { Link } from 'react-router-dom';
import NewInvoiceForm from './NewInvoiceForm';

const PaymentPageAdmin: React.FC = () => {
  // User info for header
  const [user] = useState({
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    role: 'admin',
  });

  const [showInvoiceForm, setShowInvoiceForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [customerNameSearch, setCustomerNameSearch] = useState('');

  // Mock invoice data
  const [invoices] = useState([
    {
      id: 'HD001',
      customerName: 'Nguyễn Thị Anh',
      date: '25/04/2025',
      service: 'Massage thư giãn',
      total: '500,000đ',
      status: 'paid'
    },
    {
      id: 'HD002',
      customerName: 'Trần Văn Bình',
      date: '24/04/2025',
      service: 'Massage đá nóng',
      total: '800,000đ',
      status: 'pending'
    }
  ]);

  // Filter invoices based on search query, customer name and status
  const filteredInvoices = useMemo(() => {
    return invoices.filter(invoice => {
      const matchesSearch = searchQuery === '' || 
        Object.values(invoice).some(value => 
          value.toString().toLowerCase().includes(searchQuery.toLowerCase())
        );
      const matchesStatus = statusFilter === '' || invoice.status === statusFilter;
      const matchesCustomerName = customerNameSearch === '' || 
        invoice.customerName.toLowerCase().includes(customerNameSearch.toLowerCase());
      return matchesSearch && matchesStatus && matchesCustomerName;
    });
  }, [invoices, searchQuery, statusFilter, customerNameSearch]);

  const handleLogout = () => {
    // TODO: Implement logout logic
    console.log('Logging out...');
  };

  // Sự kiện đóng form (truyền xuống NewInvoiceForm)
  const handleCancelInvoiceForm = () => setShowInvoiceForm(false);

  return (
    <div className="min-h-screen bg-gray-100">
      <HeaderAdmin user={user} handleLogout={handleLogout} />
      <SideBarAdmin />
      <main className="ml-64 pt-16">
        {showInvoiceForm ? (
          <NewInvoiceForm onCancel={handleCancelInvoiceForm} />
        ) : (
          <>
            {/* Top Header */}
            <header id="header" className="bg-white shadow-sm">
              <div className="flex items-center justify-between px-6 py-4">
                <h2 className="text-xl font-bold">Thanh toán & Hóa đơn</h2>
                <div className="flex items-center space-x-4">
                  <button
                    className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    onClick={() => setShowInvoiceForm(true)}
                  >
                    <i className="fa-solid fa-plus mr-2"></i>
                    Tạo hóa đơn mới
                  </button>
                  <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    <i className="fa-solid fa-file-export mr-2"></i>
                    Xuất báo cáo
                  </button>
                </div>
              </div>
            </header>

            {/* Payment Form */}
            <div id="payment-form" className="p-6">
              <div className="grid grid-cols-3 gap-6">
                {/* Payment Details */}
                <div className="col-span-2 bg-white rounded-lg shadow p-6">
                  <h3 className="text-lg font-semibold mb-4">Chi tiết thanh toán</h3>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Khách hàng</label>
                      <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option>Chọn khách hàng</option>
                        <option>Nguyễn Thị Anh (#KH001)</option>
                        <option>Trần Văn Bình (#KH002)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Ngày hóa đơn</label>
                      <input type="date" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                    </div>
                  </div>
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Dịch vụ</label>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center">
                          <input type="checkbox" className="mr-3" />
                          <div>
                            <div className="font-medium">Massage thư giãn toàn thân</div>
                            <div className="text-sm text-gray-500">60 phút</div>
                          </div>
                        </div>
                        <div className="font-medium">500,000đ</div>
                      </div>
                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center">
                          <input type="checkbox" className="mr-3" />
                          <div>
                            <div className="font-medium">Massage đá nóng</div>
                            <div className="text-sm text-gray-500">90 phút</div>
                          </div>
                        </div>
                        <div className="font-medium">800,000đ</div>
                      </div>
                    </div>
                  </div>
                  <div className="border-t pt-4">
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-600">Tạm tính:</span>
                      <span>1,300,000đ</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-600">Giảm giá (10%):</span>
                      <span className="text-red-600">-130,000đ</span>
                    </div>
                    <div className="flex justify-between text-lg font-semibold">
                      <span>Tổng cộng:</span>
                      <span>1,170,000đ</span>
                    </div>
                  </div>
                </div>
                {/* Payment Methods */}
                <div className="bg-white rounded-lg shadow p-6">
                  <h3 className="text-lg font-semibold mb-4">Phương thức thanh toán</h3>
                  <div className="space-y-4">
                    <label className="flex items-center p-4 border rounded-lg cursor-pointer">
                      <input type="radio" name="payment" className="mr-3" />
                      <div>
                        <div className="font-medium">Tiền mặt</div>
                        <div className="text-sm text-gray-500">Thanh toán trực tiếp</div>
                      </div>
                    </label>
                    <label className="flex items-center p-4 border rounded-lg cursor-pointer">
                      <input type="radio" name="payment" className="mr-3" />
                      <div>
                        <div className="font-medium">Thẻ ngân hàng</div>
                        <div className="text-sm text-gray-500">Visa, Mastercard, JCB</div>
                      </div>
                    </label>
                    <label className="flex items-center p-4 border rounded-lg cursor-pointer">
                      <input type="radio" name="payment" className="mr-3" />
                      <div>
                        <div className="font-medium">Chuyển khoản</div>
                        <div className="text-sm text-gray-500">Internet Banking, MoMo</div>
                      </div>
                    </label>
                  </div>
                  <button className="w-full mt-6 px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700">
                    Xác nhận thanh toán
                  </button>
                </div>
              </div>
            </div>

            {/* Recent Invoices */}
            <div id="recent-invoices" className="px-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Lịch sử hóa đơn gần đây</h3>
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <i className="fa-solid fa-search absolute left-3 top-2.5 text-gray-400"></i>
                    <input
                      type="text"
                      placeholder="Tìm kiếm hóa đơn..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  <div className="relative">
                    <i className="fa-solid fa-user absolute left-3 top-2.5 text-gray-400"></i>
                    <input
                      type="text"
                      placeholder="Tìm theo tên khách hàng..."
                      value={customerNameSearch}
                      onChange={(e) => setCustomerNameSearch(e.target.value)}
                      className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  <select 
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                  >
                    <option value="">Tất cả trạng thái</option>
                    <option value="paid">Đã thanh toán</option>
                    <option value="pending">Chờ thanh toán</option>
                    <option value="cancelled">Đã hủy</option>
                  </select>
                </div>
              </div>
              <div className="bg-white rounded-lg shadow">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="px-6 py-4">Mã HĐ</th>
                      <th className="px-6 py-4">Khách hàng</th>
                      <th className="px-6 py-4">Ngày</th>
                      <th className="px-6 py-4">Dịch vụ</th>
                      <th className="px-6 py-4">Tổng tiền</th>
                      <th className="px-6 py-4">Trạng thái</th>
                      <th className="px-6 py-4"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredInvoices.map(invoice => (
                      <tr key={invoice.id} className="border-b hover:bg-gray-50">
                        <td className="px-6 py-4 font-medium">
                          <Link to={`/admin/invoices/${invoice.id}`} className="text-blue-600 hover:underline">#{invoice.id}</Link>
                        </td>
                        <td className="px-6 py-4">{invoice.customerName}</td>
                        <td className="px-6 py-4">{invoice.date}</td>
                        <td className="px-6 py-4">{invoice.service}</td>
                        <td className="px-6 py-4">{invoice.total}</td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full ${
                            invoice.status === 'paid' 
                              ? 'bg-green-100 text-green-700' 
                              : invoice.status === 'pending'
                              ? 'bg-yellow-100 text-yellow-700'
                              : 'bg-red-100 text-red-700'
                          }`}>
                            {invoice.status === 'paid' ? 'Đã thanh toán' : invoice.status === 'pending' ? 'Chờ thanh toán' : 'Đã hủy'}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <button className="text-blue-600 hover:text-blue-800">
                            <i className="fa-solid fa-print"></i>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default PaymentPageAdmin;
