import React, { useState } from 'react';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { useNavigate } from 'react-router-dom';

const InvoiceDetailsPageAdmin: React.FC = () => {
    // Mock user for header
    const [user] = useState({
        avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
        role: 'admin',
        name: 'Admin',
    });

    // Mock invoice data
    const invoice = {
        id: 'HD001',
        date: '25/04/2025',
        customer: {
            name: 'Nguyễn Thị Anh',
            phone: '0912345678',
            email: 'khachhang@email.com',
        },
        staff: {
            name: 'Trần Thị Bình',
            id: 'NV002',
        },
        services: [
            { name: 'Massage thư giãn toàn thân', price: 500000, quantity: 1, duration: '60 phút' },
            { name: 'Tinh dầu đặc biệt', price: 100000, quantity: 1, duration: 'Phụ phí' },
        ],
        subtotal: 600000,
        discount: 60000,
        vat: 43200,
        total: 583200,
        payment: {
            method: 'Tiền mặt',
            paid: true,
            paidAt: '25/04/2025 15:30',
        },
        notes: 'Khách hàng hài lòng với dịch vụ. Đề xuất tặng voucher giảm giá cho lần sau.',
        spa: {
            name: 'Spa & Massage Center',
            address: '123 Đường ABC, Quận 1, TP.HCM',
            logo: '', // Add logo URL if available
        },
    };

    const navigate = useNavigate();

    function handleLogout(): void {
        throw new Error('Function not implemented.');
    }

    return (
        <div className="min-h-screen bg-gray-50">
            <HeaderAdmin user={user} handleLogout={handleLogout} />
            <SideBarAdmin />
            <main className="ml-64 pt-16">
                {/* Top Header */}
                <header id="header" className="bg-white shadow-sm">
                    <div className="flex items-center justify-between px-6 py-4">
                        <div className="flex items-center space-x-4">
                            <button
                                type="button"
                                className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
                                onClick={() => navigate(-1)}
                            >
                                <i className="fa-solid fa-arrow-left mr-2"></i>
                                Quay lại
                            </button>
                            <h2 className="text-2xl font-bold flex items-center gap-3">
                                Chi tiết hóa đơn <span className="text-blue-600">#{invoice.id}</span>
                                <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">Đã thanh toán</span>
                            </h2>
                        </div>
                        <div className="flex space-x-3">
                            <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                                <i className="fa-solid fa-print mr-2"></i> In hóa đơn
                            </button>
                            <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                                <i className="fa-solid fa-file-arrow-down mr-2"></i> Tải PDF
                            </button>
                        </div>
                    </div>
                </header>

                
                <div id="invoice-detail" className="p-6">
                    <div className="grid grid-cols-3 gap-6">
                        {/* Left Column */}
                        <div className="col-span-2 space-y-6">
                            {/* Invoice Info */}
                            <div id="invoice-info" className="bg-white rounded-lg shadow p-6">
                                <div className="flex justify-between items-start mb-6">
                                    <div>
                                        <h3 className="text-lg font-semibold mb-2">Thông tin hóa đơn</h3>
                                        <p className="text-gray-600">Ngày: {invoice.date}</p>
                                        <p className="text-gray-600">Mã HĐ: #{invoice.id}</p>
                                    </div>
                                    <div className="text-right">
                                        <img src={invoice.spa.logo || 'https://via.placeholder.com/120x40'} alt="Logo" className="mb-2 w-[120px] h-[40px] object-contain" />
                                        <p className="text-gray-600">{invoice.spa.name}</p>
                                        <p className="text-gray-600">{invoice.spa.address}</p>
                                    </div>
                                </div>
                                <div className="grid grid-cols-2 gap-6 border-t border-b py-6">
                                    <div>
                                        <h4 className="font-medium mb-2">Thông tin khách hàng</h4>
                                        <p className="text-gray-600">{invoice.customer.name}</p>
                                        <p className="text-gray-600">{invoice.customer.phone}</p>
                                        <p className="text-gray-600">{invoice.customer.email}</p>
                                    </div>
                                    <div>
                                        <h4 className="font-medium mb-2">Nhân viên phục vụ</h4>
                                        <p className="text-gray-600">{invoice.staff.name}</p>
                                        <p className="text-gray-600">ID: {invoice.staff.id}</p>
                                    </div>
                                </div>
                            </div>
                            {/* Services List */}
                            <div id="services-list" className="bg-white rounded-lg shadow p-6">
                                <h3 className="text-lg font-semibold mb-4">Chi tiết dịch vụ</h3>
                                <div className="space-y-4">
                                    {invoice.services.map((s, idx) => (
                                        <div key={idx} className="flex items-center justify-between p-4 border rounded-lg">
                                            <div>
                                                <div className="font-medium">{s.name}</div>
                                                <div className="text-sm text-gray-500">{s.duration}</div>
                                            </div>
                                            <div className="text-right">
                                                <div className="font-medium">{s.price.toLocaleString('vi-VN')}đ</div>
                                                <div className="text-sm text-gray-500">{s.quantity} x {s.price.toLocaleString('vi-VN')}đ</div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                        {/* Right Column */}
                        <div className="space-y-6">
                            {/* Payment Summary */}
                            <div id="payment-summary" className="bg-white rounded-lg shadow p-6">
                                <h3 className="text-lg font-semibold mb-4">Tổng kết thanh toán</h3>
                                <div className="space-y-3">
                                    <div className="flex justify-between">
                                        <span className="text-gray-600">Tạm tính:</span>
                                        <span>{invoice.subtotal.toLocaleString('vi-VN')}đ</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-gray-600">Giảm giá (10%):</span>
                                        <span className="text-red-600">-{invoice.discount.toLocaleString('vi-VN')}đ</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-gray-600">VAT (8%):</span>
                                        <span>{invoice.vat.toLocaleString('vi-VN')}đ</span>
                                    </div>
                                    <div className="pt-3 border-t">
                                        <div className="flex justify-between text-lg font-semibold">
                                            <span>Tổng cộng:</span>
                                            <span>{invoice.total.toLocaleString('vi-VN')}đ</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* Payment Method */}
                            <div id="payment-method" className="bg-white rounded-lg shadow p-6">
                                <h3 className="text-lg font-semibold mb-4">Phương thức thanh toán</h3>
                                <div className="flex items-center p-4 border rounded-lg">
                                    <i className="fa-solid fa-money-bill-wave text-green-600 text-xl mr-3"></i>
                                    <div>
                                        <div className="font-medium">{invoice.payment.method}</div>
                                        <div className="text-sm text-gray-500">Đã thanh toán: {invoice.payment.paidAt}</div>
                                    </div>
                                </div>
                            </div>
                            {/* Additional Notes */}
                            <div id="invoice-notes" className="bg-white rounded-lg shadow p-6">
                                <h3 className="text-lg font-semibold mb-4">Ghi chú</h3>
                                <p className="text-gray-600">{invoice.notes}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default InvoiceDetailsPageAdmin;
