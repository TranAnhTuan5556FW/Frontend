import React, { useState } from "react";
import { FaXmark, FaCheck, FaMagnifyingGlass, FaPlus, FaTrash } from "react-icons/fa6";

const defaultServices = [
  {
    id: 1,
    name: "Massage thư giãn toàn thân",
    duration: "60 phút",
    price: 500000,
    img: "https://source.unsplash.com/random/200x200/?massage",
  },
  {
    id: 2,
    name: "Đắp mặt nạ dưỡng da",
    duration: "30 phút",
    price: 300000,
    img: "https://source.unsplash.com/random/200x200/?spa",
  },
];

interface NewInvoiceFormProps {
  onCancel?: () => void;
}

const NewInvoiceForm: React.FC<NewInvoiceFormProps> = ({ onCancel }) => {
  const [customerSearch, setCustomerSearch] = useState("");
  const [customerType, setCustomerType] = useState("Khách thường");
  const [services, setServices] = useState(defaultServices);
  const [note, setNote] = useState("");
  const [discount, setDiscount] = useState(10);
  const [payment, setPayment] = useState("cash");

  const subtotal = services.reduce((sum, s) => sum + s.price, 0);
  const discountAmount = Math.round((subtotal * discount) / 100);
  const total = subtotal - discountAmount;

  const handleRemoveService = (id: number) => {
    setServices(services.filter((s) => s.id !== id));
  };

  return (
    <div className="flex-1">
      {/* Top Header */}
      <header id="header" className="bg-white shadow-sm">
        <div className="flex items-center justify-between px-6 py-4">
          <h2 className="text-xl font-bold">Tạo hóa đơn mới</h2>
          <div className="flex items-center space-x-4">
            <button
              className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              type="button"
              onClick={onCancel}
            >
              <FaXmark className="mr-2" />
              Hủy
            </button>
            <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              <FaCheck className="mr-2" />
              Lưu hóa đơn
            </button>
          </div>
        </div>
      </header>

      {/* New Invoice Form */}
      <div id="new-invoice-form" className="p-6">
        <div className="grid grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="col-span-2 space-y-6">
            {/* Customer Information */}
            <div id="customer-info" className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold mb-4">Thông tin khách hàng</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Tìm khách hàng</label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Tìm theo tên hoặc số điện thoại"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      value={customerSearch}
                      onChange={(e) => setCustomerSearch(e.target.value)}
                    />
                    <FaMagnifyingGlass className="absolute right-3 top-3 text-gray-400" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Loại khách hàng</label>
                  <select
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    value={customerType}
                    onChange={(e) => setCustomerType(e.target.value)}
                  >
                    <option>Khách thường</option>
                    <option>Khách VIP</option>
                    <option>Khách theo liệu trình</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Services Selection */}
            <div id="services-selection" className="bg-white rounded-lg shadow p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Dịch vụ đã chọn</h3>
                <button className="text-blue-600 hover:text-blue-800 flex items-center">
                  <FaPlus className="mr-1" />
                  Thêm dịch vụ
                </button>
              </div>
              <div className="space-y-3">
                {services.map((service) => (
                  <div
                    key={service.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center space-x-4">
                      <img
                        className="w-16 h-16 rounded-lg object-cover"
                        src={service.img}
                        alt="Service"
                      />
                      <div>
                        <div className="font-medium">{service.name}</div>
                        <div className="text-sm text-gray-500">{service.duration}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="font-medium">{service.price.toLocaleString()}đ</div>
                      <button
                        className="text-red-500 hover:text-red-700"
                        onClick={() => handleRemoveService(service.id)}
                        type="button"
                      >
                        <FaTrash />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Additional Notes */}
            <div id="additional-notes" className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold mb-4">Ghi chú thêm</h3>
              <textarea
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                rows={4}
                placeholder="Nhập ghi chú về yêu cầu đặc biệt của khách hàng..."
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Invoice Summary */}
            <div id="invoice-summary" className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold mb-4">Tổng hợp hóa đơn</h3>
              <div className="space-y-3">
                <div className="flex justify-between text-gray-600">
                  <span>Tạm tính:</span>
                  <span>{subtotal.toLocaleString()}đ</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Giảm giá:</span>
                  <div className="flex items-center">
                    <input
                      type="number"
                      className="w-16 px-2 py-1 border border-gray-300 rounded-lg text-right"
                      value={discount}
                      min={0}
                      max={100}
                      onChange={(e) => setDiscount(Number(e.target.value))}
                    />
                    <span className="ml-1">%</span>
                  </div>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Tiền giảm:</span>
                  <span className="text-red-600">-{discountAmount.toLocaleString()}đ</span>
                </div>
                <div className="pt-3 border-t">
                  <div className="flex justify-between text-lg font-semibold">
                    <span>Tổng cộng:</span>
                    <span className="text-blue-600">{total.toLocaleString()}đ</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Payment Method */}
            <div id="payment-method" className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold mb-4">Phương thức thanh toán</h3>
              <div className="space-y-3">
                <label className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <input
                    type="radio"
                    name="payment"
                    className="mr-3"
                    checked={payment === "cash"}
                    onChange={() => setPayment("cash")}
                  />
                  <div>
                    <div className="font-medium">Tiền mặt</div>
                    <div className="text-sm text-gray-500">Thanh toán trực tiếp</div>
                  </div>
                </label>
                <label className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <input
                    type="radio"
                    name="payment"
                    className="mr-3"
                    checked={payment === "bank"}
                    onChange={() => setPayment("bank")}
                  />
                  <div>
                    <div className="font-medium">Chuyển khoản</div>
                    <div className="text-sm text-gray-500">Internet Banking, MoMo</div>
                  </div>
                </label>
                <label className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <input
                    type="radio"
                    name="payment"
                    className="mr-3"
                    checked={payment === "credit"}
                    onChange={() => setPayment("credit")}
                  />
                  <div>
                    <div className="font-medium">Thẻ tín dụng</div>
                    <div className="text-sm text-gray-500">Visa, Mastercard, JCB</div>
                  </div>
                </label>
              </div>
            </div>

            {/* Confirm Buttons */}
            <div id="confirm-buttons" className="space-y-3">
              <button className="w-full px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700">
                Thanh toán ngay
              </button>
              <button className="w-full px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50">
                Lưu nháp
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewInvoiceForm;
