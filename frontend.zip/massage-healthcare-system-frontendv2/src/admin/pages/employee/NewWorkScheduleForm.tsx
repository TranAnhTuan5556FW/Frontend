import React, { useState, useEffect, ChangeEvent, FormEvent } from "react";
import '@fortawesome/fontawesome-free/css/all.min.css';

interface Staff {
  id: string;
  name: string;
  role: string;
  avatar: string;
}

interface WorkScheduleFormData {
  shiftName: string;
  shiftType: string;
  startTime: string;
  endTime: string;
  days: string[];
  staff: Staff[];
  notes: string;
}

interface Errors {
  shiftName?: string;
  startTime?: string;
  endTime?: string;
  days?: string;
}

interface WorkScheduleFormProps {
  onCancel: () => void;
  onSubmit: (data: WorkScheduleFormData) => void;
  initialData?: Partial<WorkScheduleFormData>;
  staffOptions?: Staff[]; // Optional: list of all staff to choose from
}

const defaultStaffOptions: Staff[] = [
  {
    id: '1',
    name: 'Nguyễn Văn A',
    role: 'Massage viên',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
  },
  {
    id: '2',
    name: 'Trần Thị B',
    role: 'Massage viên',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-5.jpg',
  },
  {
    id: '3',
    name: 'Lê Văn C',
    role: 'Lễ tân',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-6.jpg',
  },
];

const dayOptions = [
  { value: 'T2', label: 'T2' },
  { value: 'T3', label: 'T3' },
  { value: 'T4', label: 'T4' },
  { value: 'T5', label: 'T5' },
  { value: 'T6', label: 'T6' },
  { value: 'T7', label: 'T7' },
  { value: 'CN', label: 'CN' },
];

const initialState: WorkScheduleFormData = {
  shiftName: '',
  shiftType: 'Ca cố định',
  startTime: '',
  endTime: '',
  days: [],
  staff: [],
  notes: '',
};

const WorkScheduleForm: React.FC<WorkScheduleFormProps> = ({ onCancel, onSubmit, initialData, staffOptions }) => {
  const [form, setForm] = useState<WorkScheduleFormData>(initialData ? { ...initialState, ...initialData } : initialState);
  const [errors, setErrors] = useState<Errors>({});
  const [selectedStaffId, setSelectedStaffId] = useState('');
  const staffList = staffOptions || defaultStaffOptions;

  useEffect(() => {
    if (initialData) {
      setForm({ ...initialState, ...initialData });
    } else {
      setForm(initialState);
    }
  }, [initialData]);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (name === 'days' && type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setForm((prev) => ({
        ...prev,
        days: checked
          ? [...prev.days, value]
          : prev.days.filter((d) => d !== value),
      }));
    } else {
      setForm((prev) => ({ ...prev, [name]: value }));
    }
  };

  const validate = () => {
    const newErrors: Errors = {};
    if (!form.shiftName.trim()) newErrors.shiftName = 'Vui lòng nhập tên ca';
    if (!form.startTime) newErrors.startTime = 'Chọn thời gian bắt đầu';
    if (!form.endTime) newErrors.endTime = 'Chọn thời gian kết thúc';
    if (!form.days.length) newErrors.days = 'Chọn ít nhất một ngày';
    return newErrors;
  };

  const handleSubmit = (e?: FormEvent) => {
    if (e) e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;
    onSubmit(form);
  };

  // Staff assignment logic
  const handleAddStaff = () => {
    if (!selectedStaffId) return;
    const staffToAdd = staffList.find((s) => s.id === selectedStaffId);
    if (staffToAdd && !form.staff.some((s) => s.id === staffToAdd.id)) {
      setForm((prev) => ({ ...prev, staff: [...prev.staff, staffToAdd] }));
    }
    setSelectedStaffId('');
  };
  const handleRemoveStaff = (id: string) => {
    setForm((prev) => ({ ...prev, staff: prev.staff.filter((s) => s.id !== id) }));
  };

  return (
    <div className="max-w-4xl w-full mx-auto bg-white rounded-lg shadow-lg mb-8">
      {/* Top Header */}
      <header id="header" className="bg-white shadow-sm rounded-t-lg">
        <div className="flex items-center justify-between px-6 py-4">
          <h2 className="text-xl font-bold">Tạo ca làm việc mới</h2>
          <button
            type="button"
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
            onClick={onCancel}
          >
            <i className="fa-solid fa-xmark mr-2"></i>
            Đóng
          </button>
        </div>
      </header>
      <div className="p-6">
        <form className="p-6" onSubmit={handleSubmit}>
          {/* Basic Info Section */}
          <div id="basic-info" className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Thông tin cơ bản</h3>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tên ca</label>
                <input
                  type="text"
                  name="shiftName"
                  value={form.shiftName}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${errors.shiftName ? 'border-red-500' : 'border-gray-300'}`}
                  placeholder="Ví dụ: Ca sáng A"
                />
                {errors.shiftName && <p className="text-red-500 text-xs mt-1">{errors.shiftName}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Loại ca</label>
                <select
                  name="shiftType"
                  value={form.shiftType}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option>Ca cố định</option>
                  <option>Ca linh động</option>
                  <option>Ca tăng ca</option>
                </select>
              </div>
            </div>
          </div>

          {/* Time Settings */}
          <div id="time-settings" className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Thời gian làm việc</h3>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Thời gian bắt đầu</label>
                <input
                  type="time"
                  name="startTime"
                  value={form.startTime}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${errors.startTime ? 'border-red-500' : 'border-gray-300'}`}
                />
                {errors.startTime && <p className="text-red-500 text-xs mt-1">{errors.startTime}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Thời gian kết thúc</label>
                <input
                  type="time"
                  name="endTime"
                  value={form.endTime}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${errors.endTime ? 'border-red-500' : 'border-gray-300'}`}
                />
                {errors.endTime && <p className="text-red-500 text-xs mt-1">{errors.endTime}</p>}
              </div>
              <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Ngày làm việc</label>
                <div className="flex space-x-4">
                  {dayOptions.map((day) => (
                    <label key={day.value} className="flex items-center">
                      <input
                        type="checkbox"
                        name="days"
                        value={day.value}
                        checked={form.days.includes(day.value)}
                        onChange={handleChange}
                        className="form-checkbox h-5 w-5 text-blue-600"
                      />
                      <span className="ml-2">{day.label}</span>
                    </label>
                  ))}
                </div>
                {errors.days && <p className="text-red-500 text-xs mt-1">{errors.days}</p>}
              </div>
            </div>
          </div>

          {/* Staff Assignment */}
          <div id="staff-assignment" className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Phân công nhân viên</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Chọn nhân viên</label>
                <div className="flex space-x-2">
                  <select
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    value={selectedStaffId}
                    onChange={e => setSelectedStaffId(e.target.value)}
                  >
                    <option value="">Chọn nhân viên...</option>
                    {staffList.map((staff) => (
                      <option key={staff.id} value={staff.id} disabled={form.staff.some(s => s.id === staff.id)}>
                        {staff.name} - {staff.role}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    onClick={handleAddStaff}
                  >
                    <i className="fa-solid fa-plus"></i>
                  </button>
                </div>
              </div>
              {/* Assigned Staff List */}
              <div id="assigned-staff" className="mt-4">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Nhân viên đã chọn</h4>
                <div className="space-y-2">
                  {form.staff.map((staff) => (
                    <div key={staff.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <img src={staff.avatar} className="w-8 h-8 rounded-full" alt={staff.name} />
                        <span className="ml-3">{staff.name}</span>
                        <span className="ml-2 px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded">{staff.role}</span>
                      </div>
                      <button
                        type="button"
                        className="text-red-500 hover:text-red-700"
                        onClick={() => handleRemoveStaff(staff.id)}
                      >
                        <i className="fa-solid fa-trash"></i>
                      </button>
                    </div>
                  ))}
                  {form.staff.length === 0 && <div className="text-gray-400 text-sm">Chưa có nhân viên nào được chọn</div>}
                </div>
              </div>
            </div>
          </div>

          {/* Additional Notes */}
          <div id="additional-notes" className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Ghi chú bổ sung</h3>
            <textarea
              name="notes"
              value={form.notes}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              rows={4}
              placeholder="Nhập ghi chú về ca làm việc này..."
            ></textarea>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-4 pt-6 border-t">
            <button
              type="button"
              onClick={onCancel}
              className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center"
            >
              <i className="fa-solid fa-check mr-2"></i>
              Lưu ca
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default WorkScheduleForm;
