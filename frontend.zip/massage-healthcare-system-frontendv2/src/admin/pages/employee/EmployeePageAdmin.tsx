import React, { useState, useMemo } from 'react';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import { employeeData as initialEmployeeData, Employee } from '../../../data/employeeData';
import NewEmployeeForm from './NewEmployeeForm';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';

const ROLE_OPTIONS = ['Massage Therapist', 'Quản lý', 'Lễ tân'];
const STATUS_OPTIONS = ['Đang làm việc', 'Nghỉ phép', 'Đã nghỉ việc'];
const itemsPerPage = 3;

const skillColor = (skill: string) => {
  switch (skill) {
    case 'Swedish': return 'bg-blue-100 text-blue-700';
    case 'Thai': return 'bg-green-100 text-green-700';
    case 'Shiatsu': return 'bg-yellow-100 text-yellow-700';
    case 'Đào tạo': return 'bg-purple-100 text-purple-700';
    case 'Quản lý': return 'bg-purple-100 text-purple-700';
    case 'CSKH': return 'bg-orange-100 text-orange-700';
    case 'Đặt lịch': return 'bg-pink-100 text-pink-700';
    default: return 'bg-gray-100 text-gray-700';
  }
};
const statusColor = (status: string) => {
  switch (status) {
    case 'Đang làm việc': return 'bg-green-100 text-green-700';
    case 'Nghỉ phép': return 'bg-yellow-100 text-yellow-700';
    case 'Đã nghỉ việc': return 'bg-gray-100 text-gray-700';
    default: return 'bg-gray-100 text-gray-700';
  }
};

const EmployeePageAdmin: React.FC = () => {
  const [employees, setEmployees] = useState<Employee[]>(initialEmployeeData);
  const [searchText, setSearchText] = useState('');
  const [roleFilter, setRoleFilter] = useState('Tất cả chức vụ');
  const [statusFilter, setStatusFilter] = useState('Trạng thái');
  const [currentPage, setCurrentPage] = useState(1);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editEmployee, setEditEmployee] = useState<Employee | null>(null);
  const navigate = useNavigate();

  // User info for header
  const [user] = useState({
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    role: 'admin',
  });
  const handleLogout = () => {
    // TODO: Implement logout logic
    console.log('Logging out...');
  };

  // Filter and search
  const filteredEmployees = useMemo(() => {
    let result = employees.filter((e) => {
      const matchText = (e.name + e.position).toLowerCase().includes(searchText.toLowerCase());
      const matchRole = roleFilter === 'Tất cả chức vụ' || e.position === roleFilter;
      const matchStatus = statusFilter === 'Trạng thái' || e.status === statusFilter;
      return matchText && matchRole && matchStatus;
    });
    return result;
  }, [employees, searchText, roleFilter, statusFilter]);

  // Pagination
  const paginatedEmployees = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredEmployees.slice(start, start + itemsPerPage);
  }, [filteredEmployees, currentPage]);

  // Actions
  const handleAddEmployee = () => {
    setEditEmployee(null);
    setShowAddForm(true);
  };
  const handleEditEmployee = (employee: Employee) => {
    // Chuyển birthDate (dd/MM/yyyy) sang dob (yyyy-MM-dd) cho form
    let dob = '';
    if (employee.birthDate) {
      const [day, month, year] = employee.birthDate.split('/');
      dob = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
    }
    setEditEmployee({ ...employee, dob } as Employee);
    setShowAddForm(true);
  };
  const handleSubmitNewEmployee = (data: any) => {
    if (editEmployee) {
      setEmployees(prev => prev.map(e => e.id === editEmployee.id ? { ...e, ...data } : e));
      toast.success(`Cập nhật nhân viên: ${data.name} thành công!`);
    } else {
      const newId = employees.length > 0 ? Math.max(...employees.map(e => e.id)) + 1 : 1;
      setEmployees(prev => [
        {
          ...data,
          id: newId,
          avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg',
          status: 'Đang làm việc',
          position: data.role,
          skills: data.skills || [],
          schedule: [],
          stats: { hours: '0h', customers: 0, rating: '0/5' },
        },
        ...prev
      ]);
      toast.success(`Thêm mới nhân viên: ${data.name} thành công!`);
    }
    setShowAddForm(false);
    setEditEmployee(null);
  };
  const handleDeleteEmployee = (id: number) => {
    if (window.confirm('Bạn có chắc chắn muốn xóa nhân viên này?')) {
      const deleted = employees.find(e => e.id === id);
      setEmployees((prev) => prev.filter((e) => e.id !== id));
      toast.success(`Đã xóa nhân viên: ${deleted?.name || ''} (ID: ${id})`);
    }
  };
  const handleViewSchedule = (employee: Employee) => {
    // TODO: Hiển thị modal hoặc chuyển trang xem lịch làm việc
    toast.info(`Xem lịch làm việc của ${employee.name}`);
  };

  const handleManageSchedules = () => {
    navigate('/admin/schedules');  // Navigate to schedule management page
  };

  // Table columns
  return (
    <div className="min-h-screen bg-gray-50">
      <HeaderAdmin user={user} handleLogout={handleLogout} />
      <SideBarAdmin />
      <ToastContainer position="top-right" autoClose={2000} />
      <main className="ml-64 pt-16">
        {showAddForm ? (
          <NewEmployeeForm
            onCancel={() => { setShowAddForm(false); setEditEmployee(null); }}
            onSubmit={handleSubmitNewEmployee}
            initialData={
              editEmployee
                ? {
                    name: editEmployee.name,
                    email: '',
                    phone: editEmployee.phone,
                    gender: 'Nam',
                    dob: (editEmployee as any).dob || '',
                    role: editEmployee.position,
                    startDate: '',
                    skills: editEmployee.skills,
                    idCard: '',
                    address: editEmployee.address,
                    note: ''
                  }
                : undefined
            }
          />
        ) : (
          <>
            {/* Top Header */}
            <header id="header" className="bg-white shadow-sm">
              <div className="flex items-center justify-between px-6 py-4">
                <h2 className="text-xl font-bold">Quản lý Nhân viên</h2>
                <div className="flex items-center space-x-4">
                  <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700" onClick={handleAddEmployee}>
                    <i className="fa-solid fa-plus mr-2"></i>
                    Thêm nhân viên
                  </button>
                  <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700" onClick={handleManageSchedules}>
                    <i className="fa-solid fa-calendar-days mr-2"></i>
                    Quản lý lịch làm việc
                  </button>
                  <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    <i className="fa-solid fa-file-export mr-2"></i>
                    Xuất danh sách
                  </button>
                </div>
              </div>
            </header>
            {/* Search and Filters */}
            <div className="p-6">
              <div className="grid grid-cols-4 gap-4">
                <div className="col-span-2">
                  <div className="relative">
                    <i className="fa-solid fa-search absolute left-3 top-3 text-gray-400"></i>
                    <input
                      type="text"
                      placeholder="Tìm kiếm theo tên, chức vụ..."
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      value={searchText}
                      onChange={e => { setSearchText(e.target.value); setCurrentPage(1); }}
                    />
                  </div>
                </div>
                <div>
                  <select
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    value={roleFilter}
                    onChange={e => { setRoleFilter(e.target.value); setCurrentPage(1); }}
                  >
                    <option>Tất cả chức vụ</option>
                    {ROLE_OPTIONS.map(role => <option key={role}>{role}</option>)}
                  </select>
                </div>
                <div>
                  <select
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    value={statusFilter}
                    onChange={e => { setStatusFilter(e.target.value); setCurrentPage(1); }}
                  >
                    <option>Trạng thái</option>
                    {STATUS_OPTIONS.map(status => <option key={status}>{status}</option>)}
                  </select>
                </div>
              </div>
            </div>
            {/* Staff Table */}
            <div className="px-6">
              <div className="bg-white rounded-lg shadow">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="px-6 py-4">Nhân viên</th>
                      <th className="px-6 py-4">Chức vụ</th>
                      <th className="px-6 py-4">Kỹ năng</th>
                      <th className="px-6 py-4">Trạng thái</th>
                      <th className="px-6 py-4">Lịch làm việc</th>
                      <th className="px-6 py-4">Hành động</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedEmployees.map((employee) => (
                      <tr key={employee.id} className="border-b hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => navigate(`/admin/employees/${employee.id}`)}>
                            <img src={employee.avatar} className="w-10 h-10 rounded-full" alt={employee.name} />
                            <div>
                              <div className="font-medium">{employee.name}</div>
                              <div className="text-sm text-gray-500">ID: #NV{String(employee.id).padStart(3, '0')}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">{employee.position}</td>
                        <td className="px-6 py-4">
                          <div className="flex flex-wrap gap-2">
                            {employee.skills.map((skill) => (
                              <span key={skill} className={`px-2 py-1 rounded-full text-sm ${skillColor(skill)}`}>{skill}</span>
                            ))}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full ${statusColor(employee.status)}`}>{employee.status}</span>
                        </td>
                        <td className="px-6 py-4">
                          <button className="px-3 py-1 border border-blue-500 text-blue-500 rounded hover:bg-blue-50" onClick={() => handleViewSchedule(employee)}>
                            Xem lịch
                          </button>
                        </td>
                        <td className="px-6 py-4">
                          <button className="text-blue-600 hover:text-blue-800 mr-3" onClick={() => navigate(`/admin/employees/${employee.id}`)}>
                            <i className="fa-solid fa-eye"></i>
                          </button>
                          <button className="text-gray-600 hover:text-gray-800 mr-3" onClick={() => handleEditEmployee(employee)}>
                            <i className="fa-solid fa-pen"></i>
                          </button>
                          <button className="text-red-600 hover:text-red-800" onClick={() => handleDeleteEmployee(employee.id)}>
                            <i className="fa-solid fa-trash"></i>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {/* Pagination */}
                <div className="px-6 py-4 flex items-center justify-between border-t">
                  <div className="text-gray-600">
                    Hiển thị {filteredEmployees.length === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1}
                    -{Math.min(currentPage * itemsPerPage, filteredEmployees.length)} trong tổng số {filteredEmployees.length} nhân viên
                  </div>
                  <div className="flex space-x-2">
                    <button
                      className="px-3 py-1 border rounded hover:bg-gray-50"
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                    >
                      <i className="fa-solid fa-chevron-left"></i>
                    </button>
                    {Array.from({ length: Math.ceil(filteredEmployees.length / itemsPerPage) }, (_, i) => (
                      <button
                        key={i + 1}
                        className={`px-3 py-1 rounded ${currentPage === i + 1 ? 'bg-blue-600 text-white' : 'border hover:bg-gray-50'}`}
                        onClick={() => setCurrentPage(i + 1)}
                      >
                        {i + 1}
                      </button>
                    ))}
                    <button
                      className="px-3 py-1 border rounded hover:bg-gray-50"
                      disabled={currentPage === Math.ceil(filteredEmployees.length / itemsPerPage) || filteredEmployees.length === 0}
                      onClick={() => setCurrentPage((p) => Math.min(Math.ceil(filteredEmployees.length / itemsPerPage), p + 1))}
                    >
                      <i className="fa-solid fa-chevron-right"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default EmployeePageAdmin;
