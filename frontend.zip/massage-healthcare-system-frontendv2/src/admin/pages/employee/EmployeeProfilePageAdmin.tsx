import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import { employeeData } from '../../../data/employeeData';

const EmployeeProfilePageAdmin: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const emp = employeeData.find(e => e.id === Number(id));

  const handleBack = () => {
    navigate('/admin/employees');
  };

  if (!emp) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="bg-white p-8 rounded shadow text-center">
          <h2 className="text-xl font-bold mb-4">Không tìm thấy nhân viên</h2>
          <button 
            type="button"
            className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
            onClick={handleBack}
          >
            <i className="fa-solid fa-arrow-left mr-2"></i>
            Quay lại
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-100">
      <SideBarAdmin />
      <HeaderAdmin />
      <div className="flex-1">
        <header
          id="header"
          className="bg-white shadow-sm fixed w-full z-40"
          style={{ top: 64, left: 256 }}
        >
          <div className="flex items-center justify-between px-6 py-4 w-full max-w-[calc(100%-256px)]">
            <div className="flex items-center space-x-2">
              <button 
                type="button"
                className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
                onClick={handleBack}
              >
                <i className="fa-solid fa-arrow-left mr-2"></i>
                Quay lại
              </button>
              <h2 className="text-xl font-bold">Hồ sơ nhân viên</h2>
            </div>
            <div className="flex items-center space-x-4">
              <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                <i className="fa-solid fa-print mr-2"></i>
                In hồ sơ
              </button>
              <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i className="fa-solid fa-pen mr-2"></i>
                Chỉnh sửa
              </button>
            </div>
          </div>
        </header>
        <main className="pt-32 px-6 pb-6 ml-64 mt-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Profile Info */}
            <div id="profile-info" className="col-span-1">
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex flex-col items-center">
                  <img src={emp.avatar} className="w-32 h-32 rounded-full mb-4" alt="avatar" />
                  <h3 className="text-xl font-bold">{emp.name}</h3>
                  <p className="text-gray-500">{emp.position}</p>
                  <div className="mt-4 flex space-x-2">
                    <span className={`px-3 py-1 rounded-full text-sm ${emp.status === 'Đang làm việc' ? 'bg-green-100 text-green-700' : emp.status === 'Nghỉ phép' ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-700'}`}>{emp.status}</span>
                  </div>
                </div>
                <div className="mt-6 space-y-4">
                  <div className="flex items-center space-x-3">
                    <i className="fa-solid fa-id-card w-6 text-gray-400"></i>
                    <span>ID: #{emp.id}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <i className="fa-solid fa-phone w-6 text-gray-400"></i>
                    <span>{emp.phone}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <i className="fa-solid fa-envelope w-6 text-gray-400"></i>
                    <span>{emp.email}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <i className="fa-solid fa-location-dot w-6 text-gray-400"></i>
                    <span>{emp.address}</span>
                  </div>
                </div>
              </div>
            </div>
            {/* Main Details */}
            <div id="main-details" className="col-span-2 space-y-6">
              {/* Skills and Experience */}
              <div className="bg-white rounded-lg shadow p-6">
                <h4 className="text-lg font-bold mb-4">Kỹ năng & Kinh nghiệm</h4>
                <div className="space-y-4">
                  <div>
                    <h5 className="font-medium mb-2">Chuyên môn</h5>
                    <div className="flex flex-wrap gap-2">
                      {emp.skills.map((skill, idx) => (
                        <span key={idx} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full">{skill}</span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h5 className="font-medium mb-2">Số năm kinh nghiệm</h5>
                    <div className="flex items-center space-x-2">
                      <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full">{emp.experience} năm</span>
                    </div>
                  </div>
                </div>
              </div>
              {/* Performance Stats */}
              <div id="performance-stats" className="bg-white rounded-lg shadow p-6">
                <h4 className="text-lg font-bold mb-4">Thống kê hiệu suất</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="text-sm text-gray-600">Số giờ làm việc (Tháng)</div>
                    <div className="text-2xl font-bold text-blue-600">{emp.stats.hours}</div>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg">
                    <div className="text-sm text-gray-600">Khách hàng phục vụ</div>
                    <div className="text-2xl font-bold text-green-600">{emp.stats.customers}</div>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-lg">
                    <div className="text-sm text-gray-600">Đánh giá trung bình</div>
                    <div className="text-2xl font-bold text-purple-600">{emp.stats.rating}</div>
                  </div>
                </div>
              </div>
              {/* Schedule */}
              <div id="schedule" className="bg-white rounded-lg shadow p-6">
                <h4 className="text-lg font-bold mb-4">Lịch làm việc tuần này</h4>
                <div className="grid grid-cols-7 gap-2">
                  {emp.schedule.map((sch, idx) => (
                    <div className="text-center" key={idx}>
                      <div className="text-sm text-gray-600 mb-2">{sch.day}</div>
                      {sch.shift === 'Nghỉ' ? (
                        <div className="px-2 py-3 bg-gray-100 text-gray-500 rounded-lg">
                          <div className="font-medium">Nghỉ</div>
                        </div>
                      ) : (
                        <div className="px-2 py-3 bg-blue-50 text-blue-700 rounded-lg">
                          <div className="font-medium">{sch.shift}</div>
                          <div className="text-sm">{sch.time}</div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default EmployeeProfilePageAdmin;
