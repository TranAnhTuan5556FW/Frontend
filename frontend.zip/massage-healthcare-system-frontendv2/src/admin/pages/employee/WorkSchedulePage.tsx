import React, { useState } from 'react';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import '@fortawesome/fontawesome-free/css/all.min.css';
import WorkScheduleForm from './NewWorkScheduleForm';
import { useNavigate } from 'react-router-dom';

// Helper to format date as 'DD/MM'
function formatDayMonth(date: Date) {
  return `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}`;
}
// Helper to format week range as 'DD - DD Tháng MM, YYYY'
function formatWeekRange(start: Date, end: Date) {
  return `${start.getDate()} - ${end.getDate()} Tháng ${start.getMonth() + 1}, ${start.getFullYear()}`;
}
// Helper to get start of week (Monday)
function getStartOfWeek(date: Date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - ((day + 6) % 7); // Monday as first day
  return new Date(d.setDate(diff));
}

const WorkSchedulePage: React.FC = () => {
  // User info for header
  const [user] = useState({
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    role: 'admin',
  });
  const handleLogout = () => {
    // TODO: Implement logout logic
    console.log('Logging out...');
  };

  const navigate = useNavigate();

  // Week navigation state
  const [currentWeekStart, setCurrentWeekStart] = useState(() => getStartOfWeek(new Date()));
  const currentWeekEnd = new Date(currentWeekStart);
  currentWeekEnd.setDate(currentWeekStart.getDate() + 6);

  // Handlers for week navigation
  const handlePrevWeek = () => {
    const prev = new Date(currentWeekStart);
    prev.setDate(prev.getDate() - 7);
    setCurrentWeekStart(getStartOfWeek(prev));
  };
  const handleNextWeek = () => {
    const next = new Date(currentWeekStart);
    next.setDate(next.getDate() + 7);
    setCurrentWeekStart(getStartOfWeek(next));
  };

  // Generate days for the week
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(currentWeekStart);
    d.setDate(currentWeekStart.getDate() + i);
    return d;
  });

  // Show/Hide WorkScheduleForm
  const [showForm, setShowForm] = useState(false);

  // Handle form submit
  const handleCreateShift = (_data: any) => {
    setShowForm(false);
    alert('Tạo ca làm việc thành công!'); // Có thể thay bằng toast nếu muốn
    // TODO: Lưu ca vào state hoặc gửi API
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <HeaderAdmin user={user} handleLogout={handleLogout} />
      <SideBarAdmin />
      <main className="ml-64 pt-16">
        {showForm ? (
          <WorkScheduleForm
            onCancel={() => setShowForm(false)}
            onSubmit={handleCreateShift}
          />
        ) : (
        <div className="flex flex-1 flex-col">
          {/* Top Header */}
          <header id="header" className="bg-white shadow-sm">
            <div className="flex items-center justify-between px-6 py-4">
              <div className="flex items-center">
                <button 
                  type="button"
                  onClick={() => navigate('/admin/employees')}
                  className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg mr-4"
                >
                  <i className="fa-solid fa-arrow-left mr-2"></i>
                  Quay lại
                </button>
                <h2 className="text-xl font-bold">Quản lý Lịch làm việc</h2>
              </div>
              <div className="flex items-center space-x-4">
                <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700" onClick={() => setShowForm(true)}>
                  <i className="fa-solid fa-plus mr-2"></i>
                  Tạo ca mới
                </button>
                <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  <i className="fa-solid fa-file-export mr-2"></i>
                  Xuất lịch
                </button>
              </div>
            </div>
          </header>

          {/* Calendar Navigation */}
          <div id="calendar-nav" className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-4">
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg">Tuần</button>
                <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">Tháng</button>
                <div className="flex items-center space-x-2">
                  <button className="p-2 border rounded-lg hover:bg-gray-50" onClick={handlePrevWeek}>
                    <i className="fa-solid fa-chevron-left"></i>
                  </button>
                  <span className="font-medium">{formatWeekRange(currentWeekStart, currentWeekEnd)}</span>
                  <button className="p-2 border rounded-lg hover:bg-gray-50" onClick={handleNextWeek}>
                    <i className="fa-solid fa-chevron-right"></i>
                  </button>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  <i className="fa-solid fa-filter mr-2"></i>
                  Lọc
                </button>
                <select className="px-4 py-2 border border-gray-300 rounded-lg">
                  <option>Tất cả nhân viên</option>
                  <option>Massage viên</option>
                  <option>Lễ tân</option>
                </select>
              </div>
            </div>

            {/* Weekly Calendar */}
            <div id="weekly-calendar" className="bg-white rounded-lg shadow">
              {/* Time Column Headers */}
              <div className="grid grid-cols-8 border-b">
                <div className="p-4 font-medium text-gray-500">Giờ</div>
                {weekDays.map((d, idx) => (
                  <div key={idx} className="p-4 text-center font-medium">
                    <div>{['T2','T3','T4','T5','T6','T7','CN'][idx]}</div>
                    <div className="text-sm text-gray-500">{formatDayMonth(d)}</div>
                  </div>
                ))}
              </div>

              {/* Calendar Grid */}
              <div className="divide-y">
                {/* 8:00 AM Row */}
                <div className="grid grid-cols-8">
                  <div className="p-4 text-gray-500">8:00</div>
                  <div className="p-2 border-l">
                    <div className="bg-green-100 text-green-800 p-2 rounded">
                      <div className="font-medium">Ca sáng A</div>
                      <div className="text-sm">Nguyễn Văn A</div>
                    </div>
                  </div>
                  <div className="p-2 border-l">
                    <div className="bg-green-100 text-green-800 p-2 rounded">
                      <div className="font-medium">Ca sáng A</div>
                      <div className="text-sm">Nguyễn Văn A</div>
                    </div>
                  </div>
                  <div className="p-2 border-l"></div>
                  <div className="p-2 border-l">
                    <div className="bg-yellow-100 text-yellow-800 p-2 rounded">
                      <div className="font-medium">Nghỉ phép</div>
                      <div className="text-sm">Nguyễn Văn A</div>
                    </div>
                  </div>
                  <div className="p-2 border-l"></div>
                  <div className="p-2 border-l">
                    <div className="bg-green-100 text-green-800 p-2 rounded">
                      <div className="font-medium">Ca sáng A</div>
                      <div className="text-sm">Nguyễn Văn A</div>
                    </div>
                  </div>
                  <div className="p-2 border-l"></div>
                </div>

                {/* 12:00 PM Row */}
                <div className="grid grid-cols-8">
                  <div className="p-4 text-gray-500">12:00</div>
                  <div className="p-2 border-l">
                    <div className="bg-blue-100 text-blue-800 p-2 rounded">
                      <div className="font-medium">Ca chiều B</div>
                      <div className="text-sm">Trần Thị B</div>
                    </div>
                  </div>
                  <div className="p-2 border-l"></div>
                  <div className="p-2 border-l">
                    <div className="bg-blue-100 text-blue-800 p-2 rounded">
                      <div className="font-medium">Ca chiều B</div>
                      <div className="text-sm">Trần Thị B</div>
                    </div>
                  </div>
                  <div className="p-2 border-l"></div>
                  <div className="p-2 border-l">
                    <div className="bg-blue-100 text-blue-800 p-2 rounded">
                      <div className="font-medium">Ca chiều B</div>
                      <div className="text-sm">Trần Thị B</div>
                    </div>
                  </div>
                  <div className="p-2 border-l"></div>
                  <div className="p-2 border-l"></div>
                </div>

                {/* 16:00 PM Row */}
                <div className="grid grid-cols-8">
                  <div className="p-4 text-gray-500">16:00</div>
                  <div className="p-2 border-l"></div>
                  <div className="p-2 border-l">
                    <div className="bg-purple-100 text-purple-800 p-2 rounded">
                      <div className="font-medium">Ca tối C</div>
                      <div className="text-sm">Lê Văn C</div>
                    </div>
                  </div>
                  <div className="p-2 border-l"></div>
                  <div className="p-2 border-l">
                    <div className="bg-purple-100 text-purple-800 p-2 rounded">
                      <div className="font-medium">Ca tối C</div>
                      <div className="text-sm">Lê Văn C</div>
                    </div>
                  </div>
                  <div className="p-2 border-l"></div>
                  <div className="p-2 border-l">
                    <div className="bg-red-100 text-red-800 p-2 rounded">
                      <div className="font-medium">Tăng ca</div>
                      <div className="text-sm">Lê Văn C</div>
                    </div>
                  </div>
                  <div className="p-2 border-l"></div>
                </div>
              </div>
            </div>
          </div>

          {/* Staff Summary */}
          <div id="staff-summary" className="px-6 mb-6">
            <div className="grid grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-lg shadow">
                <div className="text-gray-500 mb-2">Tổng nhân viên làm việc</div>
                <div className="text-2xl font-bold">12/15</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow">
                <div className="text-gray-500 mb-2">Đang nghỉ phép</div>
                <div className="text-2xl font-bold">2</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow">
                <div className="text-gray-500 mb-2">Tăng ca</div>
                <div className="text-2xl font-bold">3</div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow">
                <div className="text-gray-500 mb-2">Tổng giờ làm</div>
                <div className="text-2xl font-bold">320h</div>
              </div>
            </div>
          </div>
        </div>
        )}
      </main>
    </div>
  );
};

export default WorkSchedulePage;
