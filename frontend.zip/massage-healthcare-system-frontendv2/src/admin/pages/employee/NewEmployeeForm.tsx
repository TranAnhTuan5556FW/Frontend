import React, { useState, useEffect, ChangeEvent, FormEvent } from 'react';

const SKILL_OPTIONS = ['Swedish', 'Thai', 'Shiatsu', 'Đào tạo'];
const ROLE_OPTIONS = ['Massage Therapist', 'Quản lý', 'Lễ tân'];

interface EmployeeForm {
  name: string;
  email: string;
  phone: string;
  gender: string;
  dob?: string;
  role: string;
  startDate: string;
  skills: string[];
  experienceYears: string;
  idCard: string;
  address: string;
  note: string;
  avatar: File | null;
}

interface Errors {
  name?: string;
  phone?: string;
  role?: string;
}

interface NewEmployeeFormProps {
  onCancel: () => void;
  onSubmit: (data: any) => void;
  initialData?: Partial<EmployeeForm>;
}

const initialState: EmployeeForm = {
  name: '',
  email: '',
  phone: '',
  gender: 'Nam',
  dob: '',
  role: '',
  startDate: '',
  skills: [],
  experienceYears: '',
  idCard: '',
  address: '',
  note: '',
  avatar: null,
};

const NewEmployeeForm: React.FC<NewEmployeeFormProps> = ({ onCancel, onSubmit, initialData }) => {
  const [form, setForm] = useState<EmployeeForm>(initialData ? { ...initialState, ...initialData } : initialState);
  const [errors, setErrors] = useState<Errors>({});

  useEffect(() => {
    if (initialData) {
      setForm({ ...initialState, ...initialData });
    } else {
      setForm(initialState);
    }
  }, [initialData]);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type, files } = e.target as HTMLInputElement;
    if (type === 'file') {
      setForm((prev) => ({ ...prev, [name]: files ? files[0] : null }));
    } else {
      setForm((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSkillChange = (skill: string) => {
    setForm((prev) => {
      const exists = prev.skills.includes(skill);
      return {
        ...prev,
        skills: exists ? prev.skills.filter((s) => s !== skill) : [...prev.skills, skill],
      };
    });
  };

  const validate = () => {
    const newErrors: Errors = {};
    if (!form.name.trim()) newErrors.name = 'Vui lòng nhập họ và tên';
    if (!form.phone.trim()) newErrors.phone = 'Vui lòng nhập số điện thoại';
    if (!form.role.trim()) newErrors.role = 'Vui lòng chọn chức vụ';
    return newErrors;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) {
      return;
    }
    if (onSubmit) {
      let birthDate = form.dob;
      if (form.dob && form.dob.includes('-')) {
        const [year, month, day] = form.dob.split('-');
        birthDate = `${day.padStart(2, '0')}/${month.padStart(2, '0')}/${year}`;
      }
      const submitData = { ...form, birthDate };
      delete submitData.dob;
      onSubmit(submitData);
    }
  };

  return (
    <div className="max-w-4xl w-full mx-auto bg-white rounded-lg shadow-lg mb-8">
      {/* Top Header */}
      <header id="header" className="bg-white shadow-sm rounded-t-lg">
        <div className="flex items-center justify-between px-6 py-4">
          <h2 className="text-xl font-bold">
            {initialData ? 'Chỉnh sửa thông tin nhân viên' : 'Thêm nhân viên mới'}
          </h2>
          <button
            type="button"
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
            onClick={onCancel}
          >
            <i className="fa-solid fa-xmark mr-2"></i>
            Đóng
          </button>
        </div>
      </header>
      <div className="p-6">
        <form className="space-y-6" onSubmit={handleSubmit}>
          {/* Basic Information */}
          <div id="basic-info" className="space-y-4">
            <h3 className="text-lg font-semibold">Thông tin cơ bản</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Họ và tên *</label>
                <input type="text" name="name" value={form.name} onChange={handleChange} className={`w-full px-4 py-2 border ${errors.name ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500`} />
                {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" name="email" value={form.email} onChange={handleChange} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Số điện thoại *</label>
                <input type="tel" name="phone" value={form.phone} onChange={handleChange} className={`w-full px-4 py-2 border ${errors.phone ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500`} />
                {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Giới tính</label>
                <select
                  name="gender"
                  value={form.gender}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="Nam">Nam</option>
                  <option value="Nữ">Nữ</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Ngày sinh</label>
                <input type="date" name="dob" value={form.dob} onChange={handleChange} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
              </div>
            </div>
          </div>
          {/* Work Information */}
          <div id="work-info" className="space-y-4">
            <h3 className="text-lg font-semibold">Thông tin công việc</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Chức vụ *</label>
                <select name="role" value={form.role} onChange={handleChange} className={`w-full px-4 py-2 border ${errors.role ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500`}>
                  <option value="">Chọn chức vụ</option>
                  {ROLE_OPTIONS.map((role) => (
                    <option key={role} value={role}>{role}</option>
                  ))}
                </select>
                {errors.role && <p className="text-red-500 text-xs mt-1">{errors.role}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Ngày bắt đầu</label>
                <input type="date" name="startDate" value={form.startDate} onChange={handleChange} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Kỹ năng</label>
              <div className="grid grid-cols-4 gap-3">
                {SKILL_OPTIONS.map((skill) => (
                  <label key={skill} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={form.skills.includes(skill)}
                      onChange={() => handleSkillChange(skill)}
                      className="rounded text-blue-600"
                    />
                    <span>{skill}</span>
                  </label>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Số năm kinh nghiệm</label>
              <input 
                type="number" 
                name="experienceYears" 
                value={form.experienceYears} 
                onChange={handleChange} 
                min="0"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
              />
            </div>
          </div>
          {/* Additional Information */}
          <div id="additional-info" className="space-y-4">
            <h3 className="text-lg font-semibold">Thông tin bổ sung</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">CMND/CCCD</label>
                <input type="text" name="idCard" value={form.idCard} onChange={handleChange} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Địa chỉ</label>
                <input type="text" name="address" value={form.address} onChange={handleChange} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Ghi chú</label>
              <textarea name="note" rows={3} value={form.note} onChange={handleChange} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"></textarea>
            </div>
          </div>
          {/* Upload Section */}
          <div id="upload-section" className="space-y-4">
            <h3 className="text-lg font-semibold">Tải lên tài liệu</h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Ảnh đại diện</label>
              <input type="file" name="avatar" accept="image/*" onChange={handleChange} className="w-full" />
            </div>
          </div>
          {/* Form Actions */}
          <div id="form-actions" className="flex justify-end space-x-3 pt-6 border-t">
            <button type="button" className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50" onClick={onCancel}>
              Hủy
            </button>
            <button type="submit" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
              <i className="fa-solid fa-check mr-2"></i>
              {initialData ? 'Cập nhật nhân viên' : 'Lưu nhân viên'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewEmployeeForm;
