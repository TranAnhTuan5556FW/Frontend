import { useState } from 'react';
import HeaderAdmin from '../components/HeaderAdmin';
import SideBarAdmin from '../components/SideBarAdmin';
import ReactApexChart from 'react-apexcharts';
import { ApexOptions } from 'apexcharts';

const AdminDashboard = () => {
  const [user] = useState({
    avatar: "https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg",
    role: "admin"
  });

  const handleLogout = () => {
    // TODO: Implement logout logic
    console.log("Logging out...");
  };

  // Revenue Chart Options
  const revenueOptions: ApexOptions = {
    chart: {
      type: 'line',
      height: 320,
      toolbar: {
        show: false
      }
    },
    stroke: {
      curve: 'smooth',
      width: 3
    },
    colors: ['#9333EA'],
    xaxis: {
      categories: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    },
    grid: {
      borderColor: '#f2f2f2'
    }
  };

  const revenueSeries = [{
    name: 'Revenue',
    data: [30, 40, 35, 50, 49, 60, 70]
  }];

  // Services Chart Options
  const servicesOptions: ApexOptions = {
    chart: {
      type: 'pie',
      height: 320
    },
    colors: ['#9333EA', '#3B82F6', '#EF4444', '#10B981'],
    labels: ['Swedish Massage', 'Deep Tissue', 'Hot Stone', 'Other'],
    legend: {
      position: 'bottom'
    }
  };

  const servicesSeries = [44, 55, 13, 43];

  return (
    <div className="min-h-screen bg-gray-50">
      <HeaderAdmin user={user} handleLogout={handleLogout} />
      <SideBarAdmin />

      <main className="ml-64 p-8 pt-24">
        {/* Time Filter */}
        <div id="time-filter" className="mb-8 flex items-center justify-between">
          <div className="flex space-x-2">
            <button className="px-4 py-2 bg-purple-600 text-white rounded-lg">Hôm nay</button>
            <button className="px-4 py-2 bg-white text-gray-600 rounded-lg">Hôm qua</button>
            <button className="px-4 py-2 bg-white text-gray-600 rounded-lg">Tuần này</button>
            <button className="px-4 py-2 bg-white text-gray-600 rounded-lg">Tháng này</button>
          </div>
          <div className="flex items-center space-x-2">
            <input type="date" className="px-4 py-2 border rounded-lg" />
            <span className="px-2">đến</span>
            <input type="date" className="px-4 py-2 border rounded-lg" />
          </div>
        </div>

        {/* KPI Cards */}
        <div id="kpi-cards" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-500">Khách hàng đang hoạt động</h3>
              <i className="fa-solid fa-users text-purple-500 text-xl"></i>
            </div>
            <p className="text-2xl font-bold">2,451</p>
            <p className="text-green-500 text-sm"><i className="fa-solid fa-arrow-up"></i> +15% so với tuần trước</p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-500">Lịch hẹn hôm nay</h3>
              <i className="fa-solid fa-calendar-check text-blue-500 text-xl"></i>
            </div>
            <p className="text-2xl font-bold">28</p>
            <p className="text-red-500 text-sm"><i className="fa-solid fa-arrow-down"></i> -3% so với hôm qua</p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-500">Doanh thu hôm nay</h3>
              <i className="fa-solid fa-dollar-sign text-green-500 text-xl"></i>
            </div>
            <p className="text-2xl font-bold">3,842,000đ</p>
            <p className="text-green-500 text-sm"><i className="fa-solid fa-arrow-up"></i> +8% so với hôm qua</p>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-500">Tỷ lệ hủy lịch</h3>
              <i className="fa-solid fa-ban text-red-500 text-xl"></i>
            </div>
            <p className="text-2xl font-bold">4.2%</p>
            <p className="text-green-500 text-sm"><i className="fa-solid fa-arrow-down"></i> -2% so với tuần trước</p>
          </div>
        </div>

        {/* Charts Section */}
        <div id="analytics-charts" className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <h3 className="text-lg font-semibold mb-4">Xu hướng doanh thu</h3>
            <ReactApexChart 
              options={revenueOptions}
              series={revenueSeries}
              type="line"
              height={320}
            />
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <h3 className="text-lg font-semibold mb-4">Phân bố dịch vụ</h3>
            <ReactApexChart 
              options={servicesOptions}
              series={servicesSeries}
              type="pie"
              height={320}
            />
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard; 