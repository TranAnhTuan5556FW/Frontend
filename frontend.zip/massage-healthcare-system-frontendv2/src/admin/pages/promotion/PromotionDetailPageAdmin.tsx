import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import { promotions } from '../../../data/promotionData';
import NewPromotionForm from './NewPromotionForm';
import '@fortawesome/fontawesome-free/css/all.min.css';

const PromotionDetailPageAdmin: React.FC = () => {
  const navigate = useNavigate();
  // For demo, always use the first promotion. In real app, get id from useParams and find by id.
  const { id } = useParams<{ id: string }>();
  const promotion = promotions.find(p => p.id === Number(id)) || promotions[0];

  const [user] = React.useState({
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    role: 'admin',
  });

  const [isEditing, setIsEditing] = React.useState(false);

  const handleLogout = () => {
    // TODO: Implement logout logic
    navigate('/');
  };

  const handleBack = () => {
    navigate('/admin/promotions');
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleDelete = () => {
    if (window.confirm('Bạn có chắc chắn muốn xóa khuyến mãi này?')) {
      // TODO: Implement delete logic
      alert('Đã xóa khuyến mãi (demo).');
      navigate('/admin/promotions');
    }
  };

  // Prepare initial form data for editing
  const getEditFormData = () => {
    return {
      name: promotion.name,
      code: promotion.code,
      type: promotion.type,
      value: promotion.value.replace(/[^\d]/g, ''),
      valueUnit: promotion.value.includes('%') ? '%' : 'VNĐ',
      startDate: promotion.startDate ? new Date(promotion.startDate.split('/').reverse().join('-')).toISOString().slice(0, 16) : '',
      endDate: promotion.endDate ? new Date(promotion.endDate.split('/').reverse().join('-')).toISOString().slice(0, 16) : '',
      maxCodes: promotion.usageLimit.toString(),
      maxPerCustomer: '', // Not available in mock data
      minOrderValue: '', // Not available in mock data
      services: [], // Not available in mock data
      customerTypes: [], // Not available in mock data
      description: promotion.description,
    };
  };

  const handleEditCancel = () => {
    setIsEditing(false);
  };

  const handleEditSubmit = (data: any) => {
    // TODO: Update promotion in backend or state
    alert('Đã lưu chỉnh sửa (demo): ' + JSON.stringify(data, null, 2));
    setIsEditing(false);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <HeaderAdmin user={user} handleLogout={handleLogout} />
      <SideBarAdmin />
      <main className="ml-64 pt-16">
        {isEditing ? (
          <NewPromotionForm
            onCancel={handleEditCancel}
            onSubmit={handleEditSubmit}
            initialData={getEditFormData()}
          />
        ) : (
          <>
            {/* Top Header */}
            <header id="header" className="bg-white shadow-sm">
              <div className="flex items-center justify-between px-6 py-4">
                <div className="flex items-center space-x-2">
                  <button 
                    type="button"
                    onClick={handleBack}
                    className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg mr-4"
                  >
                    <i className="fa-solid fa-arrow-left mr-2"></i>
                    Quay lại
                  </button>
                  <h2 className="text-xl font-bold">Chi tiết khuyến mãi</h2>
                </div>
                <div className="flex items-center space-x-4">
                  <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50" onClick={handleEdit}>
                    <i className="fa-solid fa-pen mr-2"></i>
                    Chỉnh sửa
                  </button>
                  <button className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700" onClick={handleDelete}>
                    <i className="fa-solid fa-trash mr-2"></i>
                    Xóa
                  </button>
                </div>
              </div>
            </header>

            <div className="p-6">
              {/* Promotion Info */}
              <div id="promotion-info" className="bg-white rounded-lg shadow mb-6">
                <div className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-2xl font-bold">{promotion.name}</h3>
                      <div className="text-gray-500 mt-1">Mã: {promotion.code}</div>
                    </div>
                    <span className={`px-4 py-2 rounded-full ${promotion.statusColor}`}>{promotion.status}</span>
                  </div>

                  <div className="grid grid-cols-3 gap-6 mt-6">
                    <div>
                      <div className="text-gray-500">Loại khuyến mãi</div>
                      <div className="mt-1 font-medium">{promotion.type}</div>
                    </div>
                    <div>
                      <div className="text-gray-500">Giá trị giảm</div>
                      <div className="mt-1 font-medium">{promotion.value}</div>
                    </div>
                    <div>
                      <div className="text-gray-500">Giới hạn sử dụng</div>
                      <div className="mt-1 font-medium">{promotion.usageLimit} lượt</div>
                    </div>
                    <div>
                      <div className="text-gray-500">Ngày bắt đầu</div>
                      <div className="mt-1 font-medium">{promotion.startDate}</div>
                    </div>
                    <div>
                      <div className="text-gray-500">Ngày kết thúc</div>
                      <div className="mt-1 font-medium">{promotion.endDate}</div>
                    </div>
                    <div>
                      <div className="text-gray-500">Đã sử dụng</div>
                      <div className="mt-1 font-medium">{promotion.used} lượt</div>
                    </div>
                  </div>

                  <div className="mt-6">
                    <div className="text-gray-500">Mô tả</div>
                    <div className="mt-1">{promotion.description}</div>
                  </div>

                  <div className="mt-6">
                    <div className="text-gray-500">Điều kiện áp dụng</div>
                    <ul className="mt-1 list-disc list-inside space-y-1">
                      {promotion.conditions.map((cond, idx) => (
                        <li key={idx}>{cond}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Usage Stats */}
              <div id="usage-stats" className="grid grid-cols-2 gap-6 mb-6">
                <div className="bg-white rounded-lg shadow p-6">
                  <h4 className="font-bold mb-4">Thống kê sử dụng</h4>
                  <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center text-gray-400">Biểu đồ lượt sử dụng (placeholder)</div>
                </div>
                <div className="bg-white rounded-lg shadow p-6">
                  <h4 className="font-bold mb-4">Doanh thu từ khuyến mãi</h4>
                  <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center text-gray-400">Biểu đồ doanh thu (placeholder)</div>
                </div>
              </div>

              {/* Usage History */}
              <div id="usage-history" className="bg-white rounded-lg shadow">
                <div className="p-6 border-b">
                  <h4 className="font-bold">Lịch sử sử dụng</h4>
                </div>
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="px-6 py-4">Khách hàng</th>
                      <th className="px-6 py-4">Dịch vụ</th>
                      <th className="px-6 py-4">Thời gian sử dụng</th>
                      <th className="px-6 py-4">Giá trị đơn hàng</th>
                      <th className="px-6 py-4">Giảm giá</th>
                      <th className="px-6 py-4">Thanh toán</th>
                    </tr>
                  </thead>
                  <tbody>
                    {promotion.usageHistory.map((item, idx) => (
                      <tr className="border-b hover:bg-gray-50" key={idx}>
                        <td className="px-6 py-4">
                          <div className="flex items-center">
                            <img src={item.customer.avatar} className="w-8 h-8 rounded-full mr-3" alt={item.customer.name} />
                            <div>
                              <div className="font-medium">{item.customer.name}</div>
                              <div className="text-sm text-gray-500">{item.customer.phone}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">{item.service}</td>
                        <td className="px-6 py-4">
                          <div>{item.date}</div>
                          <div className="text-sm text-gray-500">{item.time}</div>
                        </td>
                        <td className="px-6 py-4">{item.orderValue}</td>
                        <td className="px-6 py-4 text-red-600">{item.discount}</td>
                        <td className="px-6 py-4">{item.payment}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Pagination (static for demo) */}
                <div className="px-6 py-4 flex items-center justify-between border-t">
                  <div className="text-gray-600">
                    Hiển thị 1-{promotion.usageHistory.length} trong tổng số {promotion.used} lượt sử dụng
                  </div>
                  <div className="flex space-x-2">
                    <button className="px-3 py-1 border rounded hover:bg-gray-50">
                      <i className="fa-solid fa-chevron-left"></i>
                    </button>
                    <button className="px-3 py-1 bg-blue-600 text-white rounded">1</button>
                    <button className="px-3 py-1 border rounded hover:bg-gray-50">2</button>
                    <button className="px-3 py-1 border rounded hover:bg-gray-50">3</button>
                    <button className="px-3 py-1 border rounded hover:bg-gray-50">
                      <i className="fa-solid fa-chevron-right"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default PromotionDetailPageAdmin;
