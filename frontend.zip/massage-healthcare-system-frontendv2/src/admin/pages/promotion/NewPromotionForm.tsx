import React, { useState, useEffect } from 'react';
import { services as allServices } from '../../../data/individualServiceDataCustomer';

const PROMOTION_TYPES = ['Mã giảm giá', 'Voucher', 'Thẻ quà tặng'];
const VALUE_UNITS = ['VNĐ', '%'];
const CUSTOMER_TYPES = [
  { label: 'Khách hàng mới', value: 'new' },
  { label: 'Khách hàng VIP', value: 'vip' },
  { label: 'Tất cả khách hàng', value: 'all' },
];

interface PromotionForm {
  name: string;
  code: string;
  type: string;
  value: string;
  valueUnit: string;
  startDate: string;
  endDate: string;
  maxCodes: string;
  maxPerCustomer: string;
  minOrderValue: string;
  services: number[];
  customerTypes: string[];
  description: string;
}

interface NewPromotionFormProps {
  onCancel: () => void;
  onSubmit: (data: PromotionForm) => void;
  initialData?: PromotionForm;
}

const initialState: PromotionForm = {
  name: '',
  code: '',
  type: PROMOTION_TYPES[0],
  value: '',
  valueUnit: VALUE_UNITS[0],
  startDate: '',
  endDate: '',
  maxCodes: '',
  maxPerCustomer: '',
  minOrderValue: '',
  services: [],
  customerTypes: [],
  description: '',
};

const NewPromotionForm: React.FC<NewPromotionFormProps> = ({ onCancel, onSubmit, initialData }) => {
  const [form, setForm] = useState<PromotionForm>(initialData || initialState);

  useEffect(() => {
    if (initialData) {
      setForm(initialData);
    }
  }, [initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox' && name === 'customerTypes') {
      const input = e.target as HTMLInputElement;
      const checked = input.checked;
      setForm((prev) => {
        if (checked) {
          return { ...prev, customerTypes: [...prev.customerTypes, value] };
        } else {
          return { ...prev, customerTypes: prev.customerTypes.filter((v) => v !== value) };
        }
      });
    } else if (name === 'services') {
      // handled separately
    } else {
      setForm((prev) => ({ ...prev, [name]: value }));
    }
  };


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(form);
  };

  return (
    <div className="max-w-4xl w-full mx-auto bg-white rounded-lg shadow-lg mb-8">
      <header id="header" className="bg-white shadow-sm rounded-t-lg">
        <div className="flex items-center justify-between px-6 py-4">
          <h2 className="text-xl font-bold">{initialData ? 'Chỉnh sửa khuyến mãi' : 'Tạo khuyến mãi mới'}</h2>
          <button
            type="button"
            className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            onClick={onCancel}
          >
            <i className="fa-solid fa-xmark mr-2"></i>
            Đóng
          </button>
        </div>
      </header>
      <div className="p-6">
        <form className="space-y-6" id="new-promotion-form" onSubmit={handleSubmit}>
          <div className="bg-white rounded-lg shadow p-6">
            {/* Basic Information */}
            <div id="basic-info" className="mb-8">
              <h3 className="text-lg font-semibold mb-4">Thông tin cơ bản</h3>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Tên khuyến mãi</label>
                  <input type="text" name="name" value={form.name} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Nhập tên khuyến mãi" required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Mã khuyến mãi</label>
                  <input type="text" name="code" value={form.code} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Nhập mã khuyến mãi" required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Loại khuyến mãi</label>
                  <select name="type" value={form.type} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    {PROMOTION_TYPES.map((type) => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Giá trị</label>
                  <div className="flex">
                    <input type="number" name="value" value={form.value} onChange={handleChange} className="w-full px-4 py-2 border rounded-l-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Nhập giá trị" required />
                    <select name="valueUnit" value={form.valueUnit} onChange={handleChange} className="px-4 py-2 border-y border-r rounded-r-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                      {VALUE_UNITS.map((unit) => (
                        <option key={unit} value={unit}>{unit}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Time Settings */}
            <div id="time-settings" className="mb-8">
              <h3 className="text-lg font-semibold mb-4">Thời gian áp dụng</h3>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Ngày bắt đầu</label>
                  <input type="datetime-local" name="startDate" value={form.startDate} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Ngày kết thúc</label>
                  <input type="datetime-local" name="endDate" value={form.endDate} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
                </div>
              </div>
            </div>

            {/* Usage Limits */}
            <div id="usage-limits" className="mb-8">
              <h3 className="text-lg font-semibold mb-4">Giới hạn sử dụng</h3>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Số lượng mã tối đa</label>
                  <input type="number" name="maxCodes" value={form.maxCodes} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Nhập số lượng" required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Số lần sử dụng tối đa/khách</label>
                  <input type="number" name="maxPerCustomer" value={form.maxPerCustomer} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Nhập số lần" required />
                </div>
              </div>
            </div>

            {/* Conditions */}
            <div id="conditions" className="mb-8">
              <h3 className="text-lg font-semibold mb-4">Điều kiện áp dụng</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Giá trị đơn hàng tối thiểu</label>
                  <input type="number" name="minOrderValue" value={form.minOrderValue} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Nhập giá trị" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Áp dụng cho dịch vụ</label>
                  <select
                    name="services"
                    multiple
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 h-32"
                    value={form.services.map(String)}
                    onChange={(e) => {
                      const selected = Array.from(e.target.selectedOptions, (option) => Number(option.value));
                      setForm((prev) => ({ ...prev, services: selected }));
                    }}
                  >
                    {allServices.map((service) => (
                      <option key={service.id} value={service.id}>{service.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Đối tượng khách hàng</label>
                  <div className="space-y-2">
                    {CUSTOMER_TYPES.map((ct) => (
                      <label key={ct.value} className="flex items-center">
                        <input
                          type="checkbox"
                          name="customerTypes"
                          value={ct.value}
                          checked={form.customerTypes.includes(ct.value)}
                          onChange={handleChange}
                          className="rounded text-blue-600 focus:ring-blue-500"
                        />
                        <span className="ml-2">{ct.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Description */}
            <div id="description">
              <h3 className="text-lg font-semibold mb-4">Mô tả chi tiết</h3>
              <textarea
                name="description"
                value={form.description}
                onChange={handleChange}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 h-32"
                placeholder="Nhập mô tả chi tiết về chương trình khuyến mãi"
              ></textarea>
            </div>
          </div>
          {/* Form Actions */}
          <div className="flex justify-end space-x-4 pt-6 border-t">
            <button type="button" className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50" onClick={onCancel}>
              Hủy
            </button>
            <button type="submit" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center">
              <i className="fa-solid fa-check mr-2"></i>
              {initialData ? 'Lưu thay đổi' : 'Lưu khuyến mãi'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewPromotionForm;
