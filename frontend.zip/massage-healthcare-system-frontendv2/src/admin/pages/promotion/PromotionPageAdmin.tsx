import React, { useState, useMemo } from 'react';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import DataTable from '../../components/DataTable';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { useNavigate } from 'react-router-dom';
import { promotions as initialPromotions } from '../../../data/promotionData';
import NewPromotionForm from './NewPromotionForm';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

// Helper to map Promotion to table row format
const mapPromotionToTableRow = (promo: any) => {
  // Calculate used/usageLimit string
  const used = `${promo.used}/${promo.usageLimit}`;
  // Calculate daysLeft and expired
  const endDateParts = promo.endDate.split('/');
  const endDate = new Date(
    parseInt(endDateParts[2]),
    parseInt(endDateParts[1]) - 1,
    parseInt(endDateParts[0])
  );
  const today = new Date();
  const daysLeft = Math.max(0, Math.ceil((endDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
  const expired = daysLeft === 0 || today > endDate;
  // Type color
  let typeColor = 'bg-blue-100 text-blue-700';
  if (promo.type === 'Voucher') typeColor = 'bg-purple-100 text-purple-700';
  if (promo.type === 'Thẻ quà tặng') typeColor = 'bg-yellow-100 text-yellow-700';
  return {
    ...promo,
    used,
    daysLeft,
    expired,
    typeColor,
  };
};

const itemsPerPage = 3;

const PromotionPageAdmin: React.FC = () => {
  const navigate = useNavigate();
  const [user] = useState({
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    role: 'admin',
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [showAddForm, setShowAddForm] = useState(false);
  const [promotionList, setPromotionList] = useState(initialPromotions);
  const [editPromotion, setEditPromotion] = useState<any | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  // Use real promotions data
  const mappedPromotions = useMemo(() => promotionList.map(mapPromotionToTableRow), [promotionList]);
  
  // Filter promotions based on search and status
  const filteredPromotions = useMemo(() => {
    return mappedPromotions.filter(promo => {
      const matchesSearch = searchQuery === '' || 
        promo.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        promo.code.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === '' || promo.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [mappedPromotions, searchQuery, statusFilter]);

  const totalItems = filteredPromotions.length;
  const paginatedPromotions = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredPromotions.slice(start, start + itemsPerPage);
  }, [filteredPromotions, currentPage]);

  const handleRowClick = (id: number) => {
    navigate(`/admin/promotions/${id}`);
  };

  const handleEditClick = (promo: any) => {
    setEditPromotion({
      ...promo,
      value: promo.value.replace(/[^\d]/g, ''),
      valueUnit: promo.value.includes('%') ? '%' : 'VNĐ',
      startDate: promo.startDate ? new Date(promo.startDate.split('/').reverse().join('-')).toISOString().slice(0, 16) : '',
      endDate: promo.endDate ? new Date(promo.endDate.split('/').reverse().join('-')).toISOString().slice(0, 16) : '',
      maxCodes: promo.usageLimit.toString(),
      maxPerCustomer: '',
      minOrderValue: '',
      services: [],
      customerTypes: [],
      description: promo.description,
    });
  };

  const handleDeleteClick = (promo: any) => {
    if (window.confirm(`Bạn có chắc chắn muốn xóa khuyến mãi: ${promo.name}?`)) {
      setPromotionList((prev) => prev.filter((p) => p.id !== promo.id));
      toast.success(`Đã xóa khuyến mãi: ${promo.name}`);
    }
  };

  const tableColumns = [
    {
      header: 'Tên khuyến mãi',
      render: (promo: any) => (
        <div
          className="cursor-pointer hover:text-blue-600"
          onClick={() => handleRowClick(promo.id)}
        >
          <div className="font-medium">{promo.name}</div>
          <div className="text-sm text-gray-500">{promo.code}</div>
        </div>
      ),
    },
    {
      header: 'Loại',
      render: (promo: any) => (
        <span className={`px-3 py-1 rounded-full ${promo.typeColor}`}>{promo.type}</span>
      ),
    },
    {
      header: 'Giá trị',
      field: 'value' as const,
    },
    {
      header: 'Thời hạn',
      render: (promo: any) => (
        <div>
          <div>{promo.endDate}</div>
          <div className="text-sm text-gray-500">{promo.expired ? 'Đã hết hạn' : `Còn ${promo.daysLeft} ngày`}</div>
        </div>
      ),
    },
    {
      header: 'Đã sử dụng',
      field: 'used' as const,
    },
    {
      header: 'Trạng thái',
      render: (promo: any) => (
        <span className={`px-3 py-1 rounded-full ${promo.statusColor}`}>{promo.status}</span>
      ),
    },
    {
      header: 'Hành động',
      render: (promo: any) => (
        <>
          <button
            className="text-blue-600 hover:text-blue-800 mr-3"
            onClick={() => handleRowClick(promo.id)}
            title="Xem chi tiết"
          >
            <i className="fa-solid fa-eye"></i>
          </button>
          <button
            className="text-gray-600 hover:text-gray-800 mr-3"
            onClick={() => handleEditClick(promo)}
            title="Chỉnh sửa"
          >
            <i className="fa-solid fa-pen"></i>
          </button>
          <button
            className="text-red-600 hover:text-red-800"
            onClick={() => handleDeleteClick(promo)}
            title="Xóa"
          >
            <i className="fa-solid fa-trash"></i>
          </button>
        </>
      ),
    },
  ];

  const handleAddPromotion = () => {
    setShowAddForm(true);
  };

  const handleSubmitNewPromotion = (data: any) => {
    // Add new promotion to the list (mock, id auto increment)
    setPromotionList((prev) => [
      {
        ...data,
        id: prev.length ? Math.max(...prev.map((p) => p.id)) + 1 : 1,
        used: 0,
        usageLimit: Number(data.maxCodes),
        status: 'Đang chạy',
        statusColor: 'bg-green-100 text-green-700',
        startDate: data.startDate.split('T').reverse().join('/'),
        endDate: data.endDate.split('T').reverse().join('/'),
      },
      ...prev,
    ]);
    setShowAddForm(false);
    toast.success('Đã thêm khuyến mãi mới!');
  };

  const handleEditCancel = () => {
    setEditPromotion(null);
  };

  const handleEditSubmit = (data: any) => {
    setPromotionList((prev) =>
      prev.map((p) =>
        p.id === editPromotion.id
          ? {
              ...p,
              ...data,
              usageLimit: Number(data.maxCodes),
              value: data.value + (data.valueUnit === '%' ? '%' : 'đ'),
              startDate: data.startDate.split('T').reverse().join('/'),
              endDate: data.endDate.split('T').reverse().join('/'),
            }
          : p
      )
    );
    setEditPromotion(null);
    toast.success('Đã cập nhật khuyến mãi!');
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <HeaderAdmin user={user} />
      <SideBarAdmin />
      <ToastContainer />
      <main className="ml-64 pt-16">
        {showAddForm ? (
          <NewPromotionForm
            onCancel={() => setShowAddForm(false)}
            onSubmit={handleSubmitNewPromotion}
          />
        ) : editPromotion ? (
          <NewPromotionForm
            onCancel={handleEditCancel}
            onSubmit={handleEditSubmit}
            initialData={editPromotion}
          />
        ) : (
          <>
            {/* Top Header */}
            <header id="header" className="bg-white shadow-sm">
              <div className="flex items-center justify-between px-6 py-4">
                <h2 className="text-xl font-bold">Quản lý Khuyến mãi</h2>
                <div className="flex items-center space-x-4">
                  <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700" onClick={handleAddPromotion}>
                    <i className="fa-solid fa-plus mr-2"></i>
                    Tạo khuyến mãi mới
                  </button>
                  <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    <i className="fa-solid fa-file-export mr-2"></i>
                    Xuất danh sách
                  </button>
                </div>
              </div>
            </header>

            {/* Promotion Stats */}
            <div id="promotion-stats" className="p-6 grid grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-lg shadow">
                <div className="text-gray-500">Tổng khuyến mãi đang chạy</div>
                <div className="text-2xl font-bold mt-2">12</div>
                <div className="text-green-500 text-sm mt-2">
                  <i className="fa-solid fa-arrow-up"></i> 8% so với tháng trước
                </div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow">
                <div className="text-gray-500">Lượt sử dụng tháng này</div>
                <div className="text-2xl font-bold mt-2">456</div>
                <div className="text-green-500 text-sm mt-2">
                  <i className="fa-solid fa-arrow-up"></i> 12% so với tháng trước
                </div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow">
                <div className="text-gray-500">Doanh thu từ khuyến mãi</div>
                <div className="text-2xl font-bold mt-2">45.6M</div>
                <div className="text-red-500 text-sm mt-2">
                  <i className="fa-solid fa-arrow-down"></i> 5% so với tháng trước
                </div>
              </div>
              <div className="bg-white p-4 rounded-lg shadow">
                <div className="text-gray-500">Tỷ lệ chuyển đổi</div>
                <div className="text-2xl font-bold mt-2">24.5%</div>
                <div className="text-green-500 text-sm mt-2">
                  <i className="fa-solid fa-arrow-up"></i> 3% so với tháng trước
                </div>
              </div>
            </div>

            {/* Promotion Table */}
            <div id="promotion-table" className="px-6">
              {/* Search and Filter Section */}
              <div className="bg-white p-4 rounded-lg shadow mb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 flex-1">
                    <div className="relative flex-1">
                      <i className="fa-solid fa-search absolute left-3 top-2.5 text-gray-400"></i>
                      <input
                        type="text"
                        placeholder="Tìm kiếm theo tên khuyến mãi hoặc mã..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    <select
                      className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                    >
                      <option value="">Tất cả trạng thái</option>
                      <option value="Đang chạy">Đang chạy</option>
                      <option value="Tạm dừng">Tạm dừng</option>
                      <option value="Đã kết thúc">Đã kết thúc</option>
                    </select>
                  </div>
                </div>
              </div>
              <DataTable
                columns={tableColumns}
                data={paginatedPromotions}
                totalItems={totalItems}
                currentPage={currentPage}
                onPageChange={setCurrentPage}
                itemsPerPage={itemsPerPage}
              />
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default PromotionPageAdmin;
