import React, { useState } from 'react';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import ReactApexChart from 'react-apexcharts';
import { ApexOptions } from 'apexcharts';
import '@fortawesome/fontawesome-free/css/all.min.css';
import NewReportForm from './NewReportForm';

const FinancePageAdmin: React.FC = () => {
  // Static user for header
  const [user] = useState({
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    role: 'admin',
  });

  const [showReportForm, setShowReportForm] = useState(false);

  const handleLogout = () => {
    // TODO: Implement logout logic
    console.log('Logging out...');
  };

  // Revenue Chart Options
  const revenueOptions: ApexOptions = {
    chart: {
      type: 'area',
      height: 300,
      toolbar: { show: false },
    },
    stroke: { curve: 'smooth' },
    xaxis: {
      categories: ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'],
    },
    colors: ['#2563eb'],
    fill: {
      type: 'gradient',
      gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.7,
        opacityTo: 0.2,
        stops: [0, 90, 100],
      },
    },
    grid: { borderColor: '#f2f2f2' },
  };
  const revenueSeries = [
    {
      name: 'Doanh thu',
      data: [30, 40, 35, 50, 49, 60, 70],
    },
  ];

  // Service Revenue Chart Options
  const serviceOptions: ApexOptions = {
    chart: {
      type: 'pie',
      height: 300,
    },
    labels: ['Massage', 'Spa', 'Facial', 'Khác'],
    colors: ['#2563eb', '#ef4444', '#10b981', '#a78bfa'],
    legend: { position: 'bottom' },
  };
  const serviceSeries = [44, 55, 13, 43];

  return (
    <div className="min-h-screen bg-gray-100">
      <HeaderAdmin user={user} handleLogout={handleLogout} />
      <SideBarAdmin />
      <main className="ml-64 pt-16">
        {showReportForm ? (
          <NewReportForm onCancel={() => setShowReportForm(false)} />
        ) : (
          <>
            {/* Top Header */}
            <header id="header" className="bg-white shadow-sm">
              <div className="flex items-center justify-between px-6 py-4">
                <h2 className="text-xl font-bold">Báo cáo Tài chính</h2>
                <div className="flex items-center space-x-4">
                  <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700" onClick={() => setShowReportForm(true)}>
                    <i className="fa-solid fa-plus mr-2"></i>
                    Tạo báo cáo mới
                  </button>
                  <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    <i className="fa-solid fa-file-export mr-2"></i>
                    Xuất báo cáo
                  </button>
                </div>
              </div>
            </header>

            {/* Date Filter */}
            <div id="date-filter" className="p-6">
              <div className="grid grid-cols-4 gap-4">
                <div className="col-span-2 flex space-x-4">
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-lg">Hôm nay</button>
                  <button className="px-4 py-2 border border-gray-300 rounded-lg">Tuần này</button>
                  <button className="px-4 py-2 border border-gray-300 rounded-lg">Tháng này</button>
                  <button className="px-4 py-2 border border-gray-300 rounded-lg">
                    <i className="fa-solid fa-calendar mr-2"></i>
                    Tùy chọn
                  </button>
                </div>
              </div>
            </div>

            {/* KPI Cards */}
            <div id="kpi-cards" className="px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-6 rounded-lg shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-gray-500">Tổng doanh thu</p>
                    <h3 className="text-2xl font-bold mt-2">45,600,000đ</h3>
                    <p className="text-green-500 text-sm mt-2">
                      <i className="fa-solid fa-arrow-up"></i>
                      12.5% so với tháng trước
                    </p>
                  </div>
                  <div className="p-3 bg-blue-100 rounded-lg">
                    <i className="fa-solid fa-money-bill-trend-up text-blue-600 text-xl"></i>
                  </div>
                </div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-gray-500">Chi phí</p>
                    <h3 className="text-2xl font-bold mt-2">15,200,000đ</h3>
                    <p className="text-red-500 text-sm mt-2">
                      <i className="fa-solid fa-arrow-down"></i>
                      8.3% so với tháng trước
                    </p>
                  </div>
                  <div className="p-3 bg-red-100 rounded-lg">
                    <i className="fa-solid fa-money-bill-transfer text-red-600 text-xl"></i>
                  </div>
                </div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-gray-500">Lợi nhuận</p>
                    <h3 className="text-2xl font-bold mt-2">30,400,000đ</h3>
                    <p className="text-green-500 text-sm mt-2">
                      <i className="fa-solid fa-arrow-up"></i>
                      15.2% so với tháng trước
                    </p>
                  </div>
                  <div className="p-3 bg-green-100 rounded-lg">
                    <i className="fa-solid fa-chart-pie text-green-600 text-xl"></i>
                  </div>
                </div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-gray-500">Số đơn hàng</p>
                    <h3 className="text-2xl font-bold mt-2">256</h3>
                    <p className="text-green-500 text-sm mt-2">
                      <i className="fa-solid fa-arrow-up"></i>
                      5.8% so với tháng trước
                    </p>
                  </div>
                  <div className="p-3 bg-purple-100 rounded-lg">
                    <i className="fa-solid fa-file-invoice text-purple-600 text-xl"></i>
                  </div>
                </div>
              </div>
            </div>

            {/* Charts Section */}
            <div id="charts-section" className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Revenue Chart */}
              <div className="bg-white p-6 rounded-lg shadow">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-bold">Doanh thu theo thời gian</h3>
                  <select className="px-3 py-1 border rounded-lg">
                    <option>7 ngày qua</option>
                    <option>30 ngày qua</option>
                    <option>3 tháng qua</option>
                  </select>
                </div>
                <div className="h-[300px] flex items-center justify-center">
                  <div className="w-full h-full">
                    <ReactApexChart options={revenueOptions} series={revenueSeries} type="area" height={300} />
                  </div>
                </div>
              </div>
              {/* Service Revenue Chart */}
              <div className="bg-white p-6 rounded-lg shadow">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-bold">Doanh thu theo dịch vụ</h3>
                  <select className="px-3 py-1 border rounded-lg">
                    <option>Tháng này</option>
                    <option>Quý này</option>
                    <option>Năm nay</option>
                  </select>
                </div>
                <div className="h-[300px] flex items-center justify-center">
                  <div className="w-full h-full">
                    <ReactApexChart options={serviceOptions} series={serviceSeries} type="pie" height={300} />
                  </div>
                </div>
              </div>
            </div>

            {/* Transaction Table */}
            <div id="transaction-table" className="px-6 mb-6">
              <div className="bg-white rounded-lg shadow">
                <div className="p-6 border-b">
                  <h3 className="font-bold">Giao dịch gần đây</h3>
                </div>
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="px-6 py-4">Mã giao dịch</th>
                      <th className="px-6 py-4">Ngày</th>
                      <th className="px-6 py-4">Khách hàng</th>
                      <th className="px-6 py-4">Dịch vụ</th>
                      <th className="px-6 py-4">Số tiền</th>
                      <th className="px-6 py-4">Trạng thái</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="px-6 py-4">#TRX001</td>
                      <td className="px-6 py-4">25/04/2025</td>
                      <td className="px-6 py-4">Nguyễn Thị Anh</td>
                      <td className="px-6 py-4">Massage toàn thân</td>
                      <td className="px-6 py-4">850,000đ</td>
                      <td className="px-6 py-4">
                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full">Hoàn thành</span>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="px-6 py-4">#TRX002</td>
                      <td className="px-6 py-4">25/04/2025</td>
                      <td className="px-6 py-4">Trần Văn Bình</td>
                      <td className="px-6 py-4">Gói VIP</td>
                      <td className="px-6 py-4">2,500,000đ</td>
                      <td className="px-6 py-4">
                        <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full">Đang xử lý</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default FinancePageAdmin;
