import React, { useState } from "react";

const NewReportForm: React.FC<{ onCancel?: () => void }> = ({ onCancel }) => {
  const [title, setTitle] = useState("");
  const [type, setType] = useState("Báo cáo doanh thu");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [format, setFormat] = useState("PDF");
  const [emails, setEmails] = useState("");
  const [schedule, setSchedule] = useState("Không tự động");
  const [components, setComponents] = useState<string[]>([]);

  const reportComponents = [
    "Tổng quan KPI",
    "Biểu đồ doanh thu",
    "Biểu đồ dịch vụ",
    "Danh sách giao dịch",
    "Phân tích chi tiết",
  ];

  const handleComponentChange = (component: string) => {
    setComponents((prev) =>
      prev.includes(component)
        ? prev.filter((c) => c !== component)
        : [...prev, component]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Xử lý lưu báo cáo ở đây
    alert("Báo cáo đã được lưu!");
  };

  return (
    <div className="max-w-4xl w-full mx-auto bg-white rounded-lg shadow-lg mb-8">
      {/* Top Header */}
      <header id="header" className="bg-white shadow-sm rounded-t-lg">
        <div className="flex items-center justify-between px-6 py-4">
          <h2 className="text-xl font-bold">Tạo báo cáo mới</h2>
          <button
            type="button"
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
            onClick={onCancel || (() => window.history.back())}
          >
            <i className="fa-solid fa-xmark mr-2"></i>
            Đóng
          </button>
        </div>
      </header>
      <div className="p-6">
        <form className="space-y-6" onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Basic Information */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tiêu đề báo cáo
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-2 border rounded-lg"
                  placeholder="Nhập tiêu đề báo cáo"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Loại báo cáo
                </label>
                <select
                  className="w-full px-4 py-2 border rounded-lg"
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                >
                  <option>Báo cáo doanh thu</option>
                  <option>Báo cáo chi phí</option>
                  <option>Báo cáo lợi nhuận</option>
                  <option>Báo cáo tổng hợp</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Khoảng thời gian
                </label>
                <div className="flex space-x-4">
                  <input
                    type="date"
                    className="flex-1 px-4 py-2 border rounded-lg"
                    value={dateFrom}
                    onChange={(e) => setDateFrom(e.target.value)}
                    required
                  />
                  <input
                    type="date"
                    className="flex-1 px-4 py-2 border rounded-lg"
                    value={dateTo}
                    onChange={(e) => setDateTo(e.target.value)}
                    required
                  />
                </div>
              </div>
            </div>

            {/* Additional Options */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Định dạng xuất
                </label>
                <div className="flex space-x-3">
                  {['PDF', 'Excel', 'CSV'].map((fmt) => (
                    <label className="flex items-center" key={fmt}>
                      <input
                        type="radio"
                        name="format"
                        className="mr-2"
                        checked={format === fmt}
                        onChange={() => setFormat(fmt)}
                      />
                      {fmt}
                    </label>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Gửi báo cáo tới
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-2 border rounded-lg"
                  placeholder="Nhập email (phân cách bằng dấu phẩy)"
                  value={emails}
                  onChange={(e) => setEmails(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Lịch gửi tự động
                </label>
                <select
                  className="w-full px-4 py-2 border rounded-lg"
                  value={schedule}
                  onChange={(e) => setSchedule(e.target.value)}
                >
                  <option>Không tự động</option>
                  <option>Hàng ngày</option>
                  <option>Hàng tuần</option>
                  <option>Hàng tháng</option>
                </select>
              </div>
            </div>
          </div>

          {/* Report Components */}
          <div className="mt-8">
            <h3 className="text-lg font-medium mb-4">Thành phần báo cáo</h3>
            <div className="space-y-3">
              {reportComponents.map((comp) => (
                <div className="flex items-center p-4 border rounded-lg" key={comp}>
                  <input
                    type="checkbox"
                    className="mr-3"
                    checked={components.includes(comp)}
                    onChange={() => handleComponentChange(comp)}
                  />
                  <span>{comp}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Preview Section */}
          <div className="mt-8">
            <h3 className="text-lg font-medium mb-4">Xem trước báo cáo</h3>
            <div className="border-2 border-dashed rounded-lg p-8 text-center">
              <i className="fa-solid fa-file-lines text-4xl text-gray-400 mb-3"></i>
              <p className="text-gray-500">Nhấn để xem trước báo cáo</p>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewReportForm;
