import { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faArrowLeft,
  faBell,
  faCalendarPlus,
  faPen,
  faHands,
  faSpa,
  faCrown,
  faPlus
} from '@fortawesome/free-solid-svg-icons';
import HeaderAdmin from "../../components/HeaderAdmin";
import SideBarAdmin from "../../components/SideBarAdmin";
import { useNavigate, useParams } from "react-router-dom";
import { customers, membershipTiers, Customer } from '../../../data/customerData';
import NewAppointmentForm from '../appointment/NewAppointmentForm';
import { toast } from 'react-toastify';

const CustomerProfilePageAdmin = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [showNewAppointmentForm, setShowNewAppointmentForm] = useState(false);

  useEffect(() => {
    const customerData = customers.find((c) => c.id === id) as Customer | undefined;
    if (customerData) {
      setCustomer(customerData);
    } else {
      setCustomer(null);
    }
  }, [id]);

  const handleBackClick = () => {
    navigate('/admin/customers');
  };

  const handleNewAppointment = () => {
    setShowNewAppointmentForm(true);
  };

  const handleAppointmentSubmit = (appointmentData: any) => {
    // TODO: Implement appointment creation logic
    console.log('New appointment data:', appointmentData);
    toast.success('Đã tạo lịch hẹn mới thành công!');
    setShowNewAppointmentForm(false);
  };

  if (!customer) {
    return <div>Loading...</div>;
  }

  const membershipTier = membershipTiers[customer.membershipTier as keyof typeof membershipTiers];

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <HeaderAdmin user={{ avatar: '', role: 'admin' }} handleLogout={() => {}} />
      {/* Sidebar */}
      <SideBarAdmin />
      {/* Main Content */}
      <div className="flex-1 ml-64 pt-16">
        {showNewAppointmentForm ? (
          <NewAppointmentForm 
            onClose={() => setShowNewAppointmentForm(false)}
            onSubmit={handleAppointmentSubmit}
            initialData={{
              customerId: customer.id,
              customerName: customer.name,
              customerAvatar: customer.avatar
            }}
            isEditMode={false}
          />
        ) : (
          <>
            {/* Top Header */}
            <header id="profile-header" className="bg-white shadow-sm">
              <div className="flex items-center justify-between px-6 py-4">
                <div className="flex items-center space-x-4">
                  <button
                    type="button"
                    className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
                    onClick={handleBackClick}
                  >
                    <FontAwesomeIcon icon={faArrowLeft} className="mr-2" />
                    Quay lại
                  </button>
                  <h2 className="text-xl font-bold">Hồ sơ khách hàng</h2>
                </div>
                <div className="flex items-center space-x-3">
                  <button className="flex items-center px-4 py-2 text-blue-600 border border-blue-600 rounded-lg hover:bg-blue-50">
                    <FontAwesomeIcon icon={faBell} className="mr-2" />
                    Gửi thông báo
                  </button>
                  <button 
                    className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    onClick={handleNewAppointment}
                  >
                    <FontAwesomeIcon icon={faCalendarPlus} className="mr-2" />
                    Thêm lịch hẹn
                  </button>
                </div>
              </div>
            </header>

            <div className="p-6">
              <div className="grid grid-cols-3 gap-6">
                {/* Customer Info Card */}
                <div id="customer-info" className="col-span-2 bg-white rounded-lg shadow">
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center space-x-4">
                        <img 
                          src={customer.avatar}
                          className="w-16 h-16 rounded-full"
                          alt={`${customer.name}'s avatar`}
                        />
                        <div>
                          <h3 className="text-xl font-bold">{customer.name}</h3>
                          <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm">
                            {customer.membershipTier}
                          </span>
                        </div>
                      </div>
                      <button className="text-gray-600 hover:text-gray-800">
                        <FontAwesomeIcon icon={faPen} />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm text-gray-500">Số điện thoại</label>
                          <p>{customer.phone}</p>
                        </div>
                        <div>
                          <label className="text-sm text-gray-500">Email</label>
                          <p>{customer.email}</p>
                        </div>
                        <div>
                          <label className="text-sm text-gray-500">Ngày sinh</label>
                          <p>{customer.birthDate}</p>
                        </div>
                      </div>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm text-gray-500">Địa chỉ</label>
                          <p>{customer.address}</p>
                        </div>
                        <div>
                          <label className="text-sm text-gray-500">Giới tính</label>
                          <p>{customer.gender}</p>
                        </div>
                        <div>
                          <label className="text-sm text-gray-500">Ngày tham gia</label>
                          <p>{customer.joinDate}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Tabs */}
                  <div className="border-t">
                    <div className="flex border-b">
                      <button className="px-6 py-3 text-blue-600 border-b-2 border-blue-600">
                        Lịch sử dịch vụ
                      </button>
                    </div>

                    {/* Service History */}
                    <div className="p-6">
                      <div className="space-y-4">
                        {customer.serviceHistory && customer.serviceHistory.length > 0 ? customer.serviceHistory.map((service) => (
                          <div key={service.id} className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex items-center space-x-4">
                              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                                <FontAwesomeIcon icon={service.icon === 'faHands' ? faHands : faSpa} className="text-blue-600 text-xl" />
                              </div>
                              <div>
                                <h4 className="font-medium">{service.serviceName}</h4>
                                <p className="text-sm text-gray-500">{service.date} - {service.duration}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">{service.price}</p>
                              <p className="text-sm text-gray-500">Nhân viên: {service.staff}</p>
                            </div>
                          </div>
                        )) : <div className="text-gray-500">Chưa có lịch sử dịch vụ</div>}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Side Cards */}
                <div className="space-y-6">
                  {/* Membership Card */}
                  <div id="membership-card" className={`bg-gradient-to-r ${membershipTier.color} rounded-lg shadow p-6 text-white`}>
                    <div className="flex justify-between items-start mb-8">
                      <div>
                        <p className="text-sm opacity-80">Thẻ thành viên</p>
                        <h3 className="text-xl font-bold">{customer.membershipTier}</h3>
                      </div>
                      <FontAwesomeIcon icon={faCrown} className="text-2xl" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="opacity-80">Điểm thưởng</span>
                        <span className="font-bold">{customer.membershipInfo.points}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="opacity-80">Ưu đãi hiện tại</span>
                        <span className="font-bold">{customer.membershipInfo.discount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="opacity-80">Hạn dùng</span>
                        <span className="font-bold">{customer.membershipInfo.expiryDate}</span>
                      </div>
                    </div>
                  </div>

                  {/* Health Notes */}
                  <div id="health-notes" className="bg-white rounded-lg shadow p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-bold">Ghi chú sức khỏe</h3>
                      <button className="text-gray-600 hover:text-gray-800">
                        <FontAwesomeIcon icon={faPlus} />
                      </button>
                    </div>
                    <div className="space-y-3">
                      {customer.healthNotes && customer.healthNotes.length > 0 ? customer.healthNotes.map((note, index) => (
                        <div key={index} className={`p-3 ${note.type === 'warning' ? 'bg-yellow-50' : 'bg-blue-50'} rounded-lg`}>
                          <p className={`text-sm ${note.type === 'warning' ? 'text-yellow-800' : 'text-blue-800'}`}>{note.note}</p>
                          <p className={`text-xs ${note.type === 'warning' ? 'text-yellow-600' : 'text-blue-600'}`}>Cập nhật: {note.updatedAt}</p>
                        </div>
                      )) : <div className="text-gray-500">Không có ghi chú sức khỏe</div>}
                    </div>
                  </div>

                  {/* Upcoming Appointments */}
                  <div id="upcoming-appointments" className="bg-white rounded-lg shadow p-6">
                    <h3 className="font-bold mb-4">Lịch hẹn sắp tới</h3>
                    <div className="space-y-3">
                      {customer.upcomingAppointments && customer.upcomingAppointments.length > 0 ? customer.upcomingAppointments.map((appointment) => (
                        <div key={appointment.id} className="flex items-center space-x-3 p-3 border rounded-lg">
                          <div className="w-12 text-center">
                            <p className="text-sm font-bold">{appointment.date.split('/')[0]}</p>
                            <p className="text-xs text-gray-500">TH{appointment.date.split('/')[1]}</p>
                          </div>
                          <div>
                            <p className="font-medium">{appointment.serviceName}</p>
                            <p className="text-sm text-gray-500">{appointment.time} - {appointment.duration}</p>
                          </div>
                        </div>
                      )) : <div className="text-gray-500">Không có lịch hẹn sắp tới</div>}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default CustomerProfilePageAdmin;
