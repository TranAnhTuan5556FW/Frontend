import React, { useState } from "react";
import HeaderAdmin from "../../components/HeaderAdmin";
import SideBarAdmin from "../../components/SideBarAdmin";
import membershipsData from "../../../data/membershipsData";
import { useNavigate } from "react-router-dom";
import NewMembershipLevelForm from "./NewMembershipLevelForm";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const stats = [
  {
    label: "Tổng số thành viên",
    value: membershipsData.reduce((sum, m) => sum + m.memberCount, 0).toString(),
    change: "+12%",
    icon: <i className="fa-solid fa-arrow-up"></i>,
    color: "text-green-600",
    sub: "so với tháng trước",
  },
  {
    label: "Doanh thu từ thành viên",
    value: "865.5M",
    change: "+8%",
    icon: <i className="fa-solid fa-arrow-up"></i>,
    color: "text-green-600",
    sub: "so với tháng trước",
  },
  {
    label: "Tỷ lệ chuyển đổi cấp",
    value: "15.2%",
    change: "-3%",
    icon: <i className="fa-solid fa-arrow-down"></i>,
    color: "text-red-600",
    sub: "so với tháng trước",
  },
];

const iconMap: Record<string, React.ReactNode> = {
  'fa-crown': <i className="fa-solid fa-crown text-yellow-500 text-xl"></i>,
  'fa-medal': <i className="fa-solid fa-medal text-gray-400 text-xl"></i>,
  'fa-award': <i className="fa-solid fa-award text-amber-700 text-xl"></i>,
};

const MembershipPageAdmin: React.FC = () => {
  // User info for header
  const user = {
    avatar: "https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg",
    role: "admin",
  };
  const navigate = useNavigate();
  const handleBack = () => {
    navigate(-1);
  };

  const [showAddForm, setShowAddForm] = useState(false);
  const [editLevel, setEditLevel] = useState<any>(null);
  const [memberships, setMemberships] = useState(membershipsData);

  const handleAddLevel = () => {
    setEditLevel(null);
    setShowAddForm(true);
  };
  const handleCancelAddLevel = () => {
    setShowAddForm(false);
    setEditLevel(null);
  };
  const handleSubmitNewLevel = (_data: any) => {
    // TODO: Xử lý thêm hoặc cập nhật cấp độ mới (gọi API hoặc cập nhật state)
    setShowAddForm(false);
    setEditLevel(null);
  };
  const handleEditLevel = (level: any) => {
    setEditLevel({
      name: level.name,
      code: level.type, // hoặc level.code nếu có
      minSpending: level.criteria.spending,
      minFrequency: level.criteria.frequency,
      discount: level.benefits.find((b: string) => b.includes('Giảm giá'))?.replace(/\D/g, ''),
      pointMultiplier: level.benefits.find((b: string) => b.includes('Tích điểm'))?.replace(/\D/g, ''),
      duration: '1 năm', // hoặc lấy từ dữ liệu nếu có
      status: level.status,
      activateNow: false,
    });
    setShowAddForm(true);
  };
  const handleDeleteLevel = (level: any) => {
    if (window.confirm(`Bạn có chắc chắn muốn xóa cấp độ "${level.name}"?`)) {
      setMemberships(prev => prev.filter(m => m.id !== level.id));
      toast.success(`Đã xóa cấp độ thành viên: ${level.name}`);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex">
      <HeaderAdmin user={user} />
      <SideBarAdmin />
      <div className="flex-1 ml-64 pt-16">
        {showAddForm ? (
          <NewMembershipLevelForm
            onCancel={handleCancelAddLevel}
            onSubmit={handleSubmitNewLevel}
            initialData={editLevel}
          />
        ) : (
          <>
            {/* Top Header */}
            <header id="header" className="bg-white shadow-sm">
              <div className="flex items-center justify-between px-6 py-4">
                <div className="flex items-center space-x-4">
                  <button 
                    type="button"
                    className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
                    onClick={handleBack}
                  >
                    <i className="fa-solid fa-arrow-left mr-2"></i>
                    Quay lại
                  </button>
                  <h2 className="text-xl font-bold">Quản lý Chương trình Thành viên</h2>
                </div>
                <div className="flex items-center space-x-4">
                  <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700" onClick={handleAddLevel}>
                    <i className="fa-solid fa-plus mr-2"></i>
                    Thêm cấp độ mới
                  </button>
                  <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    <i className="fa-solid fa-file-export mr-2"></i>
                    Xuất báo cáo
                  </button>
                </div>
              </div>
            </header>

            {/* Membership Levels Table */}
            <div id="membership-table" className="p-6">
              <div className="bg-white rounded-lg shadow">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="px-6 py-4">Cấp độ</th>
                      <th className="px-6 py-4">Tiêu chí</th>
                      <th className="px-6 py-4">Ưu đãi</th>
                      <th className="px-6 py-4">Số lượng thành viên</th>
                      <th className="px-6 py-4">Trạng thái</th>
                      <th className="px-6 py-4">Hành động</th>
                    </tr>
                  </thead>
                  <tbody>
                    {memberships.map((level) => (
                      <tr key={level.id} className="border-b hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-3">
                            {iconMap[level.icon]}
                            <div>
                              <div className="font-medium">{level.name}</div>
                              <div className="text-sm text-gray-500">{level.type}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div>{level.criteria.spending}</div>
                          <div className="text-sm text-gray-500">{level.criteria.frequency}</div>
                        </td>
                        <td className="px-6 py-4">
                          {level.benefits.map((b, i) => <div key={i}>{b}</div>)}
                        </td>
                        <td className="px-6 py-4">
                          <div className="font-medium">{level.memberCount} thành viên</div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full ${level.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-200 text-gray-500'}`}>{level.status === 'active' ? 'Đang hoạt động' : 'Ngừng hoạt động'}</span>
                        </td>
                        <td className="px-6 py-4">
                          <button className="text-gray-600 hover:text-gray-800 mr-3" onClick={() => handleEditLevel(level)}>
                            <i className="fa-solid fa-pen"></i>
                          </button>
                          <button 
                            className="text-red-600 hover:text-red-800"
                            onClick={() => handleDeleteLevel(level)}
                          >
                            <i className="fa-solid fa-trash"></i>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Statistics Cards */}
            <div id="stats-cards" className="px-6 grid grid-cols-1 md:grid-cols-3 gap-6">
              {stats.map((stat) => (
                <div key={stat.label} className="bg-white p-6 rounded-lg shadow">
                  <div className="text-gray-600 mb-2">{stat.label}</div>
                  <div className="text-3xl font-bold">{stat.value}</div>
                  <div className={`mt-4 text-sm ${stat.color}`}>
                    {stat.icon} {stat.change} {stat.sub}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
      <ToastContainer position="top-right" autoClose={2000} />
    </div>
  );
};

export default MembershipPageAdmin;
