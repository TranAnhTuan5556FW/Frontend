import React, { useState } from 'react';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { useNavigate } from 'react-router-dom';

const NotificationsPageAdmin: React.FC = () => {
  const [user] = useState({
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    role: 'admin',
  });

  const navigate = useNavigate();

  const handleLogout = () => {
    // TODO: Implement logout logic
    console.log('Logging out...');
  };

  const handleBack = () => {
    navigate('/admin/customer-care');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <HeaderAdmin user={user} handleLogout={handleLogout} />
      <SideBarAdmin />
      <main className="ml-64 pt-16 flex-1">
        {/* Top Header */}
        <header id="header" className="bg-white shadow-sm">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center space-x-4">
              <button
                type="button"
                className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
                onClick={handleBack}
              >
                <i className="fa-solid fa-arrow-left mr-2"></i>
                Quay lại
              </button>
              <h2 className="text-xl font-bold">Gửi thông báo mới</h2>
            </div>
            <div className="flex items-center space-x-4">
              <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                <i className="fa-solid fa-clock-rotate-left mr-2"></i>
                Lịch sử gửi
              </button>
            </div>
          </div>
        </header>

        {/* Notification Form */}
        <div id="notification-form" className="p-6">
          <div className="bg-white rounded-lg shadow">
            <div className="p-6">
              <form>
                {/* Notification Type */}
                <div className="mb-6">
                  <label className="block text-gray-700 font-medium mb-2">Loại thông báo</label>
                  <div className="grid grid-cols-4 gap-4">
                    <div className="border p-4 rounded-lg cursor-pointer hover:border-blue-500">
                      <div className="flex items-center">
                        <input type="radio" name="notification-type" className="mr-3" />
                        <div>
                          <i className="fa-solid fa-cake-candles text-purple-600 text-xl mb-2"></i>
                          <p className="font-medium">Sinh nhật</p>
                        </div>
                      </div>
                    </div>
                    <div className="border p-4 rounded-lg cursor-pointer hover:border-blue-500">
                      <div className="flex items-center">
                        <input type="radio" name="notification-type" className="mr-3" />
                        <div>
                          <i className="fa-solid fa-calendar text-blue-600 text-xl mb-2"></i>
                          <p className="font-medium">Nhắc lịch</p>
                        </div>
                      </div>
                    </div>
                    <div className="border p-4 rounded-lg cursor-pointer hover:border-blue-500">
                      <div className="flex items-center">
                        <input type="radio" name="notification-type" className="mr-3" />
                        <div>
                          <i className="fa-solid fa-star text-yellow-600 text-xl mb-2"></i>
                          <p className="font-medium">Khảo sát</p>
                        </div>
                      </div>
                    </div>
                    <div className="border p-4 rounded-lg cursor-pointer hover:border-blue-500">
                      <div className="flex items-center">
                        <input type="radio" name="notification-type" className="mr-3" />
                        <div>
                          <i className="fa-solid fa-bullhorn text-red-600 text-xl mb-2"></i>
                          <p className="font-medium">Khuyến mãi</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recipients */}
                <div className="mb-6">
                  <label className="block text-gray-700 font-medium mb-2">Đối tượng nhận</label>
                  <div className="flex space-x-4 mb-4">
                    <button type="button" className="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100">
                      <i className="fa-solid fa-users mr-2"></i>Tất cả
                    </button>
                    <button type="button" className="px-4 py-2 border rounded-lg hover:bg-gray-50">
                      <i className="fa-solid fa-crown text-yellow-500 mr-2"></i>Khách VIP
                    </button>
                    <button type="button" className="px-4 py-2 border rounded-lg hover:bg-gray-50">
                      <i className="fa-solid fa-user-check mr-2"></i>Tùy chọn
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full flex items-center">
                      Tất cả khách hàng (1,234)
                      <i className="fa-solid fa-xmark ml-2 cursor-pointer"></i>
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="mb-6">
                  <label className="block text-gray-700 font-medium mb-2">Nội dung thông báo</label>
                  <div className="border rounded-lg p-4">
                    <div className="mb-4">
                      <input type="text" placeholder="Tiêu đề thông báo" className="w-full p-2 border rounded" />
                    </div>
                    <div className="mb-4">
                      <textarea rows={4} placeholder="Nội dung chi tiết..." className="w-full p-2 border rounded"></textarea>
                    </div>
                    <div className="flex items-center space-x-4">
                      <button type="button" className="flex items-center px-3 py-2 text-gray-600 hover:bg-gray-100 rounded">
                        <i className="fa-solid fa-image mr-2"></i>
                        Thêm hình ảnh
                      </button>
                      <button type="button" className="flex items-center px-3 py-2 text-gray-600 hover:bg-gray-100 rounded">
                        <i className="fa-solid fa-link mr-2"></i>
                        Thêm liên kết
                      </button>
                    </div>
                  </div>
                </div>

                {/* Schedule */}
                <div className="mb-6">
                  <label className="block text-gray-700 font-medium mb-2">Thời gian gửi</label>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center">
                      <input type="radio" name="schedule" className="mr-2" />
                      <span>Gửi ngay</span>
                    </div>
                    <div className="flex items-center">
                      <input type="radio" name="schedule" className="mr-2" />
                      <span>Hẹn giờ</span>
                    </div>
                    <input type="datetime-local" className="border p-2 rounded" />
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-end space-x-4 mt-8">
                  <button type="button" className="px-6 py-2 border rounded-lg hover:bg-gray-50">
                    Hủy
                  </button>
                  <button type="submit" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                    <i className="fa-solid fa-paper-plane mr-2"></i>
                    Gửi thông báo
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default NotificationsPageAdmin;
