import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import { removeVietnameseTones } from '../../../utils/stringUtils';
import DataTable from '../../components/DataTable';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { customers as customerData } from '../../../data/customerData';
import NewCustomerFormAdmin from './NewCustomerFormAdmin';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const groupColors: Record<string, string> = {
    'VIP': 'bg-purple-100 text-purple-700',
    'Tiềm năng': 'bg-blue-100 text-blue-700',
    'Thường': 'bg-gray-100 text-gray-700',
};

const itemsPerPage = 3;

const CustomerPageAdmin: React.FC = () => {
    const navigate = useNavigate();
    // Convert customerData to the format expected by the table (spending as number)
    const [customers, setCustomers] = useState(
        customerData.map((c) => ({
            ...c,
            id: Number(c.id),
            spending: typeof c.spending === 'string' ? Number(c.spending.replace(/[^\d]/g, '')) : c.spending,
        }))
    );
    const [searchText, setSearchText] = useState('');
    const [groupFilter, setGroupFilter] = useState('Tất cả nhóm');
    const [sortOption, setSortOption] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [showAddForm, setShowAddForm] = useState(false);
    const [editCustomer, setEditCustomer] = useState<any>(null);

    // User info for header
    const [user] = useState({
        avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
        role: 'admin',
    });
    const handleLogout = () => {
        // TODO: Implement logout logic
        console.log('Logging out...');
    };

    // Filter and sort
    const filteredCustomers = useMemo(() => {
        let result = customers.filter((c) => {
            const matchText = removeVietnameseTones(c.name + c.phone + c.email).toLowerCase().includes(removeVietnameseTones(searchText).toLowerCase());
            const matchGroup = groupFilter === 'Tất cả nhóm' || c.group === groupFilter;
            return matchText && matchGroup;
        });
        if (sortOption === 'Chi tiêu cao nhất') {
            result = [...result].sort((a, b) => b.spending - a.spending);
        } else if (sortOption === 'Tần suất sử dụng') {
            // No numeric frequency, so keep as is or implement custom logic
        } else if (sortOption === 'Mới nhất') {
            result = [...result].sort((a, b) => b.id - a.id);
        }
        return result;
    }, [customers, searchText, groupFilter, sortOption]);

    // Pagination
    const paginatedCustomers = useMemo(() => {
        const start = (currentPage - 1) * itemsPerPage;
        return filteredCustomers.slice(start, start + itemsPerPage);
    }, [filteredCustomers, currentPage]);

    // Actions
    const handleAddCustomer = () => {
        setEditCustomer(null);
        setShowAddForm(true);
    };
    const handleEditCustomer = (customer: any) => {
        // Chuyển birthDate (dd/MM/yyyy) sang dob (yyyy-MM-dd) cho form
        let dob = '';
        if (customer.birthDate) {
            const [day, month, year] = customer.birthDate.split('/');
            dob = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
        }
        setEditCustomer({ ...customer, dob });
        setShowAddForm(true);
    };
    const handleSubmitNewCustomer = (data: any) => {
        if (editCustomer) {
            setCustomers(prev => prev.map(c => c.id === editCustomer.id ? { ...c, ...data } : c));
            toast.success(`Cập nhật khách hàng: ${data.name} thành công!`);
        } else {
            const newId = customers.length > 0 ? Math.max(...customers.map(c => c.id)) + 1 : 1;
            setCustomers(prev => [
                {
                    ...data,
                    id: newId,
                    spending: 0,
                    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg',
                },
                ...prev
            ]);
            toast.success(`Thêm mới khách hàng: ${data.name} thành công!`);
        }
        setShowAddForm(false);
        setEditCustomer(null);
    };
    const handleDeleteCustomer = (id: number) => {
        if (window.confirm('Bạn có chắc chắn muốn xóa khách hàng này?')) {
            const deleted = customers.find(c => c.id === id);
            setCustomers((prev) => prev.filter((c) => c.id !== id));
            toast.success(`Đã xóa khách hàng: ${deleted?.name || ''} (ID: ${id})`);
        }
    };
    const handleViewCustomer = (id: number) => {
        navigate(`/admin/customers/${id}`);
    };

    // Table columns for DataTable
    const tableColumns = [
        {
            header: 'Khách hàng',
            render: (customer: any) => (
                <div className="flex items-center space-x-3 cursor-pointer" onClick={() => handleViewCustomer(customer.id)}>
                    <img src={customer.avatar} alt={customer.name} className="w-10 h-10 rounded-full" />
                    <div>
                        <div className="font-medium">{customer.name}</div>
                        <div className="text-sm text-gray-500">ID: #{customer.id}</div>
                    </div>
                </div>
            ),
        },
        {
            header: 'Liên hệ',
            render: (customer: any) => (
                <div>
                    <div>{customer.phone}</div>
                    <div className="text-sm text-gray-500">{customer.email}</div>
                </div>
            ),
        },
        {
            header: 'Nhóm',
            render: (customer: any) => (
                <span className={`px-3 py-1 rounded-full ${groupColors[customer.group] || 'bg-gray-100 text-gray-700'}`}>{customer.group}</span>
            ),
        },
        {
            header: 'Tần suất',
            field: 'frequency' as const,
        },
        {
            header: 'Chi tiêu TB/tháng',
            render: (customer: any) => (
                <span>{customer.spending.toLocaleString('vi-VN')}đ</span>
            ),
        },
        {
            header: 'Hành động',
            render: (customer: any) => (
                <>
                    <button className="text-blue-600 hover:text-blue-800 mr-3" onClick={() => handleViewCustomer(customer.id)}>
                        <i className="fa-solid fa-eye"></i>
                    </button>
                    <button className="text-gray-600 hover:text-gray-800 mr-3" onClick={() => handleEditCustomer(customer)}>
                        <i className="fa-solid fa-pen"></i>
                    </button>
                    <button className="text-red-600 hover:text-red-800" onClick={() => handleDeleteCustomer(customer.id)}>
                        <i className="fa-solid fa-trash"></i>
                    </button>
                </>
            ),
        },
    ];

    return (
        <div className="min-h-screen bg-gray-50">
            <HeaderAdmin user={user} handleLogout={handleLogout} />
            <SideBarAdmin />
            <ToastContainer position="top-right" autoClose={2000} />
            <main className="ml-64 pt-16">
                {showAddForm ? (
                    <NewCustomerFormAdmin
                        onCancel={() => { setShowAddForm(false); setEditCustomer(null); }}
                        onSubmit={handleSubmitNewCustomer}
                        initialData={editCustomer}
                    />
                ) : (
                    <>
                        {/* Page Header */}
                        <header id="header" className="bg-white shadow-sm">
                            <div className="px-6 py-4">
                                <div className="flex items-center justify-between">
                                    <h2 className="text-xl font-bold">Quản lý Khách hàng</h2>
                                    <div className="flex items-center space-x-4">
                                        <button
                                            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                                            onClick={handleAddCustomer}
                                        >
                                            <i className="fa-solid fa-plus mr-2"></i>
                                            Thêm khách hàng
                                        </button>
                                        <button
                                            className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                                            onClick={() => navigate('/admin/memberships')}
                                        >
                                            <i className="fa-solid fa-id-card mr-2"></i>
                                            Quản lý thẻ thành viên
                                        </button>
                                        <button
                                            className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                                            onClick={() => navigate('/admin/customer-care')}
                                        >
                                            <i className="fa-solid fa-heart mr-2"></i>
                                            Chăm sóc Khách hàng
                                        </button>
                                    </div>
                                </div>
                                <div className="flex justify-end mt-2">
                                    <div className="w-[170px]">
                                        <button
                                            className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 w-full"
                                        >
                                            <i className="fa-solid fa-file-export mr-2"></i>
                                            Xuất danh sách
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </header>

                        {/* Search and Filters */}
                        <div className="p-6">
                            <div className="grid grid-cols-4 gap-4">
                                <div className="col-span-2">
                                    <div className="relative">
                                        <i className="fa-solid fa-search absolute left-3 top-3 text-gray-400"></i>
                                        <input
                                            type="text"
                                            placeholder="Tìm kiếm theo tên, số điện thoại, email..."
                                            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                            value={searchText}
                                            onChange={e => { setSearchText(e.target.value); setCurrentPage(1); }}
                                        />
                                    </div>
                                </div>
                                <div>
                                    <select
                                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                        value={groupFilter}
                                        onChange={e => { setGroupFilter(e.target.value); setCurrentPage(1); }}
                                    >
                                        <option>Tất cả nhóm</option>
                                        <option>VIP</option>
                                        <option>Tiềm năng</option>
                                        <option>Thường</option>
                                    </select>
                                </div>
                                <div>
                                    <select
                                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                        value={sortOption}
                                        onChange={e => setSortOption(e.target.value)}
                                    >
                                        <option value="">Tất cả</option>
                                        <option>Chi tiêu cao nhất</option>
                                        <option>Tần suất sử dụng</option>
                                        <option>Mới nhất</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        {/* Customer Table */}
                        <div className="px-6">
                            <DataTable
                                columns={tableColumns}
                                data={paginatedCustomers}
                                totalItems={filteredCustomers.length}
                                currentPage={currentPage}
                                onPageChange={setCurrentPage}
                                itemsPerPage={itemsPerPage}
                            />
                        </div>
                    </>
                )}
            </main>
        </div>
    );
};

export default CustomerPageAdmin;
