import React, { useState, useEffect, ChangeEvent, FormEvent } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

interface CustomerForm {
  name: string;
  dob?: string;
  gender: string;
  phone: string;
  email: string;
  group: string;
  address: string;
  notes: string;
}

interface Errors {
  name?: string;
  phone?: string;
}

interface NewCustomerFormAdminProps {
  onCancel: () => void;
  onSubmit: (data: any) => void;
  initialData?: Partial<CustomerForm>;
}

const initialState: CustomerForm = {
  name: "",
  dob: "",
  gender: "Nam",
  phone: "",
  email: "",
  group: "Thường",
  address: "",
  notes: "",
};

const NewCustomerFormAdmin: React.FC<NewCustomerFormAdminProps> = ({ onCancel, onSubmit, initialData }) => {
  const [form, setForm] = useState<CustomerForm>(initialData ? { ...initialState, ...initialData } : initialState);
  const [errors, setErrors] = useState<Errors>({});

  useEffect(() => {
    if (initialData) {
      setForm({ ...initialState, ...initialData });
    } else {
      setForm(initialState);
    }
  }, [initialData]);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors: Errors = {};
    if (!form.name.trim()) newErrors.name = "Vui lòng nhập họ và tên";
    if (!form.phone.trim()) newErrors.phone = "Vui lòng nhập số điện thoại";
    return newErrors;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) {
      toast.error("Vui lòng kiểm tra lại thông tin!");
      return;
    }
    if (onSubmit) {
      let birthDate = form.dob;
      if (form.dob && form.dob.includes('-')) {
        const [year, month, day] = form.dob.split('-');
        birthDate = `${day.padStart(2, '0')}/${month.padStart(2, '0')}/${year}`;
      }
      const submitData = { ...form, birthDate };
      delete submitData.dob;
      onSubmit(submitData);
    }
  };

  return (
    <div className="max-w-4xl w-full mx-auto bg-white rounded-lg shadow-lg mb-8">
      {/* Top Header */}
      <header id="header" className="bg-white shadow-sm rounded-t-lg">
        <div className="flex items-center justify-between px-6 py-4">
          <h2 className="text-xl font-bold">
            {initialData ? 'Chỉnh sửa thông tin khách hàng' : 'Thêm Khách hàng mới'}
          </h2>
          <button 
            type="button" 
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg" 
            onClick={onCancel}
          >
            <i className="fa-solid fa-xmark mr-2"></i>
            Đóng
          </button>
        </div>
      </header>
      <div className="p-6">
        <form className="p-6" onSubmit={handleSubmit}>
          {/* Basic Information */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Thông tin cơ bản</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Họ và tên *</label>
                <input
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border ${errors.name ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500`}
                  required
                />
                {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Ngày sinh</label>
                <input
                  type="date"
                  name="dob"
                  value={form.dob}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  max={(() => {
                    const d = new Date();
                    d.setFullYear(d.getFullYear() - 16);
                    return d.toISOString().split('T')[0];
                  })()}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Số điện thoại *</label>
                <input
                  type="tel"
                  name="phone"
                  value={form.phone}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border ${errors.phone ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500`}
                  required
                />
                {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Giới tính</label>
                <select
                  name="gender"
                  value={form.gender}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="Nam">Nam</option>
                  <option value="Nữ">Nữ</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Additional Information */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Thông tin bổ sung</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Nhóm khách hàng</label>
                <select
                  name="group"
                  value={form.group}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option>Thường</option>
                  <option>Tiềm năng</option>
                  <option>VIP</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Địa chỉ</label>
                <input
                  type="text"
                  name="address"
                  value={form.address}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Notes */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Ghi chú</h3>
            <textarea
              name="notes"
              value={form.notes}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              rows={3}
            ></textarea>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-4 pt-6 border-t">
            <button
              type="button"
              onClick={onCancel}
              className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center"
            >
              <i className="fa-solid fa-check mr-2"></i>
              {initialData ? 'Cập nhật khách hàng' : 'Lưu khách hàng'}
            </button>
          </div>
        </form>
      </div>
      <ToastContainer position="top-right" autoClose={2000} />
    </div>
  );
};

export default NewCustomerFormAdmin;
