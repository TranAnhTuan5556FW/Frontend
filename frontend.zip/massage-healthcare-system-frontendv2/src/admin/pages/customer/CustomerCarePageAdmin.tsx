import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import '@fortawesome/fontawesome-free/css/all.min.css';

const CustomerCarePageAdmin: React.FC = () => {
    const navigate = useNavigate();
    // User info for header
    const [user] = useState({
        avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
        role: 'admin',
    });

    const handleLogout = () => {
        // TODO: Implement logout logic
        console.log('Logging out...');
    };

    const handleBack = () => {
        navigate('/admin/customers');
    };

    const handleSendNotification = () => {
        navigate('/admin/notifications');
    };

    return (
        <div className="min-h-screen bg-gray-50">
            <HeaderAdmin user={user} handleLogout={handleLogout} />
            <SideBarAdmin />
            <main className="ml-64 pt-16">
                {/* Top Header */}
                <header id="header" className="bg-white shadow-sm">
                    <div className="flex items-center justify-between px-6 py-4">
                        <div className="flex items-center space-x-4">
                            <button
                                type="button"
                                className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
                                onClick={handleBack}
                            >
                                <i className="fa-solid fa-arrow-left mr-2"></i>
                                Quay lại
                            </button>
                            <h2 className="text-xl font-bold">Chăm sóc Khách hàng</h2>
                        </div>
                        <div className="flex items-center space-x-4">
                            <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700" onClick={handleSendNotification}>
                                <i className="fa-solid fa-paper-plane mr-2"></i>
                                Gửi thông báo mới
                            </button>
                            <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                                <i className="fa-solid fa-clock-rotate-left mr-2"></i>
                                Lịch sử gửi
                            </button>
                        </div>
                    </div>
                </header>

                {/* Quick Stats */}
                <div id="quick-stats" className="grid grid-cols-4 gap-6 p-6">
                    <div className="bg-white p-6 rounded-lg shadow">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-500">Tổng thông báo</p>
                                <h3 className="text-2xl font-bold mt-1">1,234</h3>
                            </div>
                            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                                <i className="fa-solid fa-bell text-blue-600 text-xl"></i>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white p-6 rounded-lg shadow">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-500">Tỷ lệ phản hồi</p>
                                <h3 className="text-2xl font-bold mt-1">85%</h3>
                            </div>
                            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                                <i className="fa-solid fa-comments text-green-600 text-xl"></i>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white p-6 rounded-lg shadow">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-500">Sinh nhật tháng này</p>
                                <h3 className="text-2xl font-bold mt-1">28</h3>
                            </div>
                            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                                <i className="fa-solid fa-cake-candles text-purple-600 text-xl"></i>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white p-6 rounded-lg shadow">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-500">Đánh giá mới</p>
                                <h3 className="text-2xl font-bold mt-1">46</h3>
                            </div>
                            <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                                <i className="fa-solid fa-star text-yellow-600 text-xl"></i>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Notification History */}
                <div id="notification-history" className="px-6">
                    <div className="bg-white rounded-lg shadow">
                        <div className="p-6 border-b">
                            <h3 className="text-lg font-semibold">Lịch sử thông báo</h3>
                        </div>
                        <table className="w-full">
                            <thead>
                                <tr className="text-left border-b">
                                    <th className="px-6 py-4">Loại thông báo</th>
                                    <th className="px-6 py-4">Nội dung</th>
                                    <th className="px-6 py-4">Đối tượng</th>
                                    <th className="px-6 py-4">Thời gian gửi</th>
                                    <th className="px-6 py-4">Trạng thái</th>
                                    <th className="px-6 py-4">Tương tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className="border-b hover:bg-gray-50">
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full">Sinh nhật</span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="max-w-xs truncate">Chúc mừng sinh nhật và tặng voucher 20% cho dịch vụ massage</div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center space-x-2">
                                            <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg" className="w-8 h-8 rounded-full" alt="User" />
                                            <span>Nguyễn Thị Anh</span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">25/04/2025 09:30</td>
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full">Đã gửi</span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="text-green-600"><i className="fa-solid fa-check mr-1"></i> Đã xem</span>
                                    </td>
                                </tr>

                                <tr className="border-b hover:bg-gray-50">
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full">Nhắc lịch</span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="max-w-xs truncate">Nhắc nhở lịch hẹn massage vào ngày mai lúc 15:00</div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center space-x-2">
                                            <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg" className="w-8 h-8 rounded-full" alt="User" />
                                            <span>Trần Văn Bình</span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">25/04/2025 08:00</td>
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full">Đang gửi</span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="text-gray-600"><i className="fa-solid fa-clock mr-1"></i> Chờ</span>
                                    </td>
                                </tr>

                                <tr className="hover:bg-gray-50">
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full">Khảo sát</span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="max-w-xs truncate">Đánh giá trải nghiệm dịch vụ massage của bạn</div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center space-x-2">
                                            <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-5.jpg" className="w-8 h-8 rounded-full" alt="User" />
                                            <span>Lê Thị Cúc</span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">24/04/2025 17:45</td>
                                    <td className="px-6 py-4">
                                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full">Đã gửi</span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="text-blue-600"><i className="fa-solid fa-reply mr-1"></i> Đã phản hồi</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        {/* Pagination */}
                        <div className="px-6 py-4 flex items-center justify-between border-t">
                            <div className="text-gray-600">
                                Hiển thị 1-3 trong tổng số 45 thông báo
                            </div>
                            <div className="flex space-x-2">
                                <button className="px-3 py-1 border rounded hover:bg-gray-50">
                                    <i className="fa-solid fa-chevron-left"></i>
                                </button>
                                <button className="px-3 py-1 bg-blue-600 text-white rounded">1</button>
                                <button className="px-3 py-1 border rounded hover:bg-gray-50">2</button>
                                <button className="px-3 py-1 border rounded hover:bg-gray-50">3</button>
                                <button className="px-3 py-1 border rounded hover:bg-gray-50">
                                    <i className="fa-solid fa-chevron-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default CustomerCarePageAdmin;
