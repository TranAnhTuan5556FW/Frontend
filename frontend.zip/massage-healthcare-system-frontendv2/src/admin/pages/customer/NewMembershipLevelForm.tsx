import React, { useState, useEffect, ChangeEvent, FormEvent } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// Inline FormHeader component
const FormHeader = ({ title, onClose }: { title: string; onClose: () => void }) => (
  <div className="flex items-center justify-between px-6 py-4 border-b">
    <h2 className="text-xl font-bold">{title}</h2>
    <button type="button" className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg" onClick={onClose}>
      <i className="fa-solid fa-xmark mr-2"></i>Đóng
    </button>
  </div>
);

// Inline FormSection component
const FormSection = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="mb-8">
    <h3 className="text-lg font-semibold mb-4">{title}</h3>
    {children}
  </div>
);

interface MembershipLevelForm {
  name: string;
  code: string;
  minSpending: string;
  minFrequency: string;
  discount: string;
  pointMultiplier: string;
  duration: string;
  status: 'active' | 'inactive';
  activateNow: boolean;
}

interface Errors {
  name?: string;
  code?: string;
  minSpending?: string;
  minFrequency?: string;
  discount?: string;
  pointMultiplier?: string;
}

interface NewMembershipLevelFormProps {
  onCancel: () => void;
  onSubmit: (data: any) => void;
  initialData?: Partial<MembershipLevelForm>;
}

const initialState: MembershipLevelForm = {
  name: "",
  code: "",
  minSpending: "",
  minFrequency: "",
  discount: "",
  pointMultiplier: "",
  duration: "1 năm",
  status: "active",
  activateNow: true,
};

const NewMembershipLevelForm: React.FC<NewMembershipLevelFormProps> = ({ onCancel, onSubmit, initialData }) => {
  const [form, setForm] = useState<MembershipLevelForm>(initialData ? { ...initialState, ...initialData, activateNow: false } : initialState);
  const [errors, setErrors] = useState<Errors>({});

  useEffect(() => {
    if (initialData) {
      setForm({ ...initialState, ...initialData, activateNow: false });
    } else {
      setForm(initialState);
    }
  }, [initialData]);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === "checkbox" && e.target instanceof HTMLInputElement) {
      setForm((prev) => ({ ...prev, [name]: (e.target as HTMLInputElement).checked }));
    } else {
      setForm((prev) => ({ ...prev, [name]: value }));
    }
  };

  const validate = () => {
    const newErrors: Errors = {};
    if (!form.name.trim()) newErrors.name = "Vui lòng nhập tên cấp độ";
    if (!form.code.trim()) newErrors.code = "Vui lòng nhập mã cấp độ";
    if (!form.minSpending.trim()) newErrors.minSpending = "Vui lòng nhập chi tiêu tối thiểu";
    if (!form.minFrequency.trim()) newErrors.minFrequency = "Vui lòng nhập tần suất tối thiểu";
    if (!form.discount.trim()) newErrors.discount = "Vui lòng nhập tỷ lệ giảm giá";
    if (!form.pointMultiplier.trim()) newErrors.pointMultiplier = "Vui lòng nhập hệ số tích điểm";
    return newErrors;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) {
      toast.error("Vui lòng kiểm tra lại thông tin!");
      return;
    }
    if (onSubmit) {
      onSubmit(form);
    }
  };

  return (
    <div className="max-w-4xl w-full mx-auto bg-white rounded-lg shadow-lg mb-8">
      <FormHeader title={initialData ? 'Chỉnh sửa cấp độ thành viên' : 'Thêm cấp độ thành viên mới'} onClose={onCancel} />
      <div className="p-6">
        <form className="p-6" onSubmit={handleSubmit}>
          <FormSection title="Thông tin cơ bản">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tên cấp độ *</label>
                <input
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border ${errors.name ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500`}
                  placeholder="VD: Hạng Bạch Kim"
                  required
                />
                {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Mã cấp độ *</label>
                <input
                  type="text"
                  name="code"
                  value={form.code}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border ${errors.code ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500`}
                  placeholder="VD: PLATINUM"
                  required
                />
                {errors.code && <p className="text-red-500 text-xs mt-1">{errors.code}</p>}
              </div>
            </div>
          </FormSection>

          <FormSection title="Tiêu chí">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Chi tiêu tối thiểu (VNĐ/năm) *</label>
                <input
                  type="number"
                  name="minSpending"
                  value={form.minSpending}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border ${errors.minSpending ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500`}
                  placeholder="VD: 50000000"
                  required
                />
                {errors.minSpending && <p className="text-red-500 text-xs mt-1">{errors.minSpending}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tần suất tối thiểu (lần/tháng) *</label>
                <input
                  type="number"
                  name="minFrequency"
                  value={form.minFrequency}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border ${errors.minFrequency ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500`}
                  placeholder="VD: 4"
                  required
                />
                {errors.minFrequency && <p className="text-red-500 text-xs mt-1">{errors.minFrequency}</p>}
              </div>
            </div>
          </FormSection>

          <FormSection title="Ưu đãi">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tỷ lệ giảm giá (%)</label>
                <input type="number" name="discount" value={form.discount} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="VD: 20" required />
                {errors.discount && <p className="text-red-500 text-xs mt-1">{errors.discount}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Hệ số tích điểm</label>
                <input type="number" name="pointMultiplier" value={form.pointMultiplier} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="VD: 3" required />
                {errors.pointMultiplier && <p className="text-red-500 text-xs mt-1">{errors.pointMultiplier}</p>}
              </div>
            </div>
          </FormSection>

          <FormSection title="Trạng thái">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Trạng thái</label>
              <select
                name="status"
                value={form.status}
                onChange={handleChange}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="active">Đang hoạt động</option>
                <option value="inactive">Ngưng hoạt động</option>
              </select>
            </div>
          </FormSection>

          <FormSection title="Cài đặt bổ sung">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Thời hạn hiệu lực</label>
                <select
                  name="duration"
                  value={form.duration}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option>6 tháng</option>
                  <option>1 năm</option>
                  <option>2 năm</option>
                </select>
              </div>
            </div>
            {!initialData && (
              <div className="flex items-center space-x-2 mt-4">
                <input
                  type="checkbox"
                  name="activateNow"
                  checked={form.activateNow}
                  onChange={handleChange}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <label className="text-sm text-gray-700">Kích hoạt ngay sau khi tạo</label>
              </div>
            )}
          </FormSection>

          <div className="flex justify-end space-x-4 pt-6 border-t">
            <button
              type="button"
              onClick={onCancel}
              className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center"
            >
              <i className="fa-solid fa-check mr-2"></i>
              {initialData ? 'Cập nhật cấp độ' : 'Tạo cấp độ'}
            </button>
          </div>
        </form>
      </div>
      <ToastContainer position="top-right" autoClose={2000} />
    </div>
  );
};

export default NewMembershipLevelForm;
