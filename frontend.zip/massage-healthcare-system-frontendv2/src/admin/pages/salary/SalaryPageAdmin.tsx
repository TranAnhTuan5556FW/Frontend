import React from 'react';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { useNavigate } from 'react-router-dom';
import * as XLSX from 'xlsx';

// Interface cho dữ liệu lương
interface SalaryData {
  name: string;
  position: string;
  basicSalary: string;
  commission: string;
  bonus: string;
  totalSalary: string;
  status: string;
}

const FinancePageAdmin: React.FC = () => {
  const [user] = React.useState({
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    role: 'admin',
  });
  const navigate = useNavigate();

  // State cho chế độ chỉnh sửa
  const [editMode, setEditMode] = React.useState(false);
  // State cho dữ liệu lương và hoa hồng
  const [salaryConfig, setSalaryConfig] = React.useState({
    junior: '6,000,000đ',
    official: '8,000,000đ',
    senior: '12,000,000đ',
    basicService: '10%',
    premiumService: '15%',
    package: '20%'
  });
  // State để lưu giá trị tạm thời khi chỉnh sửa
  const [tempConfig, setTempConfig] = React.useState(salaryConfig);

  // Mock data cho bảng lương - trong thực tế sẽ lấy từ API
  const salaryData: SalaryData[] = [
    {
      name: "Nguyễn Thị Hoa",
      position: "Nhân viên cao cấp",
      basicSalary: "12,000,000đ",
      commission: "8,500,000đ",
      bonus: "2,000,000đ",
      totalSalary: "22,500,000đ",
      status: "Đã thanh toán"
    },
    {
      name: "Trần Văn Nam",
      position: "Nhân viên chính thức",
      basicSalary: "8,000,000đ",
      commission: "5,200,000đ",
      bonus: "1,000,000đ",
      totalSalary: "14,200,000đ",
      status: "Chờ duyệt"
    }
  ];

  // Khi nhấn chỉnh sửa
  const handleEdit = () => {
    setTempConfig(salaryConfig);
    setEditMode(true);
  };
  // Khi nhấn hủy
  const handleCancel = () => {
    setEditMode(false);
    setTempConfig(salaryConfig);
  };
  // Khi nhấn lưu
  const handleSave = () => {
    setSalaryConfig(tempConfig);
    setEditMode(false);
  };
  // Xử lý thay đổi input
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setTempConfig(prev => ({ ...prev, [name]: value }));
  };

  // Hàm xử lý xuất Excel
  const handleExportExcel = () => {
    // Chuẩn bị dữ liệu cho Excel
    const excelData = salaryData.map(item => ({
      'Họ và tên': item.name,
      'Chức vụ': item.position,
      'Lương cơ bản': item.basicSalary,
      'Hoa hồng': item.commission,
      'Thưởng': item.bonus,
      'Tổng thu nhập': item.totalSalary,
      'Trạng thái': item.status
    }));

    // Tạo workbook và worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(excelData);

    // Thêm worksheet vào workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Bảng lương');

    // Tạo tên file với tháng và năm hiện tại
    const date = new Date();
    const fileName = `Bang_luong_${date.getMonth() + 1}_${date.getFullYear()}.xlsx`;

    // Xuất file
    XLSX.writeFile(wb, fileName);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <HeaderAdmin user={user} />
      <SideBarAdmin />
      <main className="ml-64 pt-16">
        {/* Top Header */}
        <header id="header" className="bg-white shadow-sm">
          <div className="flex items-center justify-between px-6 py-4">
            <h2 className="text-xl font-bold">Quản lý Lương & Hoa hồng</h2>
            <div className="flex items-center space-x-4">
              <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700" onClick={() => navigate('/admin/salary/calculate')}>
                <i className="fa-solid fa-calculator mr-2"></i>
                Tính lương tháng này
              </button>
              <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50" onClick={handleExportExcel}>
                <i className="fa-solid fa-file-export mr-2"></i>
                Xuất bảng lương
              </button>
            </div>
          </div>
        </header>

        {/* Stats Cards */}
        <div id="stats-overview" className="grid grid-cols-4 gap-6 p-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <h3 className="text-gray-500">Tổng quỹ lương</h3>
              <i className="fa-solid fa-money-bill-wave text-green-500"></i>
            </div>
            <p className="text-2xl font-bold mt-2">125,000,000đ</p>
            <p className="text-sm text-gray-500 mt-2">Tháng 4/2025</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <h3 className="text-gray-500">Quỹ hoa hồng</h3>
              <i className="fa-solid fa-gift text-purple-500"></i>
            </div>
            <p className="text-2xl font-bold mt-2">45,000,000đ</p>
            <p className="text-sm text-gray-500 mt-2">Tháng 4/2025</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <h3 className="text-gray-500">Nhân viên xuất sắc</h3>
              <i className="fa-solid fa-trophy text-yellow-500"></i>
            </div>
            <p className="text-2xl font-bold mt-2">5 người</p>
            <p className="text-sm text-gray-500 mt-2">Đạt KPI tháng</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between">
              <h3 className="text-gray-500">Thưởng hiệu suất</h3>
              <i className="fa-solid fa-chart-line text-blue-500"></i>
            </div>
            <p className="text-2xl font-bold mt-2">15,000,000đ</p>
            <p className="text-sm text-gray-500 mt-2">Quỹ thưởng tháng</p>
          </div>
        </div>

        {/* Salary Configuration */}
        <div id="salary-config" className="px-6 mb-6">
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b flex items-center justify-between">
              <h3 className="text-lg font-bold">Cấu hình chính sách lương & hoa hồng</h3>
              {!editMode && (
                <button
                  className="ml-4 px-3 py-1 bg-yellow-400 text-white rounded hover:bg-yellow-500 flex items-center"
                  onClick={handleEdit}
                >
                  <i className="fa-solid fa-pen-to-square mr-2"></i>Chỉnh sửa
                </button>
              )}
              {editMode && (
                <div className="flex space-x-2 ml-4">
                  <button
                    className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700"
                    onClick={handleSave}
                  >
                    Lưu
                  </button>
                  <button
                    className="px-3 py-1 bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
                    onClick={handleCancel}
                  >
                    Hủy
                  </button>
                </div>
              )}
            </div>
            <div className="p-6 grid grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-4">Lương cơ bản theo cấp bậc</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Nhân viên mới</span>
                    <input
                      type="text"
                      name="junior"
                      value={editMode ? tempConfig.junior : salaryConfig.junior}
                      onChange={handleChange}
                      className="w-32 px-3 py-2 border rounded-lg"
                      readOnly={!editMode}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Nhân viên chính thức</span>
                    <input
                      type="text"
                      name="official"
                      value={editMode ? tempConfig.official : salaryConfig.official}
                      onChange={handleChange}
                      className="w-32 px-3 py-2 border rounded-lg"
                      readOnly={!editMode}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Nhân viên cao cấp</span>
                    <input
                      type="text"
                      name="senior"
                      value={editMode ? tempConfig.senior : salaryConfig.senior}
                      onChange={handleChange}
                      className="w-32 px-3 py-2 border rounded-lg"
                      readOnly={!editMode}
                    />
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-4">Chính sách hoa hồng</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Dịch vụ cơ bản</span>
                    <input
                      type="text"
                      name="basicService"
                      value={editMode ? tempConfig.basicService : salaryConfig.basicService}
                      onChange={handleChange}
                      className="w-32 px-3 py-2 border rounded-lg"
                      readOnly={!editMode}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Dịch vụ cao cấp</span>
                    <input
                      type="text"
                      name="premiumService"
                      value={editMode ? tempConfig.premiumService : salaryConfig.premiumService}
                      onChange={handleChange}
                      className="w-32 px-3 py-2 border rounded-lg"
                      readOnly={!editMode}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Gói liệu trình</span>
                    <input
                      type="text"
                      name="package"
                      value={editMode ? tempConfig.package : salaryConfig.package}
                      onChange={handleChange}
                      className="w-32 px-3 py-2 border rounded-lg"
                      readOnly={!editMode}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Salary Table */}
        <div id="salary-table" className="px-6">
          <div className="bg-white rounded-lg shadow">
            <table className="w-full">
              <thead>
                <tr className="text-left border-b">
                  <th className="px-6 py-4">Nhân viên</th>
                  <th className="px-6 py-4">Lương cơ bản</th>
                  <th className="px-6 py-4">Hoa hồng</th>
                  <th className="px-6 py-4">Thưởng</th>
                  <th className="px-6 py-4">Tổng thu nhập</th>
                  <th className="px-6 py-4">Trạng thái</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-3">
                      <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg" className="w-10 h-10 rounded-full" alt="Nguyễn Thị Hoa" />
                      <div>
                        <div className="font-medium">Nguyễn Thị Hoa</div>
                        <div className="text-sm text-gray-500">Nhân viên cao cấp</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">12,000,000đ</td>
                  <td className="px-6 py-4">8,500,000đ</td>
                  <td className="px-6 py-4">2,000,000đ</td>
                  <td className="px-6 py-4 font-bold">22,500,000đ</td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full">Đã thanh toán</span>
                  </td>
                </tr>
                <tr className="border-b hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-3">
                      <img src="https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg" className="w-10 h-10 rounded-full" alt="Trần Văn Nam" />
                      <div>
                        <div className="font-medium">Trần Văn Nam</div>
                        <div className="text-sm text-gray-500">Nhân viên chính thức</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">8,000,000đ</td>
                  <td className="px-6 py-4">5,200,000đ</td>
                  <td className="px-6 py-4">1,000,000đ</td>
                  <td className="px-6 py-4 font-bold">14,200,000đ</td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full">Chờ duyệt</span>
                  </td>
                </tr>
              </tbody>
            </table>
            {/* Pagination */}
            <div className="px-6 py-4 flex items-center justify-between border-t">
              <div className="text-gray-600">
                Hiển thị 1-2 trong tổng số 15 nhân viên
              </div>
              <div className="flex space-x-2">
                <button className="px-3 py-1 border rounded hover:bg-gray-50">
                  <i className="fa-solid fa-chevron-left"></i>
                </button>
                <button className="px-3 py-1 bg-blue-600 text-white rounded">1</button>
                <button className="px-3 py-1 border rounded hover:bg-gray-50">2</button>
                <button className="px-3 py-1 border rounded hover:bg-gray-50">3</button>
                <button className="px-3 py-1 border rounded hover:bg-gray-50">
                  <i className="fa-solid fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default FinancePageAdmin;
