import React from 'react';
import HeaderAdmin from '../../components/HeaderAdmin';
import SideBarAdmin from '../../components/SideBarAdmin';
import '@fortawesome/fontawesome-free/css/all.min.css';
import { useNavigate } from 'react-router-dom';

const CalculateMonthlySalaryPageAdmin: React.FC = () => {
  const [user] = React.useState({
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    role: 'admin',
  });
  const navigate = useNavigate();

  // State cho bộ lọc
  const [month, setMonth] = React.useState('Tháng 4/2025');
  const [employeeType, setEmployeeType] = React.useState('Tất cả nhân viên');
  const [status, setStatus] = React.useState('Tất cả trạng thái');

  // State cho bảng lương mẫu
  const [salaryRows, setSalaryRows] = React.useState([
    {
      id: 1,
      name: 'Nguyễn Thị Hoa',
      code: 'NV125',
      type: 'Cao cấp',
      avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-1.jpg',
      workDays: 26,
      baseSalary: '12,000,000đ',
      commission: '8,500,000đ',
      allowance: '1,000,000đ',
      bonus: '2,000,000đ',
      deduction: '500,000đ',
      net: '23,000,000đ',
    },
    {
      id: 2,
      name: 'Trần Văn Nam',
      code: 'NV126',
      type: 'Chính thức',
      avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
      workDays: 24,
      baseSalary: '8,000,000đ',
      commission: '5,200,000đ',
      allowance: '800,000đ',
      bonus: '1,000,000đ',
      deduction: '300,000đ',
      net: '14,700,000đ',
    },
  ]);

  // Xử lý thay đổi input trong bảng
  const handleInputChange = (id: number, field: string, value: string) => {
    setSalaryRows(rows =>
      rows.map(row =>
        row.id === id ? { ...row, [field]: value } : row
      )
    );
  };

  // Xử lý quay lại
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <HeaderAdmin user={user} />
      <SideBarAdmin />
      <main className="ml-64 pt-16 flex-1">
        {/* Top Header */}
        <header id="header" className="bg-white shadow-sm">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center space-x-4">
              <button
                type="button"
                className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
                onClick={handleBack}
              >
                <i className="fa-solid fa-arrow-left mr-2"></i>
                Quay lại
              </button>
              <h2 className="text-xl font-bold">Tính lương {month}</h2>
            </div>
            <div className="flex items-center space-x-4">
              <button className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                <i className="fa-solid fa-check mr-2"></i>
                Xác nhận & Lưu
              </button>
              <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                <i className="fa-solid fa-file-export mr-2"></i>
                Xuất Excel
              </button>
            </div>
          </div>
        </header>

        {/* Calculation Form */}
        <div id="calculation-form" className="p-6">
          <div className="bg-white rounded-lg shadow mb-6">
            <div className="p-6 border-b">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold">Thông tin tính lương</h3>
                <div className="flex items-center space-x-4">
                  <select className="px-4 py-2 border rounded-lg" value={month} onChange={e => setMonth(e.target.value)}>
                    <option>Tháng 4/2025</option>
                    <option>Tháng 3/2025</option>
                    <option>Tháng 2/2025</option>
                  </select>
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-lg">
                    Tính toán lại
                  </button>
                </div>
              </div>
            </div>
            {/* Employee Selection */}
            <div className="p-6 grid grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium mb-2">Chọn nhân viên</label>
                <select className="w-full px-4 py-2 border rounded-lg" value={employeeType} onChange={e => setEmployeeType(e.target.value)}>
                  <option>Tất cả nhân viên</option>
                  <option>Nhân viên cao cấp</option>
                  <option>Nhân viên chính thức</option>
                  <option>Nhân viên mới</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Trạng thái</label>
                <select className="w-full px-4 py-2 border rounded-lg" value={status} onChange={e => setStatus(e.target.value)}>
                  <option>Tất cả trạng thái</option>
                  <option>Đang làm việc</option>
                  <option>Tạm nghỉ</option>
                  <option>Đã nghỉ việc</option>
                </select>
              </div>
            </div>
          </div>

          {/* Detailed Calculation Table */}
          <div id="calculation-table" className="bg-white rounded-lg shadow">
            <table className="w-full">
              <thead>
                <tr className="text-left border-b">
                  <th className="px-6 py-4">Nhân viên</th>
                  <th className="px-6 py-4">Ngày công</th>
                  <th className="px-6 py-4">Lương cơ bản</th>
                  <th className="px-6 py-4">Hoa hồng</th>
                  <th className="px-6 py-4">Phụ cấp</th>
                  <th className="px-6 py-4">Thưởng</th>
                  <th className="px-6 py-4">Khấu trừ</th>
                  <th className="px-6 py-4">Thực lãnh</th>
                  <th className="px-6 py-4">Thao tác</th>
                </tr>
              </thead>
              <tbody>
                {salaryRows.map(row => (
                  <tr className="border-b hover:bg-gray-50" key={row.id}>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <img src={row.avatar} className="w-10 h-10 rounded-full" alt={row.name} />
                        <div>
                          <div className="font-medium">{row.name}</div>
                          <div className="text-sm text-gray-500">{row.code} - {row.type}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <input type="text" value={row.workDays} className="w-16 px-2 py-1 border rounded text-center" onChange={e => handleInputChange(row.id, 'workDays', e.target.value)} />
                    </td>
                    <td className="px-6 py-4">{row.baseSalary}</td>
                    <td className="px-6 py-4">{row.commission}</td>
                    <td className="px-6 py-4">
                      <input type="text" value={row.allowance} className="w-28 px-2 py-1 border rounded" onChange={e => handleInputChange(row.id, 'allowance', e.target.value)} />
                    </td>
                    <td className="px-6 py-4">
                      <input type="text" value={row.bonus} className="w-28 px-2 py-1 border rounded" onChange={e => handleInputChange(row.id, 'bonus', e.target.value)} />
                    </td>
                    <td className="px-6 py-4">
                      <input type="text" value={row.deduction} className="w-28 px-2 py-1 border rounded" onChange={e => handleInputChange(row.id, 'deduction', e.target.value)} />
                    </td>
                    <td className="px-6 py-4 font-bold text-green-600">{row.net}</td>
                    <td className="px-6 py-4">
                      <button className="text-blue-600 hover:text-blue-800">
                        <i className="fa-solid fa-pen-to-square"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-gray-50">
                <tr>
                  <td className="px-6 py-4 font-bold">Tổng cộng</td>
                  <td className="px-6 py-4">-</td>
                  <td className="px-6 py-4 font-bold">20,000,000đ</td>
                  <td className="px-6 py-4 font-bold">13,700,000đ</td>
                  <td className="px-6 py-4 font-bold">1,800,000đ</td>
                  <td className="px-6 py-4 font-bold">3,000,000đ</td>
                  <td className="px-6 py-4 font-bold">800,000đ</td>
                  <td className="px-6 py-4 font-bold text-green-600">37,700,000đ</td>
                  <td className="px-6 py-4">-</td>
                </tr>
              </tfoot>
            </table>
            {/* Pagination */}
            <div className="px-6 py-4 flex items-center justify-between border-t">
              <div className="text-gray-600">
                Hiển thị 1-2 trong tổng số 15 nhân viên
              </div>
              <div className="flex space-x-2">
                <button className="px-3 py-1 border rounded hover:bg-gray-50">
                  <i className="fa-solid fa-chevron-left"></i>
                </button>
                <button className="px-3 py-1 bg-blue-600 text-white rounded">1</button>
                <button className="px-3 py-1 border rounded hover:bg-gray-50">2</button>
                <button className="px-3 py-1 border rounded hover:bg-gray-50">3</button>
                <button className="px-3 py-1 border rounded hover:bg-gray-50">
                  <i className="fa-solid fa-chevron-right"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default CalculateMonthlySalaryPageAdmin;
