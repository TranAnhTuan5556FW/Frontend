import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import '@fortawesome/fontawesome-free/css/all.min.css';

const SideBarAdmin = () => {
  const location = useLocation();
  const [isFinanceOpen, setIsFinanceOpen] = useState(false);

  return (
    <aside id="sidebar" className="fixed left-0 top-16 bottom-0 w-64 bg-white shadow-lg">
      <nav className="h-full overflow-y-auto">
        <div className="px-4 py-4 space-y-2">
          <Link
            to="/admin"
            className={`flex items-center px-4 py-3 rounded-lg cursor-pointer ${location.pathname === '/admin' ? 'text-gray-700 bg-purple-100' : 'text-gray-600 hover:bg-purple-100'}`}
          >
            <i className="fa-solid fa-chart-line mr-3" />
            <span>Bảng Điều Khiển</span>
          </Link>

          <Link
            to="/admin/customers"
            className={`flex items-center px-4 py-3 rounded-lg cursor-pointer ${location.pathname.startsWith('/admin/customers') ? 'text-gray-700 bg-purple-100' : 'text-gray-600 hover:bg-purple-100'}`}
          >
            <i className="fa-solid fa-users mr-3" />
            <span>Khách Hàng</span>
          </Link>

          <Link
            to="/admin/appointments"
            className={`flex items-center px-4 py-3 rounded-lg cursor-pointer ${location.pathname === '/admin/appointments' ? 'text-gray-700 bg-purple-100' : 'text-gray-600 hover:bg-purple-100'}`}
          >
            <i className="fa-solid fa-calendar-check mr-3" />
            <span>Lịch Hẹn</span>
          </Link>

          <Link
            to="/admin/services"
            className={`flex items-center px-4 py-3 rounded-lg cursor-pointer ${location.pathname === '/admin/services' ? 'text-gray-700 bg-purple-100' : 'text-gray-600 hover:bg-purple-100'}`}
          >
            <i className="fa-solid fa-spa mr-3" />
            <span>Dịch Vụ</span>
          </Link>

          <Link
            to="/admin/employees"
            className={`flex items-center px-4 py-3 rounded-lg cursor-pointer ${location.pathname.startsWith('/admin/employees') ? 'text-gray-700 bg-purple-100' : 'text-gray-600 hover:bg-purple-100'}`}
          >
            <i className="fa-solid fa-user-tie mr-3" />
            <span>Nhân Viên</span>
          </Link>

          {/* Finance Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsFinanceOpen(!isFinanceOpen)}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-lg cursor-pointer ${
                location.pathname.includes('/admin/finance') || 
                location.pathname.includes('/admin/salary') || 
                location.pathname.includes('/admin/payment') || 
                location.pathname.includes('/admin/promotion')
                  ? 'text-gray-700 bg-purple-100' 
                  : 'text-gray-600 hover:bg-purple-100'
              }`}
            >
              <div className="flex items-center">
                <i className="fa-solid fa-money-bill-wave mr-3" />
                <span>Tài Chính</span>
              </div>
              <i className={`fa-solid fa-chevron-${isFinanceOpen ? 'up' : 'down'} ml-2`} />
            </button>
            {isFinanceOpen && (
              <div className="pl-8 mt-1 space-y-1">
                <Link
                  to="/admin/finance"
                  className={`flex items-center px-4 py-2 rounded-lg cursor-pointer ${location.pathname === '/admin/finance' ? 'text-gray-700 bg-purple-100' : 'text-gray-600 hover:bg-purple-100'}`}
                >
                  <i className="fa-solid fa-chart-pie mr-3" />
                  <span>Báo cáo Tài chính</span>
                </Link>
                <Link
                  to="/admin/salary"
                  className={`flex items-center px-4 py-2 rounded-lg cursor-pointer ${location.pathname === '/admin/salary' ? 'text-gray-700 bg-purple-100' : 'text-gray-600 hover:bg-purple-100'}`}
                >
                  <i className="fa-solid fa-coins mr-3" />
                  <span>Quản lý Lương & Hoa hồng</span>
                </Link>
                <Link
                  to="/admin/payment"
                  className={`flex items-center px-4 py-2 rounded-lg cursor-pointer ${location.pathname === '/admin/payment' ? 'text-gray-700 bg-purple-100' : 'text-gray-600 hover:bg-purple-100'}`}
                >
                  <i className="fa-solid fa-credit-card mr-3" />
                  <span>Thanh toán & Hóa đơn</span>
                </Link>
                <Link
                  to="/admin/promotions"
                  className={`flex items-center px-4 py-2 rounded-lg cursor-pointer ${location.pathname === '/admin/promotions' ? 'text-gray-700 bg-purple-100' : 'text-gray-600 hover:bg-purple-100'}`}
                >
                  <i className="fa-solid fa-tags mr-3" />
                  <span>Quản lý khuyến mãi</span>
                </Link>
              </div>
            )}
          </div>
        </div>
      </nav>
    </aside>
  );
};

export default SideBarAdmin; 