import React from "react";
import { useNavigate } from "react-router-dom";

interface User {
  avatar?: string;
  role?: string;
  name?: string;
}

interface HeaderAdminProps {
  user?: User;
  handleLogout?: () => void;
}

const HeaderAdmin: React.FC<HeaderAdminProps> = ({ user, handleLogout }) => {
  const navigate = useNavigate();

  const onLogout = () => {
    // Xóa thông tin người dùng khỏi localStorage
    localStorage.removeItem('user');
    localStorage.removeItem('permissions');

    // Gọi hàm handleLogout từ props nếu có
    if (handleLogout) {
      handleLogout();
    }

    // Chuyển hướng về trang chủ
    navigate('/');
  };

  return (
    <header id="header" className="bg-white border-b border-gray-200 fixed w-full z-50 h-16">
      <div className="px-6 py-4 flex items-center justify-between h-full">
        <div className="flex items-center space-x-4">
          <h1 className="text-xl font-semibold text-gray-800">
            Hệ Thống Quản Lý Spa
          </h1>
        </div>
        <div className="flex items-center space-x-4">
          <button className="p-2 text-gray-600 hover:text-gray-800">
            <i className="fa-regular fa-bell" />
          </button>
          <button className="p-2 text-gray-600 hover:text-gray-800">
            <i className="fa-regular fa-envelope" />
          </button>
          <div className="flex items-center space-x-2">
            <img
              src={user?.avatar || "https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg"}
              className="w-8 h-8 rounded-full"
              alt="Người Dùng"
            />
            <span className="text-sm font-medium">{user?.role === 'admin' ? `${user?.name ? user.name + ' - ' : ''}Quản Trị Viên` : 'Người Dùng'}</span>
            <button
              onClick={onLogout}
              className="ml-3 px-3 py-1 text-sm text-red-600 hover:text-red-800 hover:bg-red-50 rounded-md transition-colors"
            >
              <i className="fa-solid fa-sign-out-alt mr-1"></i>
              Đăng xuất
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default HeaderAdmin; 