import React from 'react';

interface DataTableColumn<T> {
  header: string;
  field?: keyof T;
  render?: (item: T) => React.ReactNode;
}

interface DataTableProps<T> {
  columns: DataTableColumn<T>[];
  data: T[];
  totalItems: number;
  currentPage?: number;
  onPageChange: (page: number) => void;
  itemsPerPage?: number;
}

function DataTable<T = any>({
  columns,
  data,
  totalItems,
  currentPage = 1,
  onPageChange,
  itemsPerPage = 10,
}: DataTableProps<T>) {
  return (
    <div className="bg-white rounded-lg shadow">
      <table className="w-full">
        <thead>
          <tr className="text-left border-b">
            {columns.map((column, index) => (
              <th key={index} className="px-6 py-4">{column.header}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((item, rowIndex) => (
            <tr key={rowIndex} className="border-b hover:bg-gray-50">
              {columns.map((column, colIndex) => (
                <td key={colIndex} className="px-6 py-4">
                  {column.render
                    ? column.render(item)
                    : column.field
                      ? String(item[column.field] ?? '')
                      : ''}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination */}
      <div className="px-6 py-4 flex items-center justify-between border-t">
        <div className="text-gray-600">
          Hiển thị {(currentPage - 1) * itemsPerPage + 1}-{Math.min(currentPage * itemsPerPage, totalItems)} trong tổng số {totalItems} kết quả
        </div>
        <div className="flex space-x-2">
          <button 
            className="px-3 py-1 border rounded hover:bg-gray-50"
            onClick={() => onPageChange(currentPage - 1)}
            disabled={currentPage === 1}
          >
            <i className="fa-solid fa-chevron-left"></i>
          </button>
          {[...Array(Math.ceil(totalItems / itemsPerPage))].map((_, index) => (
            <button
              key={index}
              className={`px-3 py-1 ${currentPage === index + 1 ? 'bg-blue-600 text-white' : 'border'} rounded hover:bg-gray-50`}
              onClick={() => onPageChange(index + 1)}
            >
              {index + 1}
            </button>
          ))}
          <button 
            className="px-3 py-1 border rounded hover:bg-gray-50"
            onClick={() => onPageChange(currentPage + 1)}
            disabled={currentPage === Math.ceil(totalItems / itemsPerPage)}
          >
            <i className="fa-solid fa-chevron-right"></i>
          </button>
        </div>
      </div>
    </div>
  );
}

export default DataTable; 