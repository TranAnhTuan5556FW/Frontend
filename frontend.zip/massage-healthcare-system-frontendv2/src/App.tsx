import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePageCustomer from './customer/pages/homepage/HomePageCustomer';
import AuthCustomer from './auth/AuthCustomer';
import AdminDashboard from './admin/pages/AdminDashboard';
import ProtectedRoute from './routes/ProtectedRoute';
import ServicePageCustomer from './customer/pages/service/ServicePageCustomer';
import IndividualServiceDetalPageCustomer from './customer/pages/service/IndividualServiceDetalPageCustomer';
import BookingCustomerPage from './customer/pages/booking/BookingCustomerPage';
import ConfirmBookingPage from './customer/pages/booking/ConfirmBookingPage';
import AdminRegistration from './auth/AdminRegistration';
import PackageServiceDetailCustomerPage from './customer/pages/service/PackageServiceDetailCustomerPage';
import ProfilePageCustomer from './customer/pages/profile/ProfilePageCustomer';
import CustomerPageAdmin from './admin/pages/customer/CustomerPageAdmin';
import CustomerProfilePageAdmin from './admin/pages/customer/CustomerProfilePageAdmin';
import MembershipPageAdmin from './admin/pages/customer/MembershipPageAdmin';
import EmployeePageAdmin from './admin/pages/employee/EmployeePageAdmin';
import EmployeeProfilePageAdmin from './admin/pages/employee/EmployeeProfilePageAdmin';
import AppointmentsPageAdmin from './admin/pages/appointment/AppointmentsPageAdmin';
import ReminderPageAdmin from './admin/pages/appointment/ReminderPageAdmin';
import ServicesPageAdmin from './admin/pages/service/ServicesPageAdmin';
import ServiceDetailPageAdmin from './admin/pages/service/ServiceDetailPageAdmin';
import CustomerCarePageAdmin from './admin/pages/customer/CustomerCarePageAdmin';
import PackagesServicePageAdmin from './admin/pages/service/PackagesServicePageAdmin';
import WorkSchedulePage from './admin/pages/employee/WorkSchedulePage';
import PromotionPageAdmin from './admin/pages/promotion/PromotionPageAdmin';
import PromotionDetailPageAdmin from './admin/pages/promotion/PromotionDetailPageAdmin';
import SalaryPageAdmin from './admin/pages/salary/SalaryPageAdmin';
import FinancePageAdmin from './admin/pages/finance/FinancePageAdmin';
import PaymentPageAdmin from './admin/pages/payment/PaymentPageAdmin';
import NotificationsPageAdmin from './admin/pages/customer/NotificationsPageAdmin';
import ContactPageCustomer from './customer/pages/contact/ContactPageCustomer';
import MembershipRewardsCustomer from './customer/pages/profile/MembershipRewardsCustomer';
import AboutPageCustomer from './customer/pages/about/AboutPageCustomer';
import ReviewsCustomerPage from './customer/pages/review/ReviewsCustomerPage';
import BookingHistoryCustomerPage from './customer/pages/appointment/BookingHistoryCustomerPage';
import AppointmentCustomerPage from './customer/pages/appointment/AppointmentCustomerPage';
import AppointmentDetailCustomerPage from './customer/pages/appointment/AppointmentDetailCustomerPage';
import OfferCustomerPage from './customer/pages/offer/OfferCustomerPage';
import EmployeeDashboardPage from './employee/pages/EmployeeDashboardPage';
import ScheduleEmployeePage from './employee/pages/appointment/ScheduleEmployeePage';
import AppointmentDetails from './employee/pages/appointment/AppointmentDetails';
import EmployeeProfilePage from './employee/pages/profile/EmployeeProfilePage';
import SalaryEmployeePage from './employee/pages/salary/SalaryEmployeePage';
import AppointmentsDetailPageAdmin from './admin/pages/appointment/AppointmentsDetailPageAdmin';
import PackagesServiceDetailPageAdmin from './admin/pages/service/PackagesServiceDetailPageAdmin';
import InvoiceDetailsPageAdmin from './admin/pages/payment/InvoiceDetailsPageAdmin';
import SendManualReminders from './admin/pages/appointment/SendManualReminders';
import CalculateMonthlySalaryPageAdmin from './admin/pages/salary/CalculateMonthlySalaryPageAdmin';
import InvoicePageCustomer from './customer/pages/checkout/InvoicePageCustomer';
import CheckoutPageCustomer from './customer/pages/checkout/CheckoutPageCustomer';
import ConfirmCheckoutPageCustomer from './customer/pages/checkout/ConfirmCheckoutPageCustomer';
import InvoiceDetailPageCustomer from './customer/pages/checkout/InvoiceDetailPageCustomer';


function App() {
  return (
    <Router>
      <Routes>
        <Route 
          path="/" 
          element={
            <ProtectedRoute allowedRoles={['customer', 'employee']}>
              <HomePageCustomer />
            </ProtectedRoute>
          } 
        />
        <Route path="/auth" element={<AuthCustomer />} />
        <Route 
          path="/services" 
          element={<ServicePageCustomer />} 
        />
        <Route 
          path="/services/:serviceId" 
          element={<IndividualServiceDetalPageCustomer />} 
        />
        <Route 
          path="/packages/:packageId" 
          element={<PackageServiceDetailCustomerPage />} 
        />
        <Route 
          path="/booking/:id" 
          element={<BookingCustomerPage />} 
        />
        <Route 
          path="/confirmation" 
          element={<ConfirmBookingPage />} 
        />
        <Route 
          path="/customer/profile" 
          element={
            <ProtectedRoute allowedRoles={['customer']}>
              <ProfilePageCustomer />
            </ProtectedRoute>
          } 
        />
        <Route path="/admin/register" element={<AdminRegistration />} />
        <Route 
          path="/admin/*" 
          element={
            <ProtectedRoute allowedRoles={['admin']}>
              <AdminDashboard />
            </ProtectedRoute>
          } 
        />
        <Route path="/admin/customers" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <CustomerPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/customers/:id" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <CustomerProfilePageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/appointments" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <AppointmentsPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/appointments/:id" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <AppointmentsDetailPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/reminders" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <ReminderPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/memberships" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <MembershipPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/employees" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <EmployeePageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/employees/:id" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <EmployeeProfilePageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/services" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <ServicesPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/services/:id" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <ServiceDetailPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/packages" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <PackagesServicePageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/packages/:id" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <PackagesServiceDetailPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/customer-care" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <CustomerCarePageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/schedules" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <WorkSchedulePage />
          </ProtectedRoute>
        } />
        <Route path="/admin/promotions" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <PromotionPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/promotions/:id" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <PromotionDetailPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/salary" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <SalaryPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/salary/calculate" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <CalculateMonthlySalaryPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/finance" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <FinancePageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/payment" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <PaymentPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/notifications" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <NotificationsPageAdmin />
          </ProtectedRoute>
        } />
        <Route 
          path="/contact" 
          element={<ContactPageCustomer />} 
        />
        <Route 
          path="/customer/membership-rewards" 
          element={
            <ProtectedRoute allowedRoles={['customer']}>
              <MembershipRewardsCustomer />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/about" 
          element={<AboutPageCustomer />} 
        />
        <Route 
          path="/reviews" 
          element={<ReviewsCustomerPage />} 
        />
        <Route 
          path="/customer/booking-history" 
          element={
            <ProtectedRoute allowedRoles={['customer']}>
              <BookingHistoryCustomerPage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/customer/appointments" 
          element={
            <ProtectedRoute allowedRoles={['customer']}>
              <AppointmentCustomerPage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/customer/appointments/:id" 
          element={
            <ProtectedRoute allowedRoles={['customer']}>
              <AppointmentDetailCustomerPage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/offer" 
          element={<OfferCustomerPage />} 
        />
        <Route 
          path="/employee/*" 
          element={
            <ProtectedRoute allowedRoles={['employee']}>
              <EmployeeDashboardPage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/employee/schedule" 
          element={
            <ProtectedRoute allowedRoles={['employee']}>
              <ScheduleEmployeePage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/employee/appointments/:id" 
          element={
            <ProtectedRoute allowedRoles={['employee']}>
              <AppointmentDetails />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/employee/profile" 
          element={
            <ProtectedRoute allowedRoles={['employee']}>
              <EmployeeProfilePage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/employee/profile/salary" 
          element={
            <ProtectedRoute allowedRoles={['employee']}>
              <SalaryEmployeePage />
            </ProtectedRoute>
          } 
        />
        <Route path="/admin/invoices/:id" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <InvoiceDetailsPageAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/send-manual-reminder" element={
          <ProtectedRoute allowedRoles={['admin']}>
            <SendManualReminders />
          </ProtectedRoute>
        } />
        <Route 
          path="/customer/billing" 
          element={
            <ProtectedRoute allowedRoles={['customer']}>
              <InvoicePageCustomer />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/customer/billing/:id" 
          element={
            <ProtectedRoute allowedRoles={['customer']}>
              <InvoiceDetailPageCustomer />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/customer/checkout" 
          element={
            <ProtectedRoute allowedRoles={['customer']}>
              <CheckoutPageCustomer />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/customer/checkout/confirmation" 
          element={
            <ProtectedRoute allowedRoles={['customer']}>
              <ConfirmCheckoutPageCustomer />
            </ProtectedRoute>
          } 
        />
      </Routes>
    </Router>
  );
}

export default App;
