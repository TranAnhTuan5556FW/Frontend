import React, { useState, useRef } from "react";
import HeaderEmployee from "../../componets/HeaderEmployee";
import SideBarEmployee from "../../componets/SideBarEmployee";
import { validatePassword } from '../../../data/authData';
import { motion, AnimatePresence } from 'framer-motion';

const EmployeeProfilePage: React.FC = () => {
  const [isEditing, setIsEditing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [passwordFields, setPasswordFields] = useState({
    oldPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [passwordError, setPasswordError] = useState<string>('');
  const [passwordSuccess, setPasswordSuccess] = useState<string>('');
  const [avatarError, setAvatarError] = useState<string>('');

  const [userInfo, setUserInfo] = useState({
    email: 'nam.nguyen@example.com',
    fullName: 'Nguyễn Văn Nam',
    phoneNumber: '0901 234 567',
    avatar: 'https://storage.googleapis.com/uxpilot-auth.appspot.com/avatars/avatar-2.jpg',
    role: 'Chuyên gia tạo mẫu tóc & Làm đẹp',
    skills: ['Tạo mẫu tóc', 'Nhuộm màu', 'Massage']
  });

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};
    
    // Validate email
    if (!/\S+@\S+\.\S+/.test(userInfo.email)) {
      newErrors.email = "Email không hợp lệ";
    }

    // Validate phone number
    const phoneRegex = /(84|0[3|5|7|8|9])+([0-9]{8})\b/;
    if (!phoneRegex.test(userInfo.phoneNumber)) {
      newErrors.phoneNumber = "Số điện thoại không hợp lệ";
    }

    // Validate name
    if (!userInfo.fullName.trim()) {
      newErrors.fullName = "Họ và tên không được để trống";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleEditProfile = () => {
    setIsEditing(true);
  };

  const handleSaveProfile = () => {
    if (!validateForm()) {
      return;
    }
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setErrors({});
  };

  const handleChangePassword = () => {
    setShowChangePassword(true);
    setPasswordFields({ oldPassword: '', newPassword: '', confirmPassword: '' });
    setPasswordError('');
    setPasswordSuccess('');
  };

  const handlePasswordFieldChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordFields(prev => ({ ...prev, [name]: value }));
    setPasswordError('');
    setPasswordSuccess('');
  };

  const handleCloseChangePassword = () => {
    setShowChangePassword(false);
    setPasswordFields({ oldPassword: '', newPassword: '', confirmPassword: '' });
    setPasswordError('');
    setPasswordSuccess('');
  };

  const handleSubmitChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    if (!passwordFields.oldPassword || !passwordFields.newPassword || !passwordFields.confirmPassword) {
      setPasswordError('Vui lòng nhập đầy đủ các trường');
      return;
    }

    // Kiểm tra độ mạnh mật khẩu mới
    const passwordValidation = validatePassword(passwordFields.newPassword);
    if (!passwordValidation.isValid) {
      setPasswordError(passwordValidation.message);
      return;
    }

    if (passwordFields.newPassword !== passwordFields.confirmPassword) {
      setPasswordError('Mật khẩu xác nhận không khớp');
      return;
    }

    setPasswordSuccess('Đổi mật khẩu thành công!');
    setTimeout(() => {
      setShowChangePassword(false);
    }, 1500);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setUserInfo(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear error when user types
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleAvatarClick = () => {
    if (isEditing && fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setAvatarError('');
    if (file) {
      // Kiểm tra loại file
      const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
      if (!allowedTypes.includes(file.type)) {
        setAvatarError('Chỉ cho phép các định dạng ảnh JPG, PNG, GIF, WEBP.');
        return;
      }
      // Kiểm tra kích thước file (20MB)
      const maxSize = 20 * 1024 * 1024;
      if (file.size > maxSize) {
        setAvatarError('Kích thước ảnh tối đa là 20MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setUserInfo(prev => ({
          ...prev,
          avatar: reader.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <HeaderEmployee />
      <SideBarEmployee />
      <div className="ml-0 md:ml-64 pt-16">
        <header id="profile-header" className="bg-white shadow-sm mb-6">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center space-x-4">
              <span className="text-2xl font-semibold text-gray-800">Hồ sơ của tôi</span>
            </div>
          </div>
        </header>
      </div>
      <main className="bg-gray-50 min-h-[calc(100vh-70px)] ml-0 md:ml-64 p-8 pt-0">
        <div id="employee-profile" className="min-h-[100vh] bg-gray-50">
          <div className="p-6">
            <div className="max-w-5xl mx-auto">
              {/* Profile Header */}
              <motion.section
                id="profile-overview"
                className="mb-12"
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="bg-white rounded-xl shadow-lg p-8">
                  <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
                    <motion.div
                      className="relative"
                      whileHover={isEditing ? { scale: 1.05 } : {}}
                      whileTap={isEditing ? { scale: 0.97 } : {}}
                      transition={{ type: 'spring', stiffness: 300 }}
                    >
                      <motion.img
                        src={userInfo.avatar}
                        alt="User Profile"
                        className={`w-24 h-24 rounded-full object-cover ${isEditing ? 'cursor-pointer hover:opacity-80' : ''}`}
                        onClick={handleAvatarClick}
                        whileHover={isEditing ? { scale: 1.08, opacity: 0.85 } : {}}
                        transition={{ type: 'spring', stiffness: 300 }}
                      />
                      {isEditing && (
                        <motion.div
                          className="absolute inset-0 flex items-center justify-center rounded-full bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-200 cursor-pointer"
                          onClick={handleAvatarClick}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                        >
                          <span className="text-white opacity-0 hover:opacity-100">Thay đổi</span>
                        </motion.div>
                      )}
                      <input
                        type="file"
                        ref={fileInputRef}
                        className="hidden"
                        accept="image/*"
                        onChange={handleAvatarChange}
                      />
                      {avatarError && (
                        <p className="text-red-500 text-sm mt-2">{avatarError}</p>
                      )}
                    </motion.div>
                    <div className="flex-1">
                      <h2 className="text-3xl font-bold text-gray-800 mb-2">
                        {userInfo.fullName}
                      </h2>
                      <p className="text-gray-500 mb-4">{userInfo.role}</p>
                      <div className="flex gap-4">
                        {!isEditing ? (
                          <motion.button
                            className="px-6 py-2 bg-[#008080] text-white rounded-lg hover:bg-[#006666]"
                            onClick={handleEditProfile}
                            whileTap={{ scale: 0.96 }}
                            whileHover={{ scale: 1.04 }}
                            transition={{ type: 'spring', stiffness: 300 }}
                          >
                            Chỉnh Sửa Thông Tin
                          </motion.button>
                        ) : (
                          <div className="flex gap-4">
                            <motion.button
                              className="px-6 py-2 bg-[#008080] text-white rounded-lg hover:bg-[#006666]"
                              onClick={handleSaveProfile}
                              whileTap={{ scale: 0.96 }}
                              whileHover={{ scale: 1.04 }}
                              transition={{ type: 'spring', stiffness: 300 }}
                            >
                              Lưu Thông Tin
                            </motion.button>
                            <motion.button
                              className="px-6 py-2 border border-[#008080] text-[#008080] rounded-lg hover:bg-[#008080] hover:text-white"
                              onClick={handleCancelEdit}
                              whileTap={{ scale: 0.96 }}
                              whileHover={{ scale: 1.04 }}
                              transition={{ type: 'spring', stiffness: 300 }}
                            >
                              Hủy
                            </motion.button>
                          </div>
                        )}
                        <motion.button
                          className="px-6 py-2 border border-[#008080] text-[#008080] rounded-lg hover:bg-[#008080] hover:text-white"
                          onClick={handleChangePassword}
                          whileTap={{ scale: 0.96 }}
                          whileHover={{ scale: 1.04 }}
                          transition={{ type: 'spring', stiffness: 300 }}
                        >
                          Đổi Mật Khẩu
                        </motion.button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.section>

              {/* Personal Information */}
              <motion.section
                id="personal-info"
                className="bg-white rounded-xl shadow-lg p-8"
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.2 }}
              >
                <h3 className="text-lg font-semibold mb-4">Thông tin cá nhân</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm text-gray-600 mb-1">Họ và tên</label>
                      <input 
                        type="text" 
                        name="fullName"
                        value={userInfo.fullName}
                        onChange={handleInputChange}
                        disabled={!isEditing}
                        className={`w-full px-4 py-2 border ${
                          errors.fullName ? 'border-red-500' : 'border-gray-300'
                        } rounded-lg focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none ${
                          !isEditing ? 'bg-gray-100' : ''
                        }`}
                      />
                      {errors.fullName && (
                        <p className="mt-1 text-sm text-red-500">{errors.fullName}</p>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm text-gray-600 mb-1">Số điện thoại</label>
                      <input 
                        type="tel" 
                        name="phoneNumber"
                        value={userInfo.phoneNumber}
                        onChange={handleInputChange}
                        disabled={!isEditing}
                        className={`w-full px-4 py-2 border ${
                          errors.phoneNumber ? 'border-red-500' : 'border-gray-300'
                        } rounded-lg focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none ${
                          !isEditing ? 'bg-gray-100' : ''
                        }`}
                      />
                      {errors.phoneNumber && (
                        <p className="mt-1 text-sm text-red-500">{errors.phoneNumber}</p>
                      )}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">Email</label>
                    <input 
                      type="email" 
                      name="email"
                      value={userInfo.email}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                      className={`w-full px-4 py-2 border ${
                        errors.email ? 'border-red-500' : 'border-gray-300'
                      } rounded-lg focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none ${
                        !isEditing ? 'bg-gray-100' : ''
                      }`}
                    />
                    {errors.email && (
                      <p className="mt-1 text-sm text-red-500">{errors.email}</p>
                    )}
                  </div>
                </div>
              </motion.section>

              {/* Skills Section */}
              <motion.section
                id="skills"
                className="bg-white rounded-xl shadow-lg p-8 mt-6"
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.3 }}
              >
                <h3 className="text-lg font-semibold mb-4">Kỹ năng</h3>
                <div className="flex flex-wrap gap-2">
                  {userInfo.skills.map((skill, index) => (
                    <span key={index} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">
                      {skill}
                    </span>
                  ))}
                </div>
              </motion.section>
            </div>
          </div>
        </div>
      </main>

      {/* Modal đổi mật khẩu */}
      <AnimatePresence>
        {showChangePassword && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="bg-white rounded-xl shadow-lg p-8 w-full max-w-md relative"
              initial={{ scale: 0.8, opacity: 0, y: 60 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.8, opacity: 0, y: 60 }}
              transition={{ duration: 0.3 }}
            >
              <button className="absolute top-3 right-3 text-gray-400 hover:text-gray-700" onClick={handleCloseChangePassword}>
                <i className="fa-solid fa-xmark text-2xl"></i>
              </button>
              <h2 className="text-2xl font-bold mb-6 text-gray-800 text-center">Đổi Mật Khẩu</h2>
              <form onSubmit={handleSubmitChangePassword} className="space-y-4">
                <div>
                  <label className="block text-gray-600 mb-2">Mật khẩu cũ</label>
                  <input
                    type="password"
                    name="oldPassword"
                    value={passwordFields.oldPassword}
                    onChange={handlePasswordFieldChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none"
                    autoComplete="current-password"
                  />
                </div>
                <div>
                  <label className="block text-gray-600 mb-2">Mật khẩu mới</label>
                  <input
                    type="password"
                    name="newPassword"
                    value={passwordFields.newPassword}
                    onChange={handlePasswordFieldChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none"
                    autoComplete="new-password"
                  />
                </div>
                <div>
                  <label className="block text-gray-600 mb-2">Xác nhận mật khẩu mới</label>
                  <input
                    type="password"
                    name="confirmPassword"
                    value={passwordFields.confirmPassword}
                    onChange={handlePasswordFieldChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#008080] focus:ring-1 focus:ring-[#008080] outline-none"
                    autoComplete="new-password"
                  />
                </div>
                {passwordError && <p className="text-red-500 text-sm">{passwordError}</p>}
                {passwordSuccess && <p className="text-green-600 text-sm">{passwordSuccess}</p>}
                <button
                  type="submit"
                  className="w-full px-6 py-2 bg-[#008080] text-white rounded-lg hover:bg-[#006666]"
                >
                  Đổi Mật Khẩu
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default EmployeeProfilePage;
