import React, { useState } from "react";
import HeaderEmployee from "../../componets/HeaderEmployee";
import SideBarEmployee from "../../componets/SideBarEmployee";
import { useNavigate, useParams } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft } from "@fortawesome/free-solid-svg-icons";
import { getAppointmentById } from "../../../data/appointmentsData";

const AppointmentDetails: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const appointment = getAppointmentById(Number(id));
  const handleBackClick = () => navigate(-1);

  // State cho radio button trạng thái
  const [status, setStatus] = useState<string>(appointment?.adminStatus || "confirmed");
  const statusOptions = [
    { value: "confirmed", label: "Đã xác nhận", color: "blue" },
    { value: "in_progress", label: "Đang thực hiện", color: "yellow" },
    { value: "completed", label: "Hoàn thành", color: "green" },
    { value: "absent", label: "Vắng mặt", color: "red" },
  ];

  if (!appointment) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-lg text-gray-600">Không tìm thấy lịch hẹn.</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <HeaderEmployee />
      <SideBarEmployee />
      {/* Top Header - move outside main for flush top */}
      <div className="ml-0 md:ml-64 pt-16">
        <header id="profile-header" className="bg-white shadow-sm rounded-xl mb-6">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center space-x-4">
              <button
                type="button"
                className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-50 border border-gray-300 rounded-lg"
                onClick={handleBackClick}
              >
                <FontAwesomeIcon icon={faArrowLeft} className="mr-2" />
                Quay lại
              </button>
              <h2 className="text-xl font-bold">Chi tiết lịch hẹn</h2>
            </div>
          </div>
        </header>
      </div>
      <main className="bg-gray-50 ml-0 md:ml-64 p-8 pt-0">
        <div className="p-6">
          <div className="max-w-4xl mx-auto">
            {/* Appointment Info Card */}
            <div id="appointment-info" className="bg-white rounded-xl shadow-sm p-6 mb-6">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-gray-800">{appointment.service}</h2>
                  <p className="text-gray-500 mt-1">Mã lịch hẹn #{appointment.id}</p>
                </div>
                <div id="appointment-status" className="px-4 py-2 bg-blue-100 text-blue-800 rounded-lg">
                  {statusOptions.find(opt => opt.value === appointment.adminStatus)?.label || "Đã xác nhận"}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-500">Khách hàng</label>
                    <div className="flex items-center mt-1 space-x-3">
                      <img src={appointment.customerAvatar} className="w-8 h-8 rounded-full" alt="Customer" />
                      <span className="font-medium">{appointment.customerName}</span>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-gray-500">Dịch vụ</label>
                    <p className="font-medium mt-1">{appointment.service}</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-500">Ngày & Giờ</label>
                    <p className="font-medium mt-1">{appointment.date} - {appointment.time}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-500">Thời lượng</label>
                    <p className="font-medium mt-1">{appointment.duration} phút</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-500">Ghi chú quản lý</label>
                    <p className="font-medium mt-1">{appointment.notes}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Status Update Section */}
            <div id="status-update" className="bg-white rounded-xl shadow-sm p-6 mb-6">
              <h3 className="text-lg font-semibold mb-4">Cập nhật trạng thái</h3>
              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
                {statusOptions.map((option) => (
                  <label
                    key={option.value}
                    className={`flex-1 flex items-center cursor-pointer py-2 px-4 rounded-lg border transition-colors
                      ${status === option.value
                        ? `bg-${option.color}-100 text-${option.color}-800 border-${option.color}-400`
                        : "bg-gray-50 text-gray-700 border-gray-300 hover:bg-gray-100"}
                    `}
                  >
                    <input
                      type="radio"
                      name="status"
                      value={option.value}
                      checked={status === option.value}
                      onChange={() => setStatus(option.value)}
                      className="form-radio h-4 w-4 text-blue-600 mr-2"
                    />
                    {option.label}
                  </label>
                ))}
              </div>
            </div>

            {/* Service Notes */}
            <div id="service-notes" className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Ghi chú dịch vụ</h3>
              <textarea 
                id="notes-input"
                className="w-full h-32 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Thêm ghi chú về quá trình phục vụ..."
                defaultValue={appointment.notes || ""}
              ></textarea>
              <div className="mt-4 flex justify-end">
                <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                  Lưu ghi chú
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AppointmentDetails;
