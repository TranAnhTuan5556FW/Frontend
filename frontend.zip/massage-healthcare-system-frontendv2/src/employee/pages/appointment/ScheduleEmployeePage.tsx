import React from "react";
import HeaderEmployee from "../../componets/HeaderEmployee";
import SideBarEmployee from "../../componets/SideBarEmployee";
import { Link } from "react-router-dom";
import { getAppointmentsByStatus } from "../../../data/appointmentsData";

const ScheduleEmployeePage: React.FC = () => {
  // Example appointment data
  const appointments = getAppointmentsByStatus("upcoming");

  return (
    <div className="min-h-screen bg-gray-50">
      <HeaderEmployee />
      <SideBarEmployee />
      <div className="ml-0 md:ml-64 pt-16">
        <header id="profile-header" className="bg-white shadow-sm mb-6">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center space-x-4">
              <span className="text-2xl font-semibold text-gray-800">Lịch làm việc của tôi</span>
              <div className="flex space-x-2">
                <button className="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">Hôm nay</button>
                <button className="px-4 py-2 text-sm bg-white border border-gray-300 rounded-lg hover:bg-gray-50">Tuần</button>
                <button className="px-4 py-2 text-sm bg-white border border-gray-300 rounded-lg hover:bg-gray-50">Tháng</button>
              </div>
            </div>
          </div>
        </header>
      </div>
      <main className="bg-gray-50 ml-0 md:ml-64 p-8 pt-0">
        {/* Stats Overview */}
        <div id="stats-overview" className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-4 rounded-xl shadow-sm">
            <div className="text-sm text-gray-500">Lịch hẹn hôm nay</div>
            <div className="text-2xl font-semibold mt-1">8</div>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-sm">
            <div className="text-sm text-gray-500">Khách hàng phục vụ</div>
            <div className="text-2xl font-semibold mt-1">24</div>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-sm">
            <div className="text-sm text-gray-500">Giờ làm việc</div>
            <div className="text-2xl font-semibold mt-1">6.5/8h</div>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-sm">
            <div className="text-sm text-gray-500">Tỷ lệ hoàn thành</div>
            <div className="text-2xl font-semibold mt-1">95%</div>
          </div>
        </div>

        {/* Calendar Grid & Sidebar */}
        <div id="calendar-section" className="flex flex-col lg:flex-row gap-6">
          <div id="calendar-main" className="flex-1">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="grid grid-cols-7 gap-px bg-gray-200">
                <div className="bg-white p-4 text-center text-sm font-medium">Thứ 2</div>
                <div className="bg-white p-4 text-center text-sm font-medium">Thứ 3</div>
                <div className="bg-white p-4 text-center text-sm font-medium">Thứ 4</div>
                <div className="bg-white p-4 text-center text-sm font-medium">Thứ 5</div>
                <div className="bg-white p-4 text-center text-sm font-medium">Thứ 6</div>
                <div className="bg-white p-4 text-center text-sm font-medium">Thứ 7</div>
                <div className="bg-white p-4 text-center text-sm font-medium">CN</div>
              </div>
              <div className="grid grid-cols-7 gap-px bg-gray-200">
                {/* Calendar Days */}
                <div className="bg-white p-2 min-h-[120px]">
                  <div className="text-sm text-gray-400">1</div>
                  <div className="mt-2 space-y-1">
                    <div className="bg-blue-100 text-blue-800 text-xs p-1 rounded">9:00 - Cắt tóc</div>
                  </div>
                </div>
                <div className="bg-white p-2 min-h-[120px]">
                  <div className="text-sm text-gray-400">2</div>
                </div>
                <div className="bg-white p-2 min-h-[120px]">
                  <div className="text-sm text-gray-400">3</div>
                  <div className="mt-2 space-y-1">
                    <div className="bg-green-100 text-green-800 text-xs p-1 rounded">14:00 - Massage</div>
                  </div>
                </div>
                <div className="bg-white p-2 min-h-[120px]">
                  <div className="text-sm text-gray-400">4</div>
                </div>
                <div className="bg-white p-2 min-h-[120px]">
                  <div className="text-sm text-gray-400">5</div>
                  <div className="mt-2 space-y-1">
                    <div className="bg-purple-100 text-purple-800 text-xs p-1 rounded">11:00 - Spa</div>
                  </div>
                </div>
                <div className="bg-white p-2 min-h-[120px]">
                  <div className="text-sm text-gray-400">6</div>
                </div>
                <div className="bg-white p-2 min-h-[120px]">
                  <div className="text-sm text-gray-400">7</div>
                </div>
                {/* ...other days... */}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div id="schedule-sidebar" className="w-full lg:w-[380px]">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Lịch hẹn sắp tới</h3>
              <div className="space-y-4">
                {appointments.map((apt) => (
                  <div key={apt.id} className="border-l-4 border-blue-500 pl-4 py-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="text-sm font-medium">{apt.service}</div>
                        <div className="text-xs text-gray-500">{apt.customerName}</div>
                      </div>
                      <div className="text-sm text-gray-600">{apt.time}</div>
                    </div>
                    <div className="mt-2 flex space-x-2">
                      <button className="text-xs px-3 py-1 bg-green-100 text-green-700 rounded-full">Hoàn thành</button>
                      <Link
                        to={`/employee/appointments/${apt.id}`}
                        className="text-xs px-3 py-1 bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200"
                      >
                        Chi tiết
                      </Link>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6">
                <h3 className="text-lg font-semibold mb-4">Ca làm việc</h3>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Giờ bắt đầu</span>
                    <span className="font-medium">8:00</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Giờ kết thúc</span>
                    <span className="font-medium">17:00</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Giờ nghỉ</span>
                    <span className="font-medium">12:00 - 13:00</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ScheduleEmployeePage;
