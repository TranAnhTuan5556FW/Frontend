import React, { useEffect, useRef } from "react";
import HeaderEmployee from "../componets/HeaderEmployee";
import SideBarEmployee from "../componets/SideBarEmployee";
// @ts-ignore
import Chart from "chart.js/auto";

const EmployeeDashboardPage: React.FC = () => {
  const chartRef = useRef<HTMLCanvasElement | null>(null);
  const chartInstanceRef = useRef<any>(null);

  useEffect(() => {
    if (chartRef.current) {
      const ctx = chartRef.current.getContext("2d");
      if (ctx) {
        // Destroy previous chart instance if exists
        if (chartInstanceRef.current) {
          chartInstanceRef.current.destroy();
        }
        chartInstanceRef.current = new Chart(ctx, {
          type: "bar",
          data: {
            labels: ["T2", "T3", "T4", "T5", "T6", "T7", "CN"],
            datasets: [
              {
                label: "Số dịch vụ",
                data: [12, 19, 15, 17, 14, 23, 18],
                backgroundColor: "rgba(59, 130, 246, 0.5)",
                borderColor: "rgb(59, 130, 246)",
                borderWidth: 1,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              y: {
                beginAtZero: true,
              },
            },
          },
        });
      }
    }
    // Cleanup function to destroy chart on unmount
    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
        chartInstanceRef.current = null;
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      <HeaderEmployee />
      <SideBarEmployee />
      <main className="bg-gray-50 min-h-[calc(100vh-70px)] ml-0 md:ml-64 p-8 pt-24">
        <div className="container mx-auto px-6">
          {/* Quick Stats */}
          <div id="quick-stats" className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <div className="flex items-center">
                <div className="bg-blue-100 p-3 rounded-lg">
                  <i className="fa-regular fa-calendar text-blue-600 text-xl"></i>
                </div>
                <div className="ml-4">
                  <p className="text-gray-600">Lịch hẹn hôm nay</p>
                  <h3 className="text-2xl font-bold">8</h3>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <div className="flex items-center">
                <div className="bg-green-100 p-3 rounded-lg">
                  <i className="fa-regular fa-user text-green-600 text-xl"></i>
                </div>
                <div className="ml-4">
                  <p className="text-gray-600">Khách hàng phục vụ</p>
                  <h3 className="text-2xl font-bold">24</h3>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <div className="flex items-center">
                <div className="bg-purple-100 p-3 rounded-lg">
                  <i className="fa-regular fa-clock text-purple-600 text-xl"></i>
                </div>
                <div className="ml-4">
                  <p className="text-gray-600">Tổng giờ làm</p>
                  <h3 className="text-2xl font-bold">156h</h3>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Upcoming Appointments */}
            <div id="upcoming-appointments" className="lg:col-span-2">
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h2 className="text-xl font-semibold mb-4">Lịch hẹn sắp tới</h2>
                <div className="space-y-4">
                  <div className="flex items-center p-4 border rounded-lg">
                    <div className="bg-blue-100 p-3 rounded-lg">
                      <i className="fa-regular fa-clock text-blue-600"></i>
                    </div>
                    <div className="ml-4">
                      <h4 className="font-semibold">Nguyễn Văn A</h4>
                      <p className="text-sm text-gray-600">Massage - 10:30</p>
                    </div>
                    <button className="ml-auto bg-blue-50 text-blue-600 px-4 py-2 rounded-lg text-sm">
                      Chi tiết
                    </button>
                  </div>
                  <div className="flex items-center p-4 border rounded-lg">
                    <div className="bg-blue-100 p-3 rounded-lg">
                      <i className="fa-regular fa-clock text-blue-600"></i>
                    </div>
                    <div className="ml-4">
                      <h4 className="font-semibold">Trần Thị B</h4>
                      <p className="text-sm text-gray-600">Facial - 13:45</p>
                    </div>
                    <button className="ml-auto bg-blue-50 text-blue-600 px-4 py-2 rounded-lg text-sm">
                      Chi tiết
                    </button>
                  </div>
                </div>
              </div>
            </div>
            {/* Notifications */}
            <div id="notifications" className="bg-white rounded-xl p-6 shadow-sm">
              <h2 className="text-xl font-semibold mb-4">Thông báo</h2>
              <div className="space-y-4">
                <div className="flex items-start p-4 bg-blue-50 rounded-lg">
                  <i className="fa-solid fa-circle-info text-blue-600 mt-1"></i>
                  <div className="ml-3">
                    <p className="text-sm">Lịch hẹn mới từ khách hàng Lê Thị C</p>
                    <span className="text-xs text-gray-500">5 phút trước</span>
                  </div>
                </div>
                <div className="flex items-start p-4 bg-yellow-50 rounded-lg">
                  <i className="fa-solid fa-clock text-yellow-600 mt-1"></i>
                  <div className="ml-3">
                    <p className="text-sm">Thay đổi ca làm việc ngày 15/05</p>
                    <span className="text-xs text-gray-500">2 giờ trước</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Service Performance Chart */}
          <div id="performance-chart" className="mt-6">
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <h2 className="text-xl font-semibold mb-4">Thống kê dịch vụ</h2>
              <div className="h-[400px]">
                <canvas ref={chartRef} id="serviceChart"></canvas>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default EmployeeDashboardPage;
