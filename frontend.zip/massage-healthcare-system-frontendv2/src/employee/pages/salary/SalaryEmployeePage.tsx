import React from "react";
import HeaderEmployee from "../../componets/HeaderEmployee";
import SideBarEmployee from "../../componets/SideBarEmployee";

const SalaryEmployeePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <HeaderEmployee />
      <SideBarEmployee />
      <div className="ml-0 md:ml-64 pt-16">
        <header id="profile-header" className="bg-white shadow-sm mb-6">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center space-x-4">
              <span className="text-2xl font-semibold text-gray-800">Lương & Hoa hồng</span>
              <div className="flex space-x-2">
                <button className="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">Tháng này</button>
                <button className="px-4 py-2 text-sm bg-white border border-gray-300 rounded-lg hover:bg-gray-50">Tháng trước</button>
              </div>
            </div>
          </div>
        </header>
      </div>
      <main className="bg-gray-50 min-h-[calc(100vh-70px)] ml-0 md:ml-64 p-8 pt-0">
        <div id="salary-commission-dashboard" className="min-h-[100vh] bg-gray-50">
          <div className="p-6">
            {/* Salary Overview */}
            <div id="salary-overview" className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-white p-4 rounded-xl shadow-sm">
                <div className="text-sm text-gray-500">Lương cơ bản</div>
                <div className="text-2xl font-semibold mt-1">25.000.000₫</div>
              </div>
              <div className="bg-white p-4 rounded-xl shadow-sm">
                <div className="text-sm text-gray-500">Hoa hồng</div>
                <div className="text-2xl font-semibold mt-1">8.500.000₫</div>
              </div>
              <div className="bg-white p-4 rounded-xl shadow-sm">
                <div className="text-sm text-gray-500">Thưởng</div>
                <div className="text-2xl font-semibold mt-1">2.000.000₫</div>
              </div>
              <div className="bg-white p-4 rounded-xl shadow-sm">
                <div className="text-sm text-gray-500">Tổng thu nhập</div>
                <div className="text-2xl font-semibold mt-1 text-green-600">35.500.000₫</div>
              </div>
            </div>

            {/* Detailed Information */}
            <div id="detailed-info" className="flex flex-col lg:flex-row gap-6">
              {/* Commission Details */}
              <div id="commission-details" className="flex-1">
                <div className="bg-white rounded-xl shadow-sm p-6">
                  <h3 className="text-lg font-semibold mb-4">Chi tiết hoa hồng</h3>
                  <div className="overflow-hidden">
                    <table className="min-w-full">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dịch vụ</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ngày</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Khách hàng</th>
                          <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Hoa hồng</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        <tr>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">Cắt & tạo kiểu tóc</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">01/05/2025</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Sarah Johnson</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-green-600">1.100.000₫</td>
                        </tr>
                        <tr>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">Massage toàn thân</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">02/05/2025</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Mike Peters</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-green-600">1.500.000₫</td>
                        </tr>
                        <tr>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">Liệu trình Spa</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">03/05/2025</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Emma Wilson</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-green-600">2.000.000₫</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Stats Sidebar */}
              <div id="stats-sidebar" className="w-full lg:w-[380px]">
                <div className="bg-white rounded-xl shadow-sm p-6">
                  <h3 className="text-lg font-semibold mb-4">Thống kê tháng</h3>
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-gray-600">Mục tiêu hoa hồng</span>
                        <span className="text-sm font-medium">10.000.000₫</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full">
                        <div className="h-2 bg-blue-600 rounded-full" style={{ width: '85%' }}></div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Tổng số dịch vụ</span>
                        <span className="font-medium">24</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Hoa hồng trung bình</span>
                        <span className="font-medium">354.200₫</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Hoa hồng cao nhất</span>
                        <span className="font-medium">2.000.000₫</span>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <button className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                        Xem lịch sử giao dịch
                      </button>
                      <button className="w-full mt-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200">
                        Quay lại hồ sơ
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default SalaryEmployeePage;
