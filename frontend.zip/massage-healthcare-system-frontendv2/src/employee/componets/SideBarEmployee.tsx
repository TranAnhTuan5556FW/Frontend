import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import '@fortawesome/fontawesome-free/css/all.min.css';

const SideBarEmployee: React.FC = () => {
  const location = useLocation();
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  return (
    <aside id="sidebar" className="fixed left-0 top-16 bottom-0 w-64 bg-white shadow-lg">
      <nav className="h-full overflow-y-auto">
        <div className="px-4 py-4 space-y-2">
          <Link
            to="/employee"
            className={`flex items-center px-4 py-3 rounded-lg cursor-pointer ${location.pathname === '/employee' ? 'text-gray-700 bg-purple-100' : 'text-gray-600 hover:bg-purple-100'}`}
          >
            <i className="fa-solid fa-chart-line mr-3" />
            <span>Bảng Điều Khiển</span>
          </Link>

          <Link
            to="/employee/schedule"
            className={`flex items-center px-4 py-3 rounded-lg cursor-pointer ${location.pathname === '/employee/schedule' ? 'text-gray-700 bg-purple-100' : 'text-gray-600 hover:bg-purple-100'}`}
          >
            <i className="fa-regular fa-calendar mr-3" />
            <span>Lịch Làm Việc</span>
          </Link>

          {/* Profile Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsProfileOpen(!isProfileOpen)}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-lg cursor-pointer ${
                location.pathname.startsWith('/employee/profile')
                  ? 'text-gray-700 bg-purple-100'
                  : 'text-gray-600 hover:bg-purple-100'
              }`}
            >
              <div className="flex items-center">
                <i className="fa-regular fa-user mr-3" />
                <span>Hồ Sơ Cá Nhân</span>
              </div>
              <i className={`fa-solid fa-chevron-${isProfileOpen ? 'up' : 'down'} ml-2`} />
            </button>
            {isProfileOpen && (
              <div className="pl-8 mt-1 space-y-1">
                <Link
                  to="/employee/profile"
                  className={`flex items-center px-4 py-2 rounded-lg cursor-pointer ${location.pathname === '/employee/profile' ? 'text-gray-700 bg-purple-100' : 'text-gray-600 hover:bg-purple-100'}`}
                >
                  <i className="fa-regular fa-id-badge mr-3" />
                  <span>Thông tin cá nhân</span>
                </Link>
                <Link
                  to="/employee/profile/salary"
                  className={`flex items-center px-4 py-2 rounded-lg cursor-pointer ${location.pathname === '/employee/profile/salary' ? 'text-gray-700 bg-purple-100' : 'text-gray-600 hover:bg-purple-100'}`}
                >
                  <i className="fa-solid fa-money-bill-wave mr-3" />
                  <span>Xem lương và hoa hồng</span>
                </Link>
              </div>
            )}
          </div>
        </div>
      </nav>
    </aside>
  );
};

export default SideBarEmployee;
