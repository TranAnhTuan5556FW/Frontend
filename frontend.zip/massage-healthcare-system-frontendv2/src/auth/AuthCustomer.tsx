import React, { useState, FormEvent, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Header from "../customer/components/HeaderCustomer";
import Footer from "../customer/components/FooterCustomer";
import '@fortawesome/fontawesome-free/css/all.min.css';
import { authenticateUser, validatePassword } from "../data/authData";
import { motion, AnimatePresence } from "framer-motion";

interface FormData {
  email: string;
  password: string;
  firstName?: string;
  lastName?: string;
  confirmPassword?: string;
  dateOfBirth?: string;
  gender?: string;
  phoneNumber?: string;
  rememberMe?: boolean;
  agreeToTerms?: boolean;
}

interface AuthError {
  email?: string;
  password?: string;
  confirmPassword?: string;
  phoneNumber?: string;
  general?: string;
}

const AuthCustomer: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [currentForm, setCurrentForm] = useState<'login' | 'signup' | 'forgot'>('login');
  const [formData, setFormData] = useState<FormData>({
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    confirmPassword: '',
    dateOfBirth: '',
    gender: '',
    phoneNumber: '',
    rememberMe: false,
    agreeToTerms: false
  });
  const [showPassword, setShowPassword] = useState({
    login: false,
    signup: false,
    confirm: false
  });
  const [errors, setErrors] = useState<AuthError>({});
  const [isLoading, setIsLoading] = useState(false);

  // Đọc query param để chuyển form
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const mode = params.get('mode');
    if (mode === 'signup') setCurrentForm('signup');
    else setCurrentForm('login');
  }, [location.search]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      setFormData(prev => ({
        ...prev,
        [name]: (e.target as HTMLInputElement).checked
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
      // Clear error when user types
      if (errors[name as keyof AuthError]) {
        setErrors(prev => ({ ...prev, [name]: undefined }));
      }
    }
  };

  const validateForm = (): boolean => {
    const newErrors: AuthError = {};

    if (!formData.email) {
      newErrors.email = "Email không được để trống";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email không hợp lệ";
    }

    if (!formData.password) {
      newErrors.password = "Mật khẩu không được để trống";
    } else if (currentForm === 'signup') {
      const passwordValidation = validatePassword(formData.password);
      if (!passwordValidation.isValid) {
        newErrors.password = passwordValidation.message;
      }
    }

    if (currentForm === 'signup') {
      if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = "Mật khẩu xác nhận không khớp";
      }
      
      // Validate phone number for signup
      if (!formData.phoneNumber) {
        newErrors.phoneNumber = "Số điện thoại không được để trống";
      } else {
        const phoneRegex = /(84|0[3|5|7|8|9])+([0-9]{8})\b/;
        if (!phoneRegex.test(formData.phoneNumber)) {
          newErrors.phoneNumber = "Số điện thoại không hợp lệ";
        }
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsLoading(true);
    try {
      if (currentForm === 'login') {
        const result = authenticateUser(formData.email, formData.password);
        if (result.success && result.user) {
          // Lưu thông tin user vào localStorage
          localStorage.setItem('user', JSON.stringify(result.user));
          localStorage.setItem('permissions', JSON.stringify(result.permissions));
          
          // Điều hướng dựa trên vai trò
          const role = result.user.role;
          if (role === 'admin') {
            navigate('/admin');
          } else {
            navigate('/'); // Điều hướng về trang chủ cho customer và employee
          }
        } else {
          setErrors({ general: result.message });
        }
      } else if (currentForm === 'signup') {
        // TODO: Implement signup logic
        console.log('Signup:', formData);
        setCurrentForm('login');
      } else if (currentForm === 'forgot') {
        // TODO: Implement forgot password logic
        console.log('Forgot password:', formData.email);
        setCurrentForm('login');
      }
    } catch (error) {
      setErrors({ general: "Đã có lỗi xảy ra. Vui lòng thử lại sau." });
    } finally {
      setIsLoading(false);
    }
  };

  const toggleShowPassword = (field: 'login' | 'signup' | 'confirm') => {
    setShowPassword(prev => ({ ...prev, [field]: !prev[field] }));
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Header />
      
      <main className="pt-24 pb-12 flex-grow">
        <section id="auth-container" className="container mx-auto px-4">
          <div className="max-w-md mx-auto">
            {/* Show error message if exists */}
            {errors.general && (
              <div className="mb-4 p-4 bg-red-100 text-red-700 rounded-lg">
                {errors.general}
              </div>
            )}

            {/* Animated Forms */}
            <AnimatePresence mode="wait">
              {currentForm === 'login' && (
                <motion.div
                  key="login"
                  id="login-form"
                  className="bg-white rounded-xl shadow-lg p-8 mb-8"
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -40 }}
                  transition={{ duration: 0.4 }}
                >
                  <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Chào mừng trở lại</h2>
                  <form className="space-y-4" onSubmit={handleSubmit}>
                    <div>
                      <label className="block text-gray-700 mb-2" htmlFor="email">Email</label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent ${
                          errors.email ? 'border-red-500' : 'border-gray-300'
                        }`}
                        placeholder="Nhập email của bạn"
                        disabled={isLoading}
                        required
                      />
                      {errors.email && (
                        <p className="mt-1 text-sm text-red-500">{errors.email}</p>
                      )}
                    </div>
                    <div className="relative">
                      <label className="block text-gray-700 mb-2" htmlFor="password">Mật khẩu</label>
                      <input
                        type={showPassword.login ? "text" : "password"}
                        id="password"
                        name="password"
                        value={formData.password}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                        placeholder="Nhập mật khẩu của bạn"
                        required
                      />
                      <button
                        type="button"
                        tabIndex={-1}
                        className="absolute right-3 top-9 text-gray-500 hover:text-[#008080]"
                        onClick={() => toggleShowPassword('login')}
                      >
                        <i className={`fa-regular ${showPassword.login ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          name="rememberMe"
                          checked={formData.rememberMe}
                          onChange={handleInputChange}
                          className="form-checkbox text-[#008080]"
                        />
                        <span className="ml-2 text-sm text-gray-600">Ghi nhớ đăng nhập</span>
                      </label>
                      <button
                        type="button"
                        className="text-sm text-[#008080] hover:text-[#006666]"
                        onClick={() => setCurrentForm('forgot')}
                      >
                        Quên mật khẩu?
                      </button>
                    </div>
                    <button 
                      type="submit" 
                      className={`w-full bg-[#008080] text-white py-2 rounded-lg hover:bg-[#006666] transition duration-300 ${
                        isLoading ? 'opacity-50 cursor-not-allowed' : ''
                      }`}
                      disabled={isLoading}
                    >
                      {isLoading ? 'Đang xử lý...' : 'Đăng nhập'}
                    </button>

                    <div className="relative flex items-center justify-center my-4">
                      <div className="border-t border-gray-300 w-full"></div>
                      <span className="bg-white px-4 text-sm text-gray-500">Hoặc đăng nhập với</span>
                      <div className="border-t border-gray-300 w-full"></div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <button
                        type="button"
                        onClick={() => console.log('Google login')}
                        className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition duration-300"
                      >
                        <i className="fa-brands fa-google text-red-500 mr-2"></i>
                        <span className="text-gray-700">Google</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => console.log('Facebook login')}
                        className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition duration-300"
                      >
                        <i className="fa-brands fa-facebook text-blue-600 mr-2"></i>
                        <span className="text-gray-700">Facebook</span>
                      </button>
                    </div>
                  </form>
                  <div className="mt-6 text-center">
                    <p className="text-gray-600">
                      Chưa có tài khoản?{" "}
                      <button
                        className="text-[#008080] hover:text-[#006666]"
                        onClick={() => setCurrentForm('signup')}
                      >
                        Đăng ký
                      </button>
                    </p>
                  </div>
                </motion.div>
              )}

              {currentForm === 'forgot' && (
                <motion.div
                  key="forgot"
                  id="forgot-password-form"
                  className="bg-white rounded-xl shadow-lg p-8 mb-8"
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -40 }}
                  transition={{ duration: 0.4 }}
                >
                  <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Đặt lại mật khẩu</h2>
                  <form className="space-y-4" onSubmit={handleSubmit}>
                    <div>
                      <label className="block text-gray-700 mb-2" htmlFor="reset-email">Email</label>
                      <input
                        type="email"
                        id="reset-email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                        placeholder="Nhập email của bạn"
                        required
                      />
                    </div>
                    <button type="submit" className="w-full bg-[#008080] text-white py-2 rounded-lg hover:bg-[#006666] transition duration-300">
                      Gửi liên kết đặt lại
                    </button>
                  </form>
                  <div className="mt-6 text-center">
                    <button
                      className="text-[#008080] hover:text-[#006666]"
                      onClick={() => setCurrentForm('login')}
                    >
                      Quay lại đăng nhập
                    </button>
                  </div>
                </motion.div>
              )}

              {currentForm === 'signup' && (
                <motion.div
                  key="signup"
                  id="signup-form"
                  className="bg-white rounded-xl shadow-lg p-8"
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -40 }}
                  transition={{ duration: 0.4 }}
                >
                  <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Tạo tài khoản</h2>
                  <form className="space-y-4" onSubmit={handleSubmit}>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-gray-700 mb-2" htmlFor="first-name">Họ</label>
                        <input
                          type="text"
                          id="first-name"
                          name="firstName"
                          value={formData.firstName}
                          onChange={handleInputChange}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                          placeholder="Nhập họ"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-gray-700 mb-2" htmlFor="last-name">Tên</label>
                        <input
                          type="text"
                          id="last-name"
                          name="lastName"
                          value={formData.lastName}
                          onChange={handleInputChange}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                          placeholder="Nhập tên"
                          required
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-gray-700 mb-2" htmlFor="date-of-birth">Ngày sinh</label>
                      <input
                        type="date"
                        id="date-of-birth"
                        name="dateOfBirth"
                        value={formData.dateOfBirth}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 mb-2" htmlFor="gender">Giới tính</label>
                      <select
                        id="gender"
                        name="gender"
                        value={formData.gender}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                        required
                      >
                        <option value="">Chọn giới tính</option>
                        <option value="male">Nam</option>
                        <option value="female">Nữ</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-gray-700 mb-2" htmlFor="phone-number">Số Điện Thoại</label>
                      <input
                        type="tel"
                        id="phone-number"
                        name="phoneNumber"
                        value={formData.phoneNumber}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                        placeholder="Nhập số điện thoại"
                        required
                      />
                      {errors.phoneNumber && (
                        <p className="mt-1 text-sm text-red-500">{errors.phoneNumber}</p>
                      )}
                    </div>
                    <div>
                      <label className="block text-gray-700 mb-2" htmlFor="signup-email">Email</label>
                      <input
                        type="email"
                        id="signup-email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                        placeholder="Nhập email của bạn"
                        required
                      />
                    </div>
                    <div className="relative">
                      <label className="block text-gray-700 mb-2" htmlFor="signup-password">Mật khẩu</label>
                      <input
                        type={showPassword.signup ? "text" : "password"}
                        id="signup-password"
                        name="password"
                        value={formData.password}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                        placeholder="Tạo mật khẩu"
                        required
                      />
                      <button
                        type="button"
                        tabIndex={-1}
                        className="absolute right-3 top-9 text-gray-500 hover:text-[#008080]"
                        onClick={() => toggleShowPassword('signup')}
                      >
                        <i className={`fa-regular ${showPassword.signup ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                      </button>
                    </div>
                    <div className="relative">
                      <label className="block text-gray-700 mb-2" htmlFor="confirm-password">Xác nhận mật khẩu</label>
                      <input
                        type={showPassword.confirm ? "text" : "password"}
                        id="confirm-password"
                        name="confirmPassword"
                        value={formData.confirmPassword}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#008080] focus:border-transparent"
                        placeholder="Xác nhận mật khẩu"
                        required
                      />
                      <button
                        type="button"
                        tabIndex={-1}
                        className="absolute right-3 top-9 text-gray-500 hover:text-[#008080]"
                        onClick={() => toggleShowPassword('confirm')}
                      >
                        <i className={`fa-regular ${showPassword.confirm ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                      </button>
                    </div>
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="terms"
                        name="agreeToTerms"
                        checked={formData.agreeToTerms}
                        onChange={handleInputChange}
                        className="form-checkbox text-[#008080]"
                        required
                      />
                      <label htmlFor="terms" className="ml-2 text-sm text-gray-600">
                        Tôi đồng ý với{" "}
                        <span className="text-[#008080] hover:text-[#006666] cursor-pointer">
                          Điều khoản và Điều kiện
                        </span>
                      </label>
                    </div>
                    <button type="submit" className="w-full bg-[#008080] text-white py-2 rounded-lg hover:bg-[#006666] transition duration-300">
                      Tạo tài khoản
                    </button>
                  </form>
                  <div className="mt-6 text-center">
                    <p className="text-gray-600">
                      Đã có tài khoản?{" "}
                      <button
                        className="text-[#008080] hover:text-[#006666]"
                        onClick={() => setCurrentForm('login')}
                      >
                        Đăng nhập
                      </button>
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default AuthCustomer; 